function thumbsUp(element){
	var indexReda=element.parentNode.parentNode.rowIndex;
	if(indexReda!=1){
	var roditelj= element.parentNode.parentNode;
    var dijete= roditelj.parentNode;
	dijete.insertBefore(roditelj,roditelj.previousElementSibling);
	}
	else{
		var red = document.getElementById("myTable").rows[indexReda].cells;
		for (var i = red.length - 1; i >= 0; i--) {
			var tmp=red[i].innerHTML;
			red[i].innerHTML=tmp;
			
		}
	}
}
function thumbsDown(element){
	var indexReda=element.parentNode.parentNode.rowIndex;

	if(indexReda!=5){
		var red = document.getElementById("myTable").rows[indexReda].cells;
		var redIspod=document.getElementById("myTable").rows[indexReda+1].cells;
		for (var i = red.length - 1; i >= 0; i--) {
			var tmp=red[i].innerHTML;
			red[i].innerHTML=redIspod[i].innerHTML;
			redIspod[i].innerHTML=tmp;
		}
		return true;
	}
	else{
		var red = document.getElementById("myTable").rows[indexReda].cells;
		for (var i = red.length - 1; i >= 0; i--) {
			var tmp=red[i].innerHTML;
			red[i].innerHTML=tmp;
			
		}
	}
	return false;
}
function klikPotvrdi(){
	var index = document.getElementById("index").value;
	var spirala = document.getElementById("spirala").value;
	var sadrzaj=[];
	for(var i=0;i<5;i++){
		var sifra = document.getElementById("myTable").rows[i+1].cells[0].innerHTML;
		console.log(sifra);
		var komentar = document.getElementById("myTable").rows[i+1].cells[1].children[0].value;
		var pom = {sifra_studenta:sifra,tekst:komentar,ocjena:i};
		sadrzaj.push(pom);
	}
	sadrzaj=JSON.stringify(sadrzaj);
	console.log(sadrzaj);
	KreirajFajl.kreirajKomentar(spirala,index,sadrzaj,function(error,data){
		alert(data);
	});
}