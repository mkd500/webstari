var KreirajFajl=(function(){
    
    return{
        kreirajKomentar:function(spirala,index,sadrzaj,fnCallback){
            var ajax = new XMLHttpRequest();  
            var error;
            var data;
            var greskaUParametrima=false;
            if(spirala.length<1 || index.length<1) greskaUParametrima=true;
            sadrzaj=JSON.parse(sadrzaj);
            for(var i=0;i<sadrzaj.length;i++){
                console.log({sadrzaj:sadrzaj[i]});
                if(!(sadrzaj[i].hasOwnProperty("sifra_studenta") && sadrzaj[i].hasOwnProperty("tekst") && sadrzaj[i].hasOwnProperty("ocjena")) ){
                    greskaUParametrima=true;
                    break;
                }

            }
            if(greskaUParametrima){
                error=-1;
                data="Neispravni parametri";
                fnCallback(error,data);
            }
                            
            ajax.onreadystatechange = function() {// Anonimna funkcija
                if (ajax.readyState == 4 && ajax.status == 200){
                    error=null;
                    data=ajax.responseText;
                    fnCallback(error,data);
                }
                else if(ajax.readyState == 4 && ajax.status != 200){
                    error=ajax.status;
                    data=ajax.responseText;
                    fnCallback(error,data);
                }
                    
               
            };
    
            ajax.open("POST", "http://localhost:3000/komentar", true);
            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send(JSON.stringify({spirala:spirala,index:index,sadrzaj:sadrzaj}));
            
        },
        kreirajListu:function(godina,nizRepozitorija,fnCallback){
            var ajax = new XMLHttpRequest();  
            var error;
            var data;
            var greskaUParametrima=false;

            if(godina.length<1 || nizRepozitorija.length<1) {
                error=-1;
                data="Neispravni parametri";
                fnCallback(error,data);
            }
            else{
            ajax.onreadystatechange = function() {// Anonimna funkcija
                if (ajax.readyState == 4 && ajax.status == 200){
                    error=null;
                    data=ajax.responseText;
                    console.log(data);
                    fnCallback(error,data);
                }
                else if(ajax.readyState == 4 && ajax.status != 200){
                    error=ajax.status;
                    data=ajax.responseText;
                    console.log(data);
                    fnCallback(error,data);
                }
                
            };
            
            ajax.open("POST", "http://localhost:3000/lista", true);
            ajax.setRequestHeader("Content-Type", "application/json");
            console.log({nizRepozitorija:JSON.stringify({godina:godina,nizRepozitorija:nizRepozitorija})});
            ajax.send(JSON.stringify({godina:godina,nizRepozitorija:nizRepozitorija}));
        }
 
        },
        kreirajIzvjestaj:function(spirala,index,fnCallback){
            var ajax = new XMLHttpRequest();  
            var error;
            var data;

            if(index.length<1 ) {
                error=-1;
                data="Neispravni parametri";
            }
            else{
                ajax.onreadystatechange = function() {// Anonimna funkcija
                    if (ajax.readyState == 4 && ajax.status == 200){
                        error=null;
                        data=ajax.responseText;
                        fnCallback(error,data);
                    }
                    else if(ajax.readyState == 4 && ajax.status != 200){
                        error=ajax.status;
                        data=ajax.responseText;
                        fnCallback(error,data);
                    }
                };
                
                ajax.open("POST", "http://localhost:3000/izvjestaj", true);
                ajax.setRequestHeader("Content-Type", "application/json");
                ajax.send(JSON.stringify({spirala:spirala,index:index}));
            }
        },
        kreirajBodove:function(spirala,index,fnCallback){
            var ajax = new XMLHttpRequest();  
            var error;
            var data;
            var greskaUParametrima=false;
            console.log("k");    
            if(index.length<1 ) {
                error=-1;
                data="Neispravni parametri";
                fnCallback(error,data);
            }
            ajax.onreadystatechange = function() {// Anonimna funkcija
                if (ajax.readyState == 4 && ajax.status == 200){
                    error=null;
                    data=ajax.responseText;
                    fnCallback(error,data);
                }
                else if(ajax.readyState == 4 && ajax.status != 200){
                    error=ajax.status;
                    data=ajax.responseText;
                    fnCallback(error,data);
                }
                
            };
            ajax.open("POST", "http://localhost:3000/bodovi", true);
            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send(JSON.stringify({spirala:spirala,index:index}));
            
        }

    }
})();
