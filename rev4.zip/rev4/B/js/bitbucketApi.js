//import { error } from "util";

var BitbucketApi=(function(){
    return{
        dohvatiAccessToken:function(key,secret,fnCallback){
            var ajax = new XMLHttpRequest();
            var error;
            var data;
            if(key==null || secret==null){
                error=-1;
                data="Key ili secret nisu pravilno proslijeđeni!";
                fnCallback(error,data);
            }
            else{
            ajax.onreadystatechange = function() {// Anonimna funkcija
                if (ajax.readyState == 4 && ajax.status == 200){
                    error=null;
                    data=JSON.parse(ajax.responseText).access_token;
                    fnCallback(error,data);
                }
                   
                else if (ajax.readyState == 4){
                    error=ajax.status;
                    data=null;
                    fnCallback(error,data);
                }

            }    
                
            }
            ajax.open("POST", "https://bitbucket.org/site/oauth2/access_token", true);
            ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            ajax.setRequestHeader("Authorization", "Basic "+btoa(key+":"+secret));
            ajax.send("grant_type=client_credentials");
        },
        dohvatiRepozitorije:function(token,godina,naziv,branch,fnCallback){
            var ajax = new XMLHttpRequest();
            var error;
            var data;
            ajax.onreadystatechange = function(){
                if (ajax.readyState == 4 && ajax.status == 200)
                {
                    var odg=JSON.parse(ajax.responseText).values;
                    var nizData=[];
                    
                    for(var i=0;i<odg.length;i++){

                        brisi=false;
                        console.log("godine "+parseInt(godina)+1);
                        if(!(parseInt(odg[i].created_on.substr(0,4))==parseInt(godina) || parseInt(odg[i].created_on.substr(0,4))==parseInt(godina)+1)) brisi=true;
                        console.log("brisi "+brisi);
                        function pomfun(x){
                            BitbucketApi.dohvatiBranch(token,odg[i].links.branches.href,branch,function(err,dat){
                                if(!dat)brisi=true;
                                
                                if(!brisi){
                                 for(var j=0;j<x.length;j++){
                                     if(x[j].name=="ssh") nizData.push(x[j].href);
                                 }
                                }
                                console.log({data:dat});
                                console.log({x:x}); 
                                console.log({i:i,odg:odg.length});
                                if(i==odg.length){
                                    error=null;
                                    data=nizData;
                                    console.log("poziva se callback");
                                    fnCallback(error,data)
                                }
                            });
                         }
                         pomfun(odg[i].links.clone);
                        }
                    
                }
                else if (ajax.readyState == 4){
                    error=ajax.status;
                    data=null;
                    fnCallback(error,data);
                }
                
        }
        ajax.open("GET",'https://api.bitbucket.org/2.0/repositories/?role=member&q=name~"'+naziv+'"&pagelen=100');
        ajax.setRequestHeader("Authorization", 'Bearer ' + token);
        ajax.send();
        },
        dohvatiBranch:function(token,url,naziv,fnCallback){
            var ajax = new XMLHttpRequest();
            var error;
            var data;
            console.log("poziva se");
            ajax.onreadystatechange = function(){
                if (ajax.readyState == 4 && ajax.status == 200)
                {
                    var odg=JSON.parse(ajax.responseText).values;
                    var postoji=false;
                    for(var i=0;i<odg.length;i++){
                        if(odg[i].name==naziv){ console.log({branch:odg[i].name}); postoji=true; break;}
                    }

                    error=null;
                    data=postoji;
                    pom=data;
                    fnCallback(error,data);
                    
                }
                else if (ajax.readyState == 4){
                    error=ajax.status;
                    data=null;
                    fnCallback(error,data);
                }
                
        }
        ajax.open("GET",url,true);
        ajax.setRequestHeader("Authorization", 'Bearer ' + token);
        ajax.send();
        
        var brojac=incr();
        console.log(brojac);
        }
    }
})();
var incr = (function () {
    var i = 1;

    return function () {
        return i++;
    }
})();
var pom=null;
