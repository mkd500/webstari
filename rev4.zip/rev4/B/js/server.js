
function registrujStudenta()
{
	izbrisiVrijednosti();
	Poruke.postaviIdDiva("greskeStudent");
	document.getElementById('greskeStudent').style.display="block";
  	document.getElementById('greskeNastavnik').style.display="none";
  	document.getElementById('greskeStudent').innerHTML="";
  	document.getElementById('forma2').style.display="none";
  	document.getElementById('forma3').style.display="block";
  	document.getElementById('registracija2').style.display="none";
  	document.getElementById('registracija1').style.display="block";
  	Poruke.ocistiSveGreske();
  	return true;
}
function registrujNastavnika()
{
	izbrisiVrijednosti();
  	Poruke.postaviIdDiva("greskeNastavnik");
  	document.getElementById('greskeStudent').style.display="none";
  	document.getElementById('greskeNastavnik').style.display="block";
  	document.getElementById('greskeNastavnik').innerHTML="";
  	document.getElementById('forma3').style.display="none";
  	document.getElementById('forma2').style.display="block";
  	document.getElementById('registracija1').style.display="none";
  	document.getElementById('registracija2').style.display="block";
  	Poruke.ocistiSveGreske();
  	return true;
}
function izbrisiVrijednosti(){
	var inputNumber=document.getElementsByClassName('zaBrisanje');
	var inputText=document.getElementsByClassName('zaBrisanjeText');
	console.log({inputNumber:inputNumber,inputText:inputText});
	for (var i = inputText.length - 1; i >= 0; i--) {
		inputText[i].value="";
	}
	for (var i = inputNumber.length - 1; i >= 0; i--) {
		inputNumber[i].value='';
	}
}

function statistika(){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200)
            document.getElementById("kontejner").innerHTML = ajax.responseText;
        if (ajax.readyState == 4 && ajax.status == 404)
            document.getElementById("kontejner").innerHTML = "Greska: nepoznat URL";
    }
    ajax.open("GET", "/statistika", true);
    ajax.send();
}   
function unoskomentara(){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {// Anonimna funkcija
    if (ajax.readyState == 4 && ajax.status == 200)
        document.getElementById("kontejner").innerHTML = ajax.responseText;
    if (ajax.readyState == 4 && ajax.status == 404)
        document.getElementById("kontejner").innerHTML = "Greska: nepoznat URL";
    }
    ajax.open("GET", "/unoskomentara", true);
    ajax.send();
}
function registracija(){
    
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {// Anonimna funkcija
    if (ajax.readyState == 4 && ajax.status == 200)
       { document.getElementById("kontejner").innerHTML = ajax.responseText;
       console.log("ev me");
    }
    if (ajax.readyState == 4 && ajax.status == 404)
        document.getElementById("kontejner").innerHTML = "Greska: nepoznat URL";
    }
    ajax.open("GET", "/login", true);
    ajax.send();
}
function nastavnik(){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {// Anonimna funkcija
    if (ajax.readyState == 4 && ajax.status == 200)
        document.getElementById("kontejner").innerHTML = ajax.responseText;
    if (ajax.readyState == 4 && ajax.status == 404)
        document.getElementById("kontejner").innerHTML = "Greska: nepoznat URL";
    }
    ajax.open("GET", "/nastavnik", true);
    ajax.send();
}
function bitbucket(){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {// Anonimna funkcija
    if (ajax.readyState == 4 && ajax.status == 200)
        document.getElementById("kontejner").innerHTML = ajax.responseText;
    if (ajax.readyState == 4 && ajax.status == 404)
        document.getElementById("kontejner").innerHTML = "Greska: nepoznat URL";
    }
    ajax.open("GET", "/bitbucket", true);
    ajax.send();
}
function spisak(){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {// Anonimna funkcija
    if (ajax.readyState == 4 && ajax.status == 200)
        document.getElementById("kontejner").innerHTML = ajax.responseText;
    if (ajax.readyState == 4 && ajax.status == 404)
        document.getElementById("kontejner").innerHTML = "Greska: nepoznat URL";
    }
    ajax.open("GET", "/unosspiska", true);
    ajax.send();
}
function klikIzvjestaj(){
    var index = document.getElementById("index").value;
    var spirala = document.getElementById("spirala").value;
    KreirajFajl.kreirajIzvjestaj(spirala,index,function(error,data){
        alert(data);
    });
    
}
function klikBodovi(){
    var index = document.getElementById("index").value;
    var spirala = document.getElementById("spirala").value;
    KreirajFajl.kreirajBodove(spirala,index,function(error,data){
        alert(data);
    });
}

function dohvatiSve(){
    var key = document.getElementById("key").value;
    var secret = document.getElementById("secret").value;
    var repozitorij = document.getElementById("repozitorij").value;
    var branch = document.getElementById("branch").value;
    var godina = document.getElementById("godina").value;
    BitbucketApi.dohvatiAccessToken(key,secret,function(error,data){
        BitbucketApi.dohvatiRepozitorije(data,godina,repozitorij,branch,function(err,dat){
            console.log({nezzz:dat});
            
            KreirajFajl.kreirajListu(godina,dat,function(e,d){
                alert(d);
            });
        })
    });

}

function duplikati(array) {
    var valuesSoFar = Object.create(null);
    for (var i = 0; i < array.length; ++i) {
        var value = array[i];
        if (value in valuesSoFar) {
            return true;
        }
        valuesSoFar[value] = true;
    }
    return false;
}

function kreirajDokument(text){
    var ajax = new XMLHttpRequest();  
    var error="";
    var data;

    var textArea = document.getElementById("text");
    var listaLinija = textArea.value.split("\n");

    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200){
            error=null;
            data=ajax.responseText;
        }
        else if(ajax.readyState == 4 && ajax.status != 200){
            error=ajax.status;
            data=ajax.responseText;
        }
    var validno=true;
    for(var i=0;i<listaLinija.length;i++){
        var listaIndexa=listaLinija[i].split(",");
        if(listaIndexa.length!=6){
            validno=false;
            break;
        }
        if(duplikati(listaIndexa)){
            validno=false;
            break;
        }

    }
    if(!validno){
        str="Prvi red koji ne zadovoljava uslove je: "+listaLinija[i];
        error=str;
        data=ajax.responseText;
    }
};
var jsonArr=new Array;
for(var i=0;i<listaLinija.length;i++){
    var listaIndexa=listaLinija[i].split(",");
    var maliArr=new Array;
    for(var j=0;j<listaIndexa.length;j++) maliArr.push(listaIndexa[j]);
    jsonArr.push(maliArr);
} 
var br=document.getElementById("broj").value;
ajax.open("POST", "/unosspiska", true);
ajax.setRequestHeader("Content-Type", "application/json");
ajax.send(JSON.stringify({broj:br,sadrzaj:JSON.stringify(jsonArr),greska:error}));
   
}

function Registracija(){
    //action="http://localhost:3000/registracija" method="POST"
    var ajax = new XMLHttpRequest();
    var sIme=document.getElementById("sIme").value;
            console.log({sIme:sIme});
            var sIndex=document.getElementById("sIndex").value;
            console.log({sIndex:sIndex});
            var sBrojGrupe=document.getElementById("sBrojGrupe").value;
            var sTrenutnaAg=document.getElementById("sTrenutnaAg").value;
            var sPass=document.getElementById("sPass").value;
            var sPotvrda=document.getElementById("sPotvrda").value;
            var sBitbucket=document.getElementById("sBitbucket").value;
            var sSSH=document.getElementById("sSSH").value;
            var sRep=document.getElementById("sRep").value;
            var nIme=document.getElementById("nIme").value;
            var nUname=document.getElementById("nUname").value;
            var nPass=document.getElementById("nPass").value;
            var nPotvrda=document.getElementById("nPotvrda").value;
            var nRegex=document.getElementById("nRegex").value;
            var nEmail=document.getElementById("nEmail").value;
            var nMax=document.getElementById("nMax").value;
            var nAkademskaGodina=document.getElementById("nAkademskaGodina").value;
            var nTrenutniSemestar=document.getElementById("nTrenutniSemestar").value;
    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200){
           
            
            document.getElementById("prvi").innerHTML = ajax.responseText;
            izbrisiVrijednosti(); // ovo treba nedje dole
     }
    }
    ajax.open("POST","/registracija",true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(JSON.stringify({sIme:sIme,sIndex:sIndex,sBrojGrupe:sBrojGrupe,sTrenutnaAg:sTrenutnaAg,sPass:sPass,sPotvrda:sPotvrda,sBitbucket:sBitbucket,sSSH:sSSH,sRep:sRep,
    nIme:nIme,nUname:nUname,nPass:nPass,nPotvrda:nPotvrda,nRegex:nRegex,nEmail:nEmail,nMax:nMax,nAkademskaGodina:nAkademskaGodina,nTrenutniSemestar:nTrenutniSemestar}));
}

function prijava()
{
    
    var ajax = new XMLHttpRequest();
    var ime = document.getElementById('uname').value;
    var password = document.getElementById('psw').value;
    console.log({ime:ime,password:password});
    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200){
            document.getElementById("menuKontejner").innerHTML = ajax.responseText;
            document.getElementById("kontejner").innerHTML ="";
        }
    }
    ajax.open("POST","/prijava",true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(JSON.stringify({username:ime,password:password}));
}
function logout(){
    var ajax = new XMLHttpRequest();
    console.log("poziva se");
    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200){
            //document.getElementById("menuKontejner").innerHTML = "";
            document.getElementById("pom").innerHTML = ajax.responseText;
        }
    }
    ajax.open("POST","/index",true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send();
}
function dajListuKorisnika()
{
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200)
            document.getElementById("kontejner").innerHTML = ajax.responseText;
    }
    ajax.open("GET", "/listaKorisnika", true);
    ajax.send();
}
function pretraga()
{
    var ajax = new XMLHttpRequest();
    var pretraga = document.getElementById('pretraga').value;
    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200)
            document.getElementById("kontejner").innerHTML = ajax.responseText;
    }
    ajax.open("GET", "/listaKorisnika/"+pretraga, true);
    ajax.send();
}
function verificiraj(i,id)
{
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200){
            document.getElementById("poruka").innerHTML = ajax.responseText;
            document.getElementById("tabela").rows[i].cells[1].children[0].style.display="block";
            document.getElementById("tabela").rows[i].cells[2].children[0].style.display="none";
           
        }
    }
    ajax.open("GET","/verify/"+id,true);
    ajax.send();
}
function odverificiraj(i,id)
{
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200){
            document.getElementById("poruka").innerHTML = ajax.responseText;
            document.getElementById("tabela").rows[i].cells[1].children[0].style.display="none"
            document.getElementById("tabela").rows[i].cells[2].children[0].style.display="block"
            
        }
    }
    ajax.open("GET","/unverify/"+id,true);
    ajax.send();
}

