var Poruke=(function(){
    var idDivaPoruka="greskeStudent";
    var mogucePoruke=["\nEmail koji ste unijeli nije validan fakultetski mail\n",//0
                        "\nIndeks koji ste unijeli nije validan\n",//1
                        "\nNastavna grupa koju ste unijeli nije validna\n",//2
                        "\nAkademska godina koju ste unijeli nije validna\n",//3
                        "\nPassword koji ste unijeli nije validan\n",//4
                        "\nPotvrda passworda koju ste unijeli nije validna\n",//5
                        "\nBitbucket URL koji ste unijeli nije validan\n",//6
                        "\nBitbucket SSH koji ste unijeli nije validan\n",//7
                        "\nNaziv repozitorija koji ste unijeli nije validan\n",//8
                        "\nIme i prezime koje ste unijeli nije validno\n",//9
                        "\nBroj semestra koji ste unijeli nije validan\n"];//10
    var porukeZaIspis=[];
    function ispisiGreske(){
        document.getElementById(idDivaPoruka).innerHTML=porukeZaIspis.toString();
    }
    function postaviIdDiva(id){
        idDivaPoruka=id;
    }
    function dodajPoruku(i){
        var str=mogucePoruke[i].toString();
        var indeks=porukeZaIspis.indexOf(str);
        if(indeks==-1)
            porukeZaIspis.push(mogucePoruke[i]);
        ispisiGreske();
    }
    function ocistiGresku(i){
       var indeks=porukeZaIspis.indexOf(mogucePoruke[i]);
       if(indeks>-1){
        porukeZaIspis.splice(indeks,1);
       }
       ispisiGreske();
    }
    function ocistiSveGreske(){
        for (var i = mogucePoruke.length - 1; i >= 0; i--) {
             var indeks=porukeZaIspis.indexOf(mogucePoruke[i]);
       if(indeks>-1){
        porukeZaIspis.splice(indeks,1);
       }
        }
    }
    return{
        ispisiGreske:ispisiGreske,
        postaviIdDiva:postaviIdDiva,
        dodajPoruku:dodajPoruku,
        ocistiGresku:ocistiGresku,
        ocistiSveGreske:ocistiSveGreske
    }
}());


var Validacija=(function(){
	var maxGrupa=7;
	var trenutniSemestar=0; //0 zimski, 1 ljetni
	var trenutnaGodina=parseInt((new Date()).getFullYear()%100);
	var regeksByNastavnik=null;
	function validirajImeiPrezime(string)
	{
		var regeks=/^[A-ZČĆŽŠĐ][a-zA-ZČĆŽŠĐčćžžđ]{2,12}([ \-']*[A-ZČĆŽŠĐ][a-zA-ZČĆŽŠčćžžđ]*)*$/;
        if(regeks.test(string)) Poruke.ocistiGresku(9);
        else Poruke.dodajPoruku(9);
		return regeks.test(string);
	}
	function validirajFakultetski(string)
	{
		var regeks=/\w*@etf.unsa.ba\b/;
        if(regeks.test(string)) Poruke.ocistiGresku(0);
        else Poruke.dodajPoruku(0);
		return regeks.test(string);
	}
    function validirajIndeks(broj)
    {
    	var regeks=/^[1][0-9]{4}\b/;
        if(regeks.test(broj)) Poruke.ocistiGresku(1);
        else Poruke.dodajPoruku(1);
    	return regeks.test(broj);
    }
    function validirajGrupu(broj)
    {
    	var regeks= /^[1-7]\b/;
        if(regeks.test(broj)) Poruke.ocistiGresku(2);
        else Poruke.dodajPoruku(2);
    	return regeks.test(broj);
    }
    function validirajAkGod(string)
    {
    	var regeks=/(20[1-9]+[1-9]|202[0-9])+\/+(20[1-9]+[1-9]|20[0-9]+[1-9])/;
    	var prvi=parseInt(string.substring(2,4));
    	var drugi=parseInt(string.substring(7,9));

    	if(trenutniSemestar==0 && trenutnaGodina==prvi && prvi==drugi-1)
    	{ 
            if(regeks.test(string)) Poruke.ocistiGresku(3);
            else Poruke.dodajPoruku(3);
    		return regeks.test(string);
    	}

    	else if(trenutniSemestar==1 && trenutnaGodina==drugi && prvi==drugi-1)
    	{
            if(regeks.test(string)) Poruke.ocistiGresku(3);
            else Poruke.dodajPoruku(3);
    		return regeks.test(string);
    	}
        else Poruke.dodajPoruku(3);
    	return false;
    }
    function validirajPassword(string)
    {
    	var regeks=/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{7,20}$/;
        if(regeks.test(string)) Poruke.ocistiGresku(4);
        else Poruke.dodajPoruku(4);
    	return regeks.test(string);
    }
    function validirajBitbucketURL(string)
    {
    	var regeks=/^https:\/\/[a-zA-Z0-9][a-zA-Z0-9]*@bitbucket.org\/[a-zA-Z0-9][a-zA-Z0-9]*\/wt(?:p|P)rojekat[1][0-9]{4}\b.git$/;
        if(regeks.test(string)) Poruke.ocistiGresku(6);
        else Poruke.dodajPoruku(6);
    	return regeks.test(string);
    }
    function validirajPotvrdu(string1,string2)
    {
    	if(string1==string2)
    	{
            if(regeks.test(string1)) Poruke.ocistiGresku(5);
            else Poruke.dodajPoruku(5);
    		return validirajPassword(string1) && regeks.test(string1) && regeks.test(string2);
    	}
        else Poruke.dodajPoruku(5);
        return false;
    }
    function validirajBitbucketSSH(string)
    {
		var regeks=/(s|git@bitbucket.org)\:[a-zA-Z0-9][a-zA-Z0-9]*\/wt(?:p|P)rojekat[1][0-9]{4}\b(s|.git)$/;
        if(regeks.test(string)) Poruke.ocistiGresku(7);
        else Poruke.dodajPoruku(7);
    	return regeks.test(string);
    }
    
    function validirajNazivRepozitorija(reg,string)
    {

    	if(reg==null)
    	{
    		regeks=/^wt(?:p|P)rojekat[1][0-9]{4}\b$/;
    	} 
        else regeks=new Regex(reg);

        if(regeks.test(string)) Poruke.ocistiGresku(8);
        else Poruke.dodajPoruku(8);

    	return regeks.test(string);
    }
    function postaviMaxGrupa(max)
    {
    	maxGrupa=max;
    }
    function postaviTrenSemestar(semestar)
    {
        if(semestar>1){
            Poruke.dodajPoruku(10);
            return false;
        } 
    	trenutniSemestar=semestar;
    }
    function postaviRegeks(string){
        regeksByNastavnik=string;
    }
	return{
		validirajFakultetski:validirajFakultetski,
		validirajIndeks:validirajIndeks,
		validirajGrupu:validirajGrupu,
		validirajAkGod:validirajAkGod,
		validirajPassword:validirajPassword,
		validirajPotvrdu:validirajPotvrdu,
		validirajBitbucketURL:validirajBitbucketURL,
		validirajBitbucketSSH:validirajBitbucketSSH,
		validirajNazivRepozitorija:validirajNazivRepozitorija,
		validirajImeiPrezime:validirajImeiPrezime,
		postaviMaxGrupa:postaviMaxGrupa,
		postaviTrenSemestar:postaviTrenSemestar,
        postaviRegeks:postaviRegeks
	}

}());


