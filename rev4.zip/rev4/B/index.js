
//Administrator: username:Admin password:nekipassword

var js = require('readjson');
var express = require('express'); 
var app = express(); 
var path = require('path'); 
var fs = require('fs');
var port = 3000 ;
var bodyParser = require('body-parser');

const session = require("express-session");
const bcrypt = require('bcrypt-nodejs');

app.use(session({secret: 'sifrica',resave: true,saveUninitialized: true}));
app.use(express.static(path.join(__dirname + '/css'))); 
app.use(express.static(path.join(__dirname + '/js')));
app.use(express.static(path.join(__dirname + '/html')));
app.use(express.static(__dirname + '/baza'));

app.use(express.static('spirala'));
app.use(bodyParser());

const Sequelize = require('sequelize');
const sequelize = require('./baza/DB.js');
const Korisnik = sequelize.import(__dirname+"/baza/korisnik.js");
const Rola = sequelize.import(__dirname+"/baza/rola.js");
const Podaci = sequelize.import(__dirname+"/baza/podaci.js");
Rola.sync().then(function()
{
    Rola.findOrCreate({where: {id: 1}, defaults: {naziv: 'Administrator'}})
    Rola.findOrCreate({where: {id: 2}, defaults: {naziv: 'Student'}})
    Rola.findOrCreate({where: {id: 3}, defaults: {naziv: 'Nastavnik'}})
});
Podaci.sync();
Korisnik.sync().then(function()
{
    Korisnik.findOrCreate({where: {username: 'Admin'}, defaults: {password: bcrypt.hashSync('nekipassword'), RolaId: 1}})
});


const saltRounds = 10;

app.get('/', function(req, res) { 
    res.sendFile(path.join(__dirname, '/html/index.html')); 
    req.session.permisija=null;
});

app.post('/index', function(req, res) { 
    res.sendFile(path.join(__dirname, '/html/index.html')); 
    req.session.permisija=null;
});
app.post('/login', function(req, res) { 
    res.sendFile(path.join(__dirname, '/html/login.html')); 
    req.session.permisija=null;
});

app.get('/statistika',function(req,res)
{
    console.log(req.session.permisija);
    if(req.session.permisija === 2)
    res.sendFile(__dirname + '/html/statistika.html'); 
    else
    res.send('Nemate dozvolu za pristup ovom sadrzaju');
});
app.get('/unoskomentara',function(req,res)
{
    if(req.session.permisija === 2)
    res.sendFile(__dirname + '/html/unoskomentara.html');  
    else
    res.send('Nemate dozvolu za pristup ovom sadrzaju');
    
});
app.get('/login',function(req,res)
{
    console.log(req.session.permisija);
    if(req.session.permisija === 3)
    res.sendFile(__dirname + '/html/login.html');  
    else
    res.send('Nemate dozvolu za pristup ovom sadrzaju');
    
});
app.get('/unosspiska',function(req,res)
{
    if(req.session.permisija === 3)
    res.sendFile(__dirname + '/html/unosSpiska.html');  
    else
    res.send('Nemate dozvolu za pristup ovom sadrzaju');
   
});
app.post('/unosspiska',function(req,res){ 
    if(req.session.permisija != 3)
    {
        res.send(permissionError);
        res.end();
    }
    console.log(req.body.greska);   
    if(req.body.greska!=""){
      //  alert(req.body.greska);
    }
    else{
        fs.writeFile("spisakS"+req.body.broj+".json",req.body.sadrzaj,(err) => {
        if (err) throw err;
    });
       // alert("Uspjesno kreirana datoteka");
    }
         
});
app.get('/nastavnik',function(req,res)
{
    if(req.session.permisija === 3)
    res.sendFile(__dirname + '/html/nastavnik.html');  
    else
    res.send('Nemate dozvolu za pristup ovom sadrzaju');
    
});
app.get('/izvjestaj',function(req,res)
{
    if(req.session.permisija === 3)
      res.sendFile(__dirname + '/html/nastavnik.html'); 
    else
    res.send('Nemate dozvolu za pristup ovom sadrzaju');
   
});
app.post('/bodovi', function(req,res){ 
    
    if(req.session.permisija != 3)
    {
        res.send(permissionError);
        res.end();
    }
    
    var suma = 0;
    
    var index=req.body.index;
    var spirala=req.body.spirala;
    var p = "./"
    var datoteke=[];
    var brojac=0;

    fs.readdir(p,async function (err, files) {
        if (err) {
            throw err;
        }

        files.map(function (file) {
            return path.join(p, file);
        }).filter(function (file) {
            return fs.statSync(file).isFile();
        }).forEach(function (file) {
            datoteke.push(file);
        });
    });
    suma=0;
     fs.readFile('./spisakS'+req.body.spirala+".json",'utf-8',(err,data)=>{
        if(err) throw err;
        data=JSON.parse(data);
        for( var i=0;i<data.length;i++){
            var indeksi = data[i].splice(',');
            
            for(var j=1;j<6;j++){
               if(indeksi[j]==req.body.index){
                   console.log(indeksi[i]);
                     async function upisi(parametar,s){
                        if(datoteke.indexOf('markS'+spirala+indeksi[0]+'.json')!=-1){
                        fs.readFile('./markS'+req.body.spirala+indeksi[0]+".json",'utf-8',(err,data)=>{
                            if(err) throw err;
                            data=JSON.parse(data);
                            console.log(suma);
                            suma=parseInt(s)+parseInt(data[parametar-1].ocjena);
                            console.log(suma+"   "+brojac);
                            brojac++;
                            f(suma,brojac);
                            return suma;
                        });                            
                    }
                }
                var x=suma;
                
                console.log({sumaprije:suma});
                suma= upisi(j,x);
                console.log({sumaposlije:suma});
                  
                
                }
            
            }
            //if(i==data.length-1){
                function f(sum,br){
                    console.log({i: i, dat:data.length-1});
                    if(i==data.length){
                console.log({suma: suma, brojac:brojac});
                suma=parseInt(suma);
                suma+=1;
                console.log('suma '+suma);
                res.send({poruka:"Student "+req.body.index+" je ostvario u prosjeku "+suma+" mjesto"});
                }
            }
            
        }        
    });
    
});
app.post('/izvjestaj',function(req,res){ 

    if(req.session.permisija != 3)
    {
        res.send(permissionError);
        res.end();
    }
    var index=req.body.index;
    var spirala=req.body.spirala;
    var naziv="izvjestajS"+spirala+index+".txt";
    var upisano="";

    fs.writeFile(naziv,'',(err) => { if (err) throw err;});

    var p = "./"
    var datoteke=[];
    fs.readdir(p, function (err, files) {
        if (err) {
            throw err;
        }

        files.map(function (file) {
            return path.join(p, file);
        }).filter(function (file) {
            return fs.statSync(file).isFile();
        }).forEach(function (file) {
            datoteke.push(file);
        });
    });
    
    fs.readFile('spisakS'+req.body.spirala+'.json', (err, data) => {
        
        if (err) throw err;
        
        var str = JSON.parse(data);//data.toString();
        console.log(str);

        for(var i=0;i<str.length;i++){
            var pom=str[i].splice(',');
            console.log(pom);
            for(var j=0;j<pom.length;j++){
                if(pom[j]==index){
                    console.log(pom[j]);
                    function upisUDatoteku(x){
                        //ako ima i ako nema
                        console.log(datoteke);
                        if(datoteke.indexOf('markS'+spirala+index+'.json')!=-1){
                            fs.readFile('markS'+spirala+index+'.json', (err, data) => {
            
                                if (err) throw err;

                                var procitano=JSON.parse(data);
                                //procitano= procitano[x-1].tekst+'\n'+"##########"+'\n';
                                console.log({upisujese:procitano[x-1].tekst});
                                var upisi=procitano[x-1].tekst+'\n'+"##########"+'\n';
                                upisano+=upisi+'\n';
                                fs.appendFile(naziv,upisi,function(err){
                                    if(err) throw err;
                                });
                            });
                        }
                    }
                    upisUDatoteku(j);
                }
                
            }
        }
        
      });
      console.log({upisano:upisano});
      res.send("Datoteka uspjesno kreirana!");
});
app.post('/komentar',function(req,res){ 
    if(req.session.permisija != 3)
    {
        res.send(permissionError);
        res.end();
    }
    console.log({neRadi:req.body});
    if(!(req.body.hasOwnProperty("spirala") && req.body.hasOwnProperty("index") && req.body.hasOwnProperty("sadrzaj") 
        //&& req.body.sadrzaj.hasOwnProperty("sifra_studenta")
        //&& req.body.sadrzaj.hasOwnProperty("tekst")
        //&& req.body.sadrzaj.hasOwnProperty("ocjena")
    ))
    res.send({message:"Podaci nisu u traženom formatu!",data:null});
    else{
        var index=req.body.index;
        var spirala=req.body.spirala;
        var sadrzaj=req.body.sadrzaj;
        var naziv="markS"+spirala+index+".json";
        fs.writeFile(naziv,'',(err) => { if (err) throw err;});
        var brojac=0;
         
                fs.appendFile(naziv,JSON.stringify(sadrzaj,function(err){
                        if(err) throw err;
                }));
        
        res.send({message:"Uspjesno kreirana datoteka",data:sadrzaj});
    }
      
});
app.get('/bitbucket',function(req,res)
{
    if(req.session.permisija === 3)
    res.sendFile(__dirname + '/html/bitbucketPozivi.html');  
    else
    res.send('Nemate dozvolu za pristup ovom sadrzaju');
    
});
app.post('/lista',function(req,res){ 
    if(req.session.permisija != 3)
    {
        res.send(permissionError);
        res.end();
    }
    if(!(req.body.hasOwnProperty("godina") && req.body.hasOwnProperty("nizRepozitorija")))
    res.send({message:"Podaci nisu u traženom formatu!",data:null});
    else{
        var listaRepozitorija=req.body.nizRepozitorija;
        var godina=req.body.godina;
        var naziv="spisak"+godina;
        fs.writeFile(naziv,'',(err) => { if (err) throw err;});
        var brojac=0;
        for(var i=0;i<listaRepozitorija.length;i++){
            
            var dijelovi=listaRepozitorija[i].split('/');
            if(dijelovi[1].includes(godina)){
                fs.appendFile(naziv,listaRepozitorija[i]+'\n',function(err){
                        if(err) throw err;
                });
                brojac++;
            }
        }
        res.send({message:"Lista uspjesno kreirana",data:brojac});
    }
    
});



app.post('/prijava',function(req,res){
        console.log(req);
    var username = req.body.username.replace('SELECT','').replace('select','').replace('Select','').replace('>','').replace('<','');
    var password = req.body.password.replace('SELECT','').replace('select','').replace('Select','').replace('>','').replace('<','');
   console.log({username:username,password:password});
    Korisnik.findOne({where: {username: username}}).then(function(results){
        if(!results)
        {
            res.send('Ne postoji korisnik sa unsesnim username-om');
            res.end();
        }
        else
        {
            
            var korisnik = results.dataValues;
            bcrypt.compare(password, korisnik.password, function(err, data) {
                if (err) console.log(korisnik.password);
                
                if(data == true) //2 ili 3 jednako
                {
                    Podaci.findOne({where:{id: korisnik.PodaciId}}).then(function(results1){
                        if(!results1){
                           
                            req.session.permisija = korisnik.RolaId;
                            var permission = req.session.permisija = korisnik.RolaId;
                            console.log(permission);
                            if(permission === 1)
                            res.sendFile(__dirname + '/html/menuAdmin.html');
                        }
                        else{
                            console.log(results1.dataValues);
                        if(results1.dataValues.verified === true || results1.dataValues.verified === null || korisnik.RolaId == 1)
                        {
                            console.log(req.session);
                            var permission = req.session.permisija = korisnik.RolaId;
                            
                            
                            if(permission === 2)
                                res.sendFile(__dirname + '/html/menuStudent.html');
                            else
                                res.sendFile(__dirname + '/html/menuNastavnik.html');
                        }
                        else
                        {
                            res.send('Korisnik nije verificiran');
                            res.end();
                        }
                    }
                    })
                   

                }
                else
                {
                    res.send('Netacan password');
                    res.end();
                }
            });
        }
    });
});

app.post('/registracija',function(req,res){
  console.log({kkkk: req.body});
        if(req.body.nEmail != ""){
            console.log("sto ides ovdje aaa??");
            bcrypt.hash(req.body.nPass, null,null,(function(hash) {
            Podaci.create({imePrezime:req.body.nIme.replace('<','').replace('>','').replace('SELECT','').replace('select',''), 
                                fakultetskiMail:req.body.nEmail.replace('<','').replace('>','').replace('SELECT','').replace('select',''),
                                maksimalanBrojGrupa:req.body.nMax.replace('<','').replace('>','').replace('SELECT','').replace('select',''),
                                regexZaValidaciju:req.body.nRegex.replace('<','').replace('>','').replace('SELECT','').replace('select',''),
                                trenutniSemestar:req.body.nTrenutniSemestar.replace('<','').replace('>','').replace('SELECT','').replace('select',''),
                                akademskaGodina:req.body.nAkademskaGodina.replace('<','').replace('>','').replace('SELECT','').replace('select',''),
                                verified:false,
                        })
                        .then(function(zapis){
                            Korisnik.create({
                                username:req.body.nUname.replace('<','').replace('>','').replace('SELECT','').replace('select',''),
                                password:hash,
                                PodaciId:zapis.id,
                                RolaId:3
                            });
                            res.send(zapis);
                        })
                        .catch(function(err){
                            res.send(err);
                        });
                    }));
        }
        else if(req.body.sIme!='')
        {
            console.log({pass:req.body});
            bcrypt.hash(req.body.sPass, null, null, (function(err,hash) {
           if(err) return err;
                Podaci.create({imePrezime:req.body.sIme.replace('<','').replace('>','').replace('SELECT','').replace('select',''), 
                                    Index:req.body.sIndex.replace('<','').replace('>','').replace('SELECT','').replace('select',''),
                                    brojGrupe:req.body.sBrojGrupe.replace('<','').replace('>','').replace('SELECT','').replace('select',''),
                                    verified:null,
                                    bitbucketUrl:req.body.sBitbucket.replace('<','').replace('>','').replace('SELECT','').replace('select',''),
                                    bitbucketSsh:req.body.sSSH.replace('<','').replace('>','').replace('SELECT','').replace('select',''),
                                    nazivRepozitorija:req.body.sRep.replace('<','').replace('>','').replace('SELECT','').replace('select',''),
                                    fakultetskiMail:null,
                                    maksimalanBrojGrupa:null,
                                    regexZaValidaciju:null,
                                    trenutniSemestar:null,
                                    akademskaGodina:null,
                                    verified:null
                                })
                            .then(function(zapis){
                                console.log({hash:hash});
                                Korisnik.create({
                                    password:hash,
                                    username:req.body.sIme.replace('<','').replace('>','').replace('SELECT','').replace('select',''),
                                    PodaciId:zapis.id,
                                    RolaId:2
                                });
                                res.send(zapis);
                            })
                            .catch(function(err){
                                res.send(err);
                            });
                        }));
        }
        else
        {
            res.send('Format podataka nije uredu');
        }
});

app.get('/listaKorisnika',function(req,res){
    if(req.session.permisija != 1)
    {
        res.send('Nemate privilegije za pregled ovog sadrzaja');
        res.end();
    }
    Podaci.findAll({include: [Korisnik]}).then(function(results){
        var ispis = '';
        var redovi = [];
        for(i = 0; i < results.length;i++)
        {
            var varijable = results[i].dataValues;
            var red = '<tr><td>' + varijable.imePrezime+ '</td>';
            console.log({varijable:varijable})
            if(varijable.verified == false)
            {
                //<td><button style="display:inline;">Verify</button><button style="display:none">Unverify</button></td>
                red += '<td><button style="display:none;" id="unverificiraniButton" onClick="odverificiraj('+i+','+ varijable.id +')">Unverify</button> </td> <td> <button style="display:inline;" id="verificiraniButton" onClick="verificiraj('+i+','+ varijable.id + ')">Verify</button></td>';
            }
            else if(varijable.verified == true)
            {
                red += '<td><button style="display:inline;" id="unverificiraniButton" onClick="odverificiraj('+i+','+ varijable.id +')">Unverify</button> </td> <td> <button style="display:none;" id="verificiraniButton" onClick="verificiraj('+i+','+ varijable.id + ')">Verify</button></td>';
            }
            red += '</tr>';
            redovi.push(red);
        }
        var ispis = '<input id="pretraga"><button onclick=pretraga()>Pretrazi</button>';
        ispis += '<table id="tabela">';
        for(i = 0; i < redovi.length;i++)
        {
            ispis += redovi[i];
        }
        ispis += '</table>';
        ispis+='<div id="poruka"></div>';
        res.send(ispis);
        res.end();
    });
});
app.get('/listaKorisnika/:pretraga',function(req,res){
    if(req.session.permisija != 1)
    {
        res.send('Zabranjen pristup sadrzaju');
        res.end();
    }
    var pretraga = req.params.pretraga;
    pretraga = pretraga.replace('<','').replace('>','').replace('SELECT','').replace('select','');
    sequelize.query("SELECT * from korisniks k, licniPodacis lp where k.username like ? and k.PodaciId = lp.Id",{ replacements: ['%'+pretraga+'%']})
            .spread(function(results,metadata){
        var ispis = '';
        var redovi = [];
        for(i = 0; i < results.length;i++)
        {
            var varijable = results[i];
            var red = '<tr><td>' + varijable.username+ '</td>';
            if(varijable.verified == false)
            {
                red += '<td><button>Verify</button></td>';
            }
            else if(varijable.verified == true)
            {
                red += '<td><button>Unverify</button></td>';
            }
            red += '</tr>';
            redovi.push(red);
        }
        var ispis = '<input id="pretraga"><button onclick=pretraga()>Pretrazi</button>';
        ispis += '<table>';
        for(i = 0; i < redovi.length;i++)
        {
            ispis += redovi[i];
        }
        ispis += '</table>';
        console.log({ispis:ispis});
        res.send(ispis);
        res.end();
    });
});
app.get('/verify/:id',function(req,res)
{
    var id = req.params.id;
    Podaci.findOne(
        { where: 
            { id: id}
        }
    ).then(function (podaci) {
    if (podaci) {
      podaci.updateAttributes({
        verified: true
      })
      console.log(podaci);
      
      res.send('Korisnik ' + podaci.imePrezime + ' verificiran!');
    }
  })
});
app.get('/unverify/:id',function(req,res)
{
    var id = req.params.id;
    Podaci.findOne(
        { where: 
            { id: id}
        }
    ).then(function (podaci) {
    if (podaci) {
      podaci.updateAttributes({
        verified: false
      })
      console.log(podaci);
      res.send('Korisnik ' + podaci.imePrezime + ' odverificiran!');
    }
  })
});
app.listen(process.env.PORT||3000);

console.log("Now listening on port " + port); 
