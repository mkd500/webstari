const Sequelize = require("sequelize");
const sequelize = require("./DB.js");
const Podaci = sequelize.define('licniPodaci',{
    imePrezime: Sequelize.STRING(30),
    brojGrupe: Sequelize.STRING(5),
    akademskaGodina: Sequelize.STRING(10),
    Index: Sequelize.STRING(30),
    bitbucketUrl: Sequelize.STRING,
    bitbucketSsh: Sequelize.STRING,
    nazivRepozitorija: Sequelize.STRING(20),
    fakultetskiMail: Sequelize.STRING(25),
    maksimalanBrojGrupa: Sequelize.INTEGER,
    regexZaValidacijuNazivaRepozitorija: Sequelize.STRING(30),
    trenutniSemestar: Sequelize.INTEGER,
    verified: Sequelize.BOOLEAN
})
module.exports = function(sequelize,DataTypes){
    return Podaci;
}