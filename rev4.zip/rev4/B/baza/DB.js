const Sequelize = require("sequelize");
const sequelize = new Sequelize("heroku_3c83b2e940a0213","b3b7ad02bb15b2","4ef1153d",{host:"us-cdbr-iron-east-05.cleardb.net",dialect:"mysql"});
module.exports = sequelize;