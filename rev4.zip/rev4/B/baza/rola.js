const Sequelize = require("sequelize");
const sequelize = require("./DB.js");
const Rola = sequelize.define('Rola',{
    naziv: Sequelize.STRING(30),
})
module.exports = function(sequelize,DataTypes){
    return Rola;
}