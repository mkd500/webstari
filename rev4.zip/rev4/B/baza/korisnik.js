const Sequelize = require("sequelize");
const sequelize = require("./DB.js");
const Korisnik = sequelize.define('Korisnik',{
    username: Sequelize.STRING(30),
    password: Sequelize.STRING(100)
})
const Rola = sequelize.import(__dirname+"/rola.js");
const Podaci = sequelize.import(__dirname+"/podaci.js");

Rola.hasOne(Korisnik, {as: 'Rola', foreignKey: 'RolaId'});
Podaci.hasOne(Korisnik, {foreignKey: 'PodaciId'});


module.exports = function(sequelize,DataTypes){
    return Korisnik;
}