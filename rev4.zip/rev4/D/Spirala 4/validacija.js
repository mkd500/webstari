var Validacija=(function(){
    var maxGrupa=7;
    var trenutniSemestar=0;//0 za zimski, 1 za ljetni semestar
    var ajax = new XMLHttpRequest();
    return{
    validirajFakultetski: function(Mail) {
            var regexmail= /^\w+@etf.unsa.ba$/g;
            return regexmail.test(Mail);
        },
    validirajIndex: function(Indeks){
                var regex = /^1\d{4}$/g;
                return regex.test(Indeks);
            },
    validirajGrupu: function(Grupa) {
                if(Grupa.length>1) return false;
                var broj=parseInt(Grupa);
                if(broj<1 || broj>maxGrupa){
                    return false;
                }
                return true;
            },
    validirajAkGod: function(akgod) {
                var regexakgod = /^20\d{2}\/20\d{2}$/g;
                if(regexakgod.test(akgod)){
                    var a = parseInt(akgod[2])*10+parseInt(akgod[3]);
                    var b = parseInt(akgod[7])*10+parseInt(akgod[8]);
                    if(a+1 != b){
                        return false;
                    }
                    
                }
                else if(!regexakgod.test(akgod)) return false;
                return true;
            },
    validirajPassword: function(sifra) {
                var regexsifra = /(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{7,20}/g;
                return regexsifra.test(sifra);
            },
    validirajPotvrdu: function(sifra, sifrapot) {
                if(sifra == sifrapot) return true;
                return false;},
    validirajBitbucketURL: function(bitbucketurl) {
                var regexbitbucket = /^https:\/\/\w+@bitbucket.org\/\w+\/\w+.git$/g;
                return regexbitbucket.test(bitbucketurl);
            }, 
    validirajBitbucketSSH: function(ssh) {
                var regexssh= /^git@bitbucket.org:\w+\/\w+\.git$/g;
                return regexssh.test(ssh);

            },
    validirajNazivRepozitorija: function(regexrep, naziv) {
                if(regexrep == "" || regexrep == null){
                    regexrep = /^wt[Pp]rojekat1\d{4}$/g; 
                }
                var a = new RegExp(regexrep);
                return a.test(naziv);
            },
    validirajImeiPrezime: function(imeprezime) {
                var regeximeprez = /^(^[A-ZŠŽĆĐČ][a-zA-Z-'šćŠĆČčĐđŽž]{2,11}\s[A-ZŠŽĆĐČ][a-zA-Z-'šćŠĆČčĐđŽž]{0,}$)|(^[A-ZŠĐŽĆČ][a-zA-Z-'šćŠĆČčĐđŽž]?\s[A-Z][a-zA-Z-'šćŠĆČčĐđŽž]{2,11}$)$/g;
                return regeximeprez.test(imeprezime);
            },
    postaviMaxGrupa: function(max) {
                maxGrupa=max;
            },
    postaviTrenSemestar: function(semestar) {
                trenutniSemestar=semestar;
            }   
    }
    }());
    function Validiraj(bool, broj){
        if(!bool){
                Poruke.dodajPoruku(broj);
                Poruke.ispisiGreske();
            }
            else {
                Poruke.ocistiGresku(broj);
                Poruke.ispisiGreske();
            }
    }