function swapup(id, idred){
    var tabela = document.getElementById(id);
    var redovi = document.getElementsByTagName("TR");
    var red = document.getElementById(idred);
    for(var i=0; i<redovi.length; i++){
        if(redovi[i] == red && i!=0){
            redovi[i-1].parentNode.insertBefore(redovi[i], redovi[i-1]);
            break;
        }
    }

}
function swapdown(id, idred){
    var tabela = document.getElementById(id);
    var redovi = document.getElementsByTagName("TR");
    var red = document.getElementById(idred);
    for(var i=0; i<redovi.length; i++){
        if(redovi[i] == red && i!=redovi.length-1){
            redovi[i].parentNode.insertBefore(redovi[i+1], redovi[i]);
            break;
        }
    }

}