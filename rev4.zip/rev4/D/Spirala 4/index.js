const express = require('express');
const bodyParser = require('body-parser');
const http = require('http');
const fs = require('fs');
const app = express();
const bcrypt = require('bcrypt');
const session = require("express-session");
const Sequelize = require('sequelize');
const xssFilters = require('xss-filters');
const Op = Sequelize.Op;
app.use(session({
    secret: 'root',
    resave: true,
    saveUninitialized: true
 }));
app.use(express.static("public"));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.get('/',function(req,res){
    if(req.session.rola == null || req.session.rola == "")
        res.sendFile(__dirname + '/index.html');
    else if(req.session.rola == "student") 
        res.sendFile(__dirname + '/indexStudent.html');
    else if(req.session.rola == "nastavnik")
        res.sendFile(__dirname + "/indexNastavnik.html");
    else if(req.session.rola == "administrator")
        res.sendFile(__dirname + "/indexAdministrator.html");
});

app.get('/login',function(req,res)
{
    res.sendFile(__dirname + '/login.html');
});
app.get('/studentMeni', function(req,res){
    res.sendFile(__dirname + '/studentMeni.html');
});
app.get('/nastavnikMeni', function(req,res){
    res.sendFile(__dirname + '/nastavnikMeni.html');
});
app.get('/administratorMeni', function(req,res){
    res.sendFile(__dirname + '/administratorMeni.html');
});
app.get('/unosSpiska',function(req,res)
{
    if(req.session.rola == "nastavnik")
        res.sendFile(__dirname + '/unosSpiska.html');
    else 
        res.end();
});
app.get('/bitbucketPozivi',function(req,res)
{
    if(req.session.rola == "nastavnik")
        res.sendFile(__dirname + '/bitbucketPozivi.html');
    else 
        res.end();
});
app.get('/nastavnik', function(req,res)
{
    if(req.session.rola == "nastavnik")
        res.sendFile(__dirname + '/nastavnik.html');
    else 
        res.end();
});
app.get('/statistika',function(req,res)
{
    if(req.session.rola == "student")
        res.sendFile(__dirname + '/statistika.html');
    else 
        res.end();
});
app.get('/index.js',function(req,res)
{
    res.sendFile(__dirname + '/index.js');
});
app.get('/login.js',function(req,res)
{
    res.sendFile(__dirname + '/login.js');
});
app.get('/unoskomentara.js',function(req,res)
{
    res.sendFile(__dirname + '/unoskomentara.js');
});
app.get('/unoskomentara',function(req,res)
{
    if(req.session.rola == "student")
        res.sendFile(__dirname + '/unoskomentara.html');
    else 
        res.end();
});
app.get('/bitbucketPozivi.js',function(req,res)
{
    res.sendFile(__dirname + '/bitbucketPozivi.js');
});
app.get('/bitbucketApi.js',function(req,res)
{
    res.sendFile(__dirname + '/bitbucketApi.js');
});
app.get('/AjaxZadatak1.js',function(req,res)
{
    res.sendFile(__dirname + '/AjaxZadatak1.js');
});
app.get('/PrikaziVrati.js',function(req,res)
{
    res.sendFile(__dirname + '/PrikaziVrati.js');
});
app.get('/registracija.js',function(req,res)
{
    res.sendFile(__dirname + '/registracija.js');
});
app.get('/Svap.js',function(req,res)
{
    res.sendFile(__dirname + '/Svap.js');
});
app.get('/ValidirajKorisnicko.js',function(req,res)
{
    res.sendFile(__dirname + '/ValidirajKorisnicko.js');
});
app.get('/validacija.js',function(req,res)
{
    res.sendFile(__dirname + '/validacija.js');
});
app.get('/poruke.js',function(req,res)
{
    res.sendFile(__dirname + '/poruke.js');
});
app.get('/unosSpiska.js',function(req,res)
{
    res.sendFile(__dirname + '/unosSpiska.js');
});
app.get('/kreirajFajl.js', function(req,res)
{
    res.sendFile(__dirname + '/kreirajFajl.js');
});
app.post('/unosSpiska', function(req,res){
    let tijelo =  req.body;
    let test = tijelo['niz'];
    fs.writeFile("spisakS" + tijelo['broj'] +".json", test);
});
app.post('/komentar', function(req,res){
    let tijelo = xssFilters.inHTMLData(req.body['nesto']);
    tijelo = JSON.parse(tijelo);
    if(!tijelo.hasOwnProperty("spirala") || !tijelo.hasOwnProperty("index") || !tijelo.hasOwnProperty("sadrzaj")) {
        res.json({"message":"Podaci nisu u traženom formatu!", "data":null});
        return;
    }
    let sadrzaj = tijelo['sadrzaj'];
    for(i=0; i<sadrzaj.length; i++){
        if(sadrzaj[i].hasOwnProperty("sifra_studenta") || sadrzaj[i].hasOwnProperty("tekst") || sadrzaj[i].hasOwnProperty("ocjena")){
            res.json({"message":"Podaci nisu u traženom formatu!", "data":null});
            return;
        }
    }
    let spirala = tijelo['spirala'];
    let index = tijelo['index'];
    fs.writeFile("markS" + spirala + index + ".json",JSON.stringify(tijelo), function(err){
        if(err) throw err;
        res.json({"message":"Uspješno kreirana datotoeka!", "data":tijelo});
    });
});
app.post('/lista', function(req,res){
    let tijelo = xssFilters.inHTMLData(req.body['nesto']);
    tijelo = JSON.parse(tijelo);
    if(!tijelo.hasOwnProperty("godina") || !tijelo.hasOwnProperty("nizRepozitorija")) {
        res.json({"message":"Podaci nisu u traženom formatu!", "data":null});
        return;
    }
    var godina = tijelo['godina'];
    let nizRep = tijelo['nizRepozitorija'];
    for(i=0; i<nizRep.length; i++){
        if(nizRep[i].indexOf(godina) == -1){
            nizRep.splice(i,1);
        }
    }
    let string = "";
    for(i = 0; i<nizRep.length; i++){
        if(i < nizRep.length-1){
            string += nizRep[i] + "\n";
        }
        else {
            string += nizRep[i];
        }
    }
    fs.writeFile("spisak" + godina + ".txt" , string ,function(err){
        if(err) throw err;
        res.json({"message":"Uspješno kreirana datotoeka!", "data":nizRep.length});
    });

});
app.post('/izvjestaj', function(req,res){
    let tijelo = xssFilters.inHTMLData(req.body['nesto']);
    tijelo = JSON.parse(tijelo);
    fs.readdir(__dirname, function(err, data){
        var naziv = "spisakS" + tijelo["spirala"] + ".json";
        var treba = "";
        for(i=0; i<data.length; i++){
            if(data[i] == naziv){
                treba = data[i];
                break;
            }
        }
        let rawdata = fs.readFileSync(treba);
        let podaciSpisakSX = JSON.parse(rawdata);

        var indeks = tijelo["index"];
        var spirala = tijelo["spirala"];
        var studenti = [];
        var ocjena = [];
        for(i=0; i<podaciSpisakSX.length; i++){
            for(j=1; j<podaciSpisakSX[i].length; j++){
                if(podaciSpisakSX[i][j] == indeks){
                    studenti.push(podaciSpisakSX[i][0]);
                    if(j == 1){
                        ocjena.push('A');
                    }
                    else if(j == 2){
                        ocjena.push('B');
                    }
                    else if(j == 3){
                        ocjena.push('C');
                    }
                    else if(j == 4){
                        ocjena.push('D');
                    }
                    else if(j == 5){
                        ocjena.push('E');
                    }
                }
            }
        }
        var studentKomentari = [];
        
        var bool = false;
        var i=0;
        for(i=0; i<studenti.length; i++){
            bool = false;
            var temp = "markS"+ spirala + studenti[i] + ".json";
            for(k=0; k<data.length; k++){
                if(data[k] == temp){
                    bool = true;
                }
            }
            if(bool){
                let rawdata = fs.readFileSync(temp);
                let podaciMarkSX = JSON.parse(rawdata);
                var niz = JSON.parse(podaciMarkSX.sadrzaj);
                for(j=0; j<niz.length; j++){                   
                    if(niz[j].sifra_studenta == ocjena[i]){
                        if(niz[j].text != ""){
                            studentKomentari.push(niz[j].text);
                           
                        }
                        else {
                            studentKomentari.push("\n");
                        }
                    }
                }
            }
        }
        var string = "";
        if(studentKomentari.length != 0){
            for(i=0; i<studentKomentari.length; i++){
                if(i < studentKomentari.length-1){
                    if(studentKomentari[i] != "\n")
                        string += studentKomentari[i] + "\n" + "##########" + "\n";
                    else
                        string += "\n" + "##########" + "\n";
                }
                else {
                    if(studentKomentari[i] != "\n")
                        string += studentKomentari[i] + "\n" + "##########";
                    else
                        string += "\n" + "##########";
                }
            }
            fs.writeFile("izvjestajS" + spirala + indeks + ".txt", string, function(err){
                if(err) throw err; 
                
            });
            var te = __dirname + '/izvjestajS' + spirala + indeks + '.txt';
            res.download(te, te);
        }  
        var te = __dirname + '/izvjestajS' + spirala + indeks + '.txt';
        res.download(te, te);
    });
  
});
app.post('/bodovi', function(req,res){
    let tijelo = xssFilters.inHTMLData(req.body['nesto']);
    tijelo = JSON.parse(tijelo);
    fs.readdir(__dirname, function(err, data){
        var naziv = "spisakS" + tijelo["spirala"] + ".json";
        var treba = "";
        for(i=0; i<data.length; i++){
            if(data[i] == naziv){
                treba = data[i];
                break;
            }
        }
        let rawdata = fs.readFileSync(treba);
        let podaciSpisakSX = JSON.parse(rawdata);
        var indeks = tijelo["index"];
        var spirala = tijelo["spirala"];
        var studenti = [];
        var ocjena = [];
        for(i=0; i<podaciSpisakSX.length; i++){
            for(j=1; j<podaciSpisakSX[i].length; j++){
                if(podaciSpisakSX[i][j] == indeks){
                    studenti.push(podaciSpisakSX[i][0]);
                    if(j == 1){
                        ocjena.push('A');
                    }
                    else if(j == 2){
                        ocjena.push('B');
                    }
                    else if(j == 3){
                        ocjena.push('C');
                    }
                    else if(j == 4){
                        ocjena.push('D');
                    }
                    else if(j == 5){
                        ocjena.push('E');
                    }
                }
            }
        }
        var prosjek = 0;
        for(i=0; i<studenti.length; i++){
            var temp = "markS"+ spirala + studenti[i] + ".json";
            let rawdata = fs.readFileSync(temp);
            let podaciMarkSX = JSON.parse(rawdata);
            var niz = JSON.parse(podaciMarkSX.sadrzaj);
            for(j=0; j<niz.length; j++){
                if(niz[j].sifra_studenta == ocjena[i]){
                    prosjek += parseInt(niz[j].ocjena);
                    break;
                }
            }
        }
        if(prosjek == parseInt(prosjek/studenti.length)){
            prosjek = parseInt(prosjek/studenti.length);
        }
        else {
            prosjek = parseInt(prosjek/studenti.length) + 1;
        }
        res.json({"poruka":"Student " + indeks + " je ostvario u prosjeku " + prosjek + " mjesto."});
    });
});
// Spirala 4
const sequelize = new Sequelize('mysql://root:admin@localhost:3001/spirala4');

const korisnik = sequelize.define('korisnik', {
    korisnicko_Ime: {
            type: Sequelize.STRING,
        },
        sifra: {
            type: Sequelize.STRING,
        },
        idRole: {
            type: Sequelize.INTEGER,
        }
});
const licniPodaci = sequelize.define('licniPodaci', {
    ime_i_prezime: {
        type: Sequelize.STRING,
    },
    akademska_godina: {
        type: Sequelize.STRING,
    },
    fakultetski_mail: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null
    },
    maksimalni_broj_grupa: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null
    },
    regex_validacija: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null
    },
    trenutni_semestar: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null
    },    
    broj_indeksa: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null
    },
    broj_grupe: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: null
    },
    bitbucket_url: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null
    },
    bitbucket_ssh: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null
    },
    naziv_repozitorija: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: null
    },
    verified: {
        type: Sequelize.BOOLEAN,
        allowNull: true,
        defaultValue: null
    },
    idkorisnika: {
        type: Sequelize.INTEGER
    }
});
const role = sequelize.define('role', {
    naziv: {
        type: Sequelize.STRING,
    }
});
sequelize.sync();
const saltRounds = 10;
app.post('/provjeriBazu', function(req,res){
    let tijelo1 = xssFilters.inHTMLData(req.body['nesto']);
    let tijelo2 = xssFilters.inHTMLData(req.body['pass']);
    var salt = bcrypt.genSaltSync(saltRounds);
    var hash = bcrypt.hashSync(tijelo2, salt);
    //role.create({naziv:"student"});
    //role.create({naziv:"nastavnik"});
    //role.create({naziv:"administrator"}); 
    var bool = false;
    korisnik.findOne({where:{korisnicko_Ime:tijelo1}}).then(function(zapisKorisnik){
        if(zapisKorisnik != null)
            if(bcrypt.compareSync(tijelo2, zapisKorisnik.dataValues.sifra)){
                role.findOne({where:{id:zapisKorisnik.dataValues.idRole}}).then(function(zapisRola){

                    if(zapisRola.dataValues.naziv == "student"){
                        req.session.rola = "student";
                        req.session.save();
                    }
                    else if(zapisRola.dataValues.naziv == "nastavnik"){
                        req.session.rola = "";
                        licniPodaci.findOne({where:{idkorisnika: zapisKorisnik.dataValues.id}}).then(function(zapisLicni){
                            if(!zapisLicni.dataValues.verified){
                                bool = true;
                            }
                            else if(zapisLicni.dataValues.verified){
                                req.session.rola = "nastavnik";
                            }
                        });
                        req.session.save();
                    }
                    else if(zapisRola.dataValues.naziv == "administrator"){
                        req.session.rola = "administrator";
                        req.session.save();
                    }
                });
            }  
    }); 
    setTimeout(function(){ 
        if(!bool){
            res.end(req.session.rola);
        }
        else if(bool){
            res.end("NOK"); 
        }
    }, 500); 
});
app.post('/registrujNastavnika', function(req,res){
    let tijelo = xssFilters.inHTMLData(req.body['nastavnik']);
    var podaci = JSON.parse(tijelo);
    var salt = bcrypt.genSaltSync(saltRounds);
    var hash = bcrypt.hashSync(podaci.sifra, salt);
    korisnik.create({korisnicko_Ime: podaci.korisnickoIme, sifra: hash, idRole: 2});
    setTimeout( function() { 
        korisnik.findOne({where:{korisnicko_Ime:podaci.korisnickoIme}}).then(function(zapisKorisnik){
            if(zapisKorisnik.dataValues.korisnicko_Ime == podaci.korisnickoIme){
                licniPodaci.create({
                ime_i_prezime: podaci.imeprezime, 
                akademska_godina: podaci.trenutnaAkGod,
                fakultetski_mail: podaci.fakultetskimail,
                maksimalni_broj_grupa: podaci.maksbrojgrupa,
                trenutni_semestar: podaci.trenutnisem,
                regex_validacija: podaci.regval,
                verified: false,
                idkorisnika: zapisKorisnik.dataValues.id
                });
            }
    }); }, 1000);
    res.end("OK");
});
app.post('/registrujStudenta', function(req,res){
    let tijelo = xssFilters.inHTMLData(req.body['student']);
    var podaci = JSON.parse(tijelo);
    var salt = bcrypt.genSaltSync(saltRounds);
    var hash = bcrypt.hashSync(podaci.sifra, salt);
    korisnik.create({korisnicko_Ime: podaci.korisnickoIme, sifra: hash, idRole: 1});
    setTimeout( function() { 
        korisnik.findOne({where:{korisnicko_Ime:podaci.korisnickoIme}}).then(function(zapisKorisnik){
            if(zapisKorisnik.dataValues.korisnicko_Ime == podaci.korisnickoIme){
                licniPodaci.create({
                    ime_i_prezime: podaci.imeprezime,
                    akademska_godina: podaci.AkGod,
                    broj_grupe: podaci.brojgrupe,
                    broj_indeksa: podaci.brojindeksa,
                    bitbucket_url: podaci.bibucketURL,
                    bitbucket_ssh: podaci.bitbucketSSH,
                    naziv_repozitorija: podaci.nazivrep,
                    idkorisnika: zapisKorisnik.dataValues.id
                });
            }
    }); }, 1000);
    res.end("OK");
});
app.post('/provjeriKorisnicko', function(req,res){
    let tijelo1 = xssFilters.inHTMLData(req.body['korisnicko']);
    var imalga = false;
    var ispravno = false;
    korisnik.findOne({where:{korisnicko_Ime:tijelo1}}).then(function(zapisKorisnik){
        if(zapisKorisnik != null){
            imalga = true;
            ispravno = true;
        }
        else if(zapisKorisnik == null){
            imalga = false;
            ispravno = true;
        }
    });
    setTimeout(function(){
        if(!imalga && ispravno)
            res.end("OK");
        else if (imalga && ispravno)
            res.end("NOK");
    }, 500);
});
app.listen(3000);