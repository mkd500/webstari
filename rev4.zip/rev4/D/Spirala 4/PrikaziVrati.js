function PrikaziNast(id,konto,left,right1){
    document.getElementById("greska").innerHTML = "";
    var desno = document.getElementById(id);
    var kont= document.getElementById(konto);
    var lijevo = document.getElementById(left);
    var desno1 = document.getElementById(right1);
    desno.style.display='block';
    kont.style.marginTop = '70px';
    kont.style.marginBottom = '70px';
    kont.style.height='850px';
    lijevo.style.display='none';
    desno1.style.display='none';
}
function vratiNast(id,konto,left,right1){
    var desno = document.getElementById(id);
    var kont= document.getElementById(konto);
    var lijevo = document.getElementById(left);
    var desno1 = document.getElementById(right1);
    desno.style.display='none';
    kont.style.height='580px';
    kont.style.marginTop = '0px';
    kont.style.marginBottom = '0px';
    lijevo.style.display='block';
    desno1.style.display='block';
}
function PrikaziStud(id,konto,left,right1){
    var desno2 = document.getElementById(id);
    var kont= document.getElementById(konto);
    var lijevo = document.getElementById(left);
    var desno1 = document.getElementById(right1);
    desno2.style.display='block';
    kont.style.height='850px';
    kont.style.marginTop = '70px';
    kont.style.marginBottom = '70px';
    lijevo.style.display='none';
    desno1.style.display='none';
}
function vratiStud(id,konto,left,right1){
    var desno = document.getElementById(id);
    var kont= document.getElementById(konto);
    var lijevo = document.getElementById(left);
    var desno1 = document.getElementById(right1);
    desno2.style.display='none';
    kont.style.height='580px';
    kont.style.marginTop = '0px';
    kont.style.marginBottom = '0px';
    lijevo.style.display='block';
    desno1.style.display='block';
}