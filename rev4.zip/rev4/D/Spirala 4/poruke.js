var Poruke=(function(){
    var idDivaPoruka;
    var mogucePoruke = ["Email koji ste napisali nije validan fakultetski email.",
                        "Indeks kojeg ste napisali nije validan.",
                        "Nastavna grupa koju ste napisali nije validna.",
                        "Akademska godina koju ste napisali nije validna.",
                        "Sifra nije validna.",
                        "Potvrda sifre i sifra se ne podudaraju.",
                        "Bitbucket URL nije validan.",
                        "Bitbucket SSH nije validan.",
                        "Naziv repozitorija nije validan.",
                        "Ime i prezime nije pravilno uneseno.",
                        "Korisnicko ime vec postoji!",
                        "Korisnicko ime nije uneseno."];
    var porukeZaIspis = [];
    var pomocni = [];
    return {
        ispisiGreske: function(){
            var Ispisi = "";
            for(var i=0; i<porukeZaIspis.length; i++){
                Ispisi += porukeZaIspis[i] + "<br>";
            }
            idDivaPoruka = document.getElementById('greska');
            idDivaPoruka.innerHTML=Ispisi;
        },
        postaviIdDiva: function(iddiva){
            idDivaPoruka = document.getElementById(iddiva);
        },
        dodajPoruku: function(broj){
            if(broj <= mogucePoruke.length-1){
                if(porukeZaIspis.indexOf(mogucePoruke[broj]) == -1){
                    porukeZaIspis.push(mogucePoruke[broj]);
                    pomocni.push(broj);
                }
            }
        },
        ocistiGresku: function(broj){
            var temp = -1;
            for(var i=0; i<pomocni.length; i++){
                 if(pomocni[i] == broj){
                    temp = i;
                    break;
                }
            }
            if(temp != -1){
                porukeZaIspis.splice(temp,1);
                pomocni.splice(temp,1);
            }
        }
    }
    }());
    