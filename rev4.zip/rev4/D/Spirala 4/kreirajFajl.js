var KreirajFajl = (function(){

    var ajax = new XMLHttpRequest(); 

    return {

        kreirajKomentar : function(spirala, index, sadrzaj, fnCallback){
            if(((!(typeof spirala === 'string') && spirala.length < 1)) || (!(typeof index === 'string') && index.length < 1)){
                fnCallback(-1, 'Neispravni parametri');
            }
            var temp = JSON.parse(sadrzaj);
            for(var i=0; i<temp.length; i++){
                if(Object.keys(temp[i]).length != 3 || !("sifra_studenta" in temp[i]) || !("text" in temp[i]) || !("ocjena" in temp[i])){
                    fnCallback(-1, 'Neispravni parametri'); 
                }
            }
            var json = {
                spirala: spirala,
                index: index,
                sadrzaj: sadrzaj
            }
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200)
                    fnCallback(null, ajax.responseText);
                else {
                    fnCallback(ajax.status, ajax.responseText);
                }
            }
            ajax.open("POST", "http://localhost:3000/komentar", true);
            ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");     
            ajax.send("nesto=" + JSON.stringify(json));       
        },
        kreirajListu : function(godina, nizRepozitorija, fnCallback){
            if(((!(typeof godina === 'string') && godina.length < 1)) || nizRepozitorija.length < 1){
                fnCallback(-1, 'Neispravni parametri');
            }
            var json = {
                godina: godina,
                nizRepozitorija: nizRepozitorija
            }
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200)
                    fnCallback(null, ajax.responseText);
                else {
                    fnCallback(ajax.status, ajax.responseText);
                }
            }
            ajax.open("POST", "http://localhost:3000/lista", true);
            ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");     
            ajax.send("nesto=" + JSON.stringify(json));       
        },
        kreirajIzvjestaj : function(spirala, index, fnCallback){
            if(((!(typeof spirala === 'string') && spirala.length < 1)) || (!(typeof index === 'string') && index.length < 1)){
                fnCallback(-1, 'Neispravni parametri');
            }
            var json = {
                spirala: spirala,
                index: index,
            }
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200){
                    fnCallback(null, ajax.responseText);
                }
                else {
                    fnCallback(ajax.status, ajax.responseText);
                }
            }
            ajax.open("POST", "http://localhost:3000/izvjestaj", true);
            ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            ajax.send("nesto=" + JSON.stringify(json));     
        },
        kreirajBodove : function(spirala, index, fnCallback){
            if(((!(typeof spirala === 'string') && spirala.length < 1)) || (!(typeof index === 'string') && index.length < 1)){
                fnCallback(-1, 'Neispravni parametri');
            }
            var json = {
                spirala: spirala,
                index: index,
            }
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200){
                    fnCallback(null, ajax.responseText);
                    
                }
                else {
                    fnCallback(ajax.status, ajax.responseText);
                }
            }
            ajax.open("POST", "http://localhost:3000/bodovi", true);
            ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");     
            ajax.send("nesto=" + JSON.stringify(json));     
        }
    }
})();