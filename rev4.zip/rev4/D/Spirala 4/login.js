function Login(username, password){
    if(username != "" && password != "")
        poziv(username,password,function (err, data){
            if(err != null && data != "NOK"){
                document.getElementById("greska").innerHTML = "";
                otvoriMeni(data);
                return;
            }
            else if(err != null) {
                if(data == "NOK"){
                    document.getElementById("greska").innerHTML = "Nastavnik nije validiran!";
                    return ;
                }
                if(data == "Greska"){
                    document.getElementById("greska").innerHTML = "Greska u Bazi.";
                    return ;
                }
            }
        }); 
}
function poziv(username, password, fnCallback){
    var ajax = new XMLHttpRequest();     
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4 && ajax.status == 200 && ajax.responseText != ""){
            fnCallback("ok", ajax.responseText);
        }
        else {
            fnCallback(null, null);
        }
    }
    ajax.open("POST", "http://localhost:3000/provjeriBazu", true);
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");     
    ajax.send("nesto=" + username + "&pass=" + password);   
}