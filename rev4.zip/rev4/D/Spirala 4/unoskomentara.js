function pripremi(sifra1,sifra2,sifra3,sifra4,sifra5,komentar1,komentar2,komentar3,komentar4,komentar5){
    var red1 = document.getElementById("tr1");
    var red2 = document.getElementById("tr2");
    var red3 = document.getElementById("tr3");
    var red4 = document.getElementById("tr4");
    var red5 = document.getElementById("tr5");
    var temp = {
        sifra_studenta: sifra1,
        text: komentar1,
        ocjena: red1.rowIndex
    }
    var sadrzaj = [];
    sadrzaj.push(temp);
    temp = {
        sifra_studenta: sifra2,
        text: komentar2,
        ocjena: red2.rowIndex
    }
    sadrzaj.push(temp);
    temp = {
        sifra_studenta: sifra3,
        text: komentar3,
        ocjena: red3.rowIndex
    }
    sadrzaj.push(temp);
    temp = {
        sifra_studenta: sifra4,
        text: komentar4,
        ocjena: red4.rowIndex
    }
    sadrzaj.push(temp);
    temp = {
        sifra_studenta: sifra5,
        text: komentar5,
        ocjena: red5.rowIndex
    }
    sadrzaj.push(temp);
    sadrzaj = JSON.stringify(sadrzaj);
    KreirajFajl.kreirajKomentar(document.getElementById("sp").value, document.getElementById("in").value, sadrzaj, function(a,b){});
}