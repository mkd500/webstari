function napraviJSON(){
    var textarea = document.getElementById("text");
    var broj = document.getElementById("broj");
    var potvrdi = document.getElementById("potvrdi");
    var text = textarea.value;
    var niz = text.split('\n');
    var regex = /^\d{5}\,\d{5}\,\d{5}\,\d{5}\,\d{5}\,\d{5}$/;
    if(text.length == 0){
        alert("Neispravan CSV format");
        return;
    }
    for(i=0; i<niz.length; i++){
        var red = niz[i].split(',');
        for(j=0; j<red.length; j++){
            for(k=0; k<red.length; k++){
                if(k==j) k++;
                if(red[j] == red[k]){
                    alert("Neispravan CSV format; red: " + red);
                    return;
                }
            }
        }
        if(!regex.test(niz[i])){
            alert("Neispravan CSV format; red: " + niz[i]);
            return;
        }
    }   
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4 && ajax.status == 200)
            alert(ajax.responseText);
        else {
            
        }
    }
    var test = [];
    for(i=0; i<niz.length; i++){
        test.push(niz[i].split(','));
    }
    ajax.open("POST", "http://localhost:3000/unosSpiska", true);
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send("niz=" + JSON.stringify(test) + "&broj="+ broj.value);

}