function otvoriStranicu(stranica){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4 && ajax.status == 200)
            document.getElementById("kontejner").innerHTML = ajax.responseText;
        if (ajax.readyState == 4 && ajax.status == 404)
            document.getElementById("kontejner").innerHTML = "Greska: nepoznat URL";
    }
    ajax.open("GET", "http://localhost:3000/" + stranica, true);
    ajax.send();
}

function otvoriMeni(meni){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4 && ajax.status == 200)
            document.getElementById("meni").innerHTML = "";
            document.getElementById("meni").innerHTML = ajax.responseText;
        if (ajax.readyState == 4 && ajax.status == 404)
            document.getElementById("meni").innerHTML = "Greska: nepoznat URL";
    }
    ajax.open("GET", "http://localhost:3000/" + meni + "Meni", true);
    ajax.send();
}