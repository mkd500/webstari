var bitbucketApi = (function(){
    var ajax = new XMLHttpRequest();
    return {
        dohvatiAccessToken: function(key, secret, fnCallback){ 
            if(key == null || secret == null) {
                fnCallback(-1,"Key ili secret nisu pravilno proslijeđeni!");
            }  
            ajax.onreadystatechange = function() {
                if (ajax.status == 200)
                    try{
                        fnCallback(null, JSON.parse(ajax.responseText).access_token);
                    } catch(err) {

                    }
                else
                    fnCallback(ajax.status,ajax.responseText);
            }
            ajax.open("POST", "https://bitbucket.org/site/oauth2/access_token", true);
            ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            ajax.setRequestHeader("Authorization", 'Basic ' + btoa(key + ':' + secret));
        	ajax.send("grant_type="+encodeURIComponent("client_credentials"));
        },
        dohvatiRepozitorije: function (token, godina, naziv, branch, fnCallback){
            ajax.onreadystatechange = function(){
                if (ajax.readyState == 4 && ajax.status == 200) {
                    var kontejner = JSON.parse(ajax.responseText);
                    var i;
                    var ssh=[];
                    for(i=0; i<kontejner.values.length;i++){
                        var datum = new Date(kontejner.values[i].created_on);
                        if((datum.getFullYear() == godina || datum.getFullYear() == godina + 1) && naziv.indexOf(kontejner.values[i].name) != -1){
                            bitbucketApi.dohvatiBranch(token,kontejner.values[i].links.branches.href, branch, function(err ,data){
                                if(data == true){
                                    ssh.push('git@bitbucket.org:'+kontejner.values[i].owner.username + '/' + kontejner.values[i].name + '.git');
                                }
                                else if(err != null){
                                    i--;
                                    fnCallback(err, null);
                                }
                            });   
                        }
                    }
                    setTimeout(function(){
                        fnCallback(null, ssh);}, 2000);
                }
                else
                    fnCallback(ajax.status,ajax.responseText);
            }
            ajax.open("GET","https://api.bitbucket.org/2.0/repositories?role=member&pagelen=150");
            ajax.setRequestHeader("Authorization", 'Bearer ' + token);
            ajax.send();         
        },
        dohvatiBranch: function(token, url, naziv, fnCallback){
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200){
                    var bol = false;
                    var kontejner = JSON.parse(ajax.responseText);
                    for(j=0; j<kontejner.values.length; j++){
                        if(kontejner.values[j].name == naziv){
                            bol = true;
                        }
                    }
                    if(bol == true){
                        fnCallback(null, true);
                    }
                    else {
                        fnCallback(null, false);
                    }
                }
                else 
                    fnCallback(ajax.status,ajax.responseText);
            }
            try {
                ajax.open("GET",url);
                ajax.setRequestHeader("Authorization", 'Bearer ' + token);
                ajax.send();

            } catch(err){

            }
        }
    }
})();

