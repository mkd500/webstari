function pripremi3(key, secret, nazivRep, branch, godina){
    var token = "";
    var ssh = [];
    bitbucketApi.dohvatiAccessToken(key, secret, function(err,data){
        if(err == -1){
            
        }
        else if(err == null && data != null){
            token = data;
            bitbucketApi.dohvatiRepozitorije(token,godina, nazivRep,branch, function(err, data){
                if(err != null){
                    
                }
                if(err == null) {
                    ssh = data;
                    KreirajFajl.kreirajListu("2017", ssh, function(err, data){
                        if(err == -1){
                            
                        }
                    });
                }
            });
        }
    });
}