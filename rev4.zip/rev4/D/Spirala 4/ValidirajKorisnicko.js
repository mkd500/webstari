function validirajkorisnicko(korisnickoIme){
    if(korisnickoIme != "")
        temp(korisnickoIme,function (err, data){
            if(err != null){
                Validiraj(data, 10);
                return;
            }
        });
    else
        Validiraj(false, 11);       
}
function temp(korisnickoIme, fnCallback){
    var ajax = new XMLHttpRequest();     
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4 && ajax.status == 200 && ajax.responseText != ""){
            if(ajax.responseText == "OK")
                fnCallback("ok", true);
            else
                fnCallback("ok", false); 
        }
        else {
            fnCallback(null, null);
        }
    }
    ajax.open("POST", "http://localhost:3000/provjeriKorisnicko", true);
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");     
    ajax.send("korisnicko=" + korisnickoIme);   
}