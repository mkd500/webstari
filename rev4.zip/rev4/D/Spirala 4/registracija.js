var Registruj = (function(){
var ajax = new XMLHttpRequest();
return {
    registrujNastavnika: function(imeprezime, korisnickoIme, sifra, fakultetskimail, maksbrojgrupa, regval, trenutnisem, trenutnaAkGod){
        if(document.getElementById("greska").innerHTML == "Uspjesno dodan novi korsinik!" || document.getElementById("greska").innerHTML == "Greska na bazi!")
            document.getElementById("greska").innerHTML == "";
        if(document.getElementById("greska").innerHTML == ""){ 
            var json = {
                imeprezime: imeprezime,
                korisnickoIme: korisnickoIme,
                sifra: sifra,
                fakultetskimail: fakultetskimail,
                maksbrojgrupa: maksbrojgrupa,
                regval: regval,
                trenutnisem: trenutnisem,
                trenutnaAkGod: trenutnaAkGod
            };    
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200){
                    if(ajax.responseText == "OK")
                        document.getElementById("greska").innerHTML = "Uspjesno dodan novi korsinik!";
                }
                if (ajax.readyState == 4 && ajax.status == 404) {
                    document.getElementById("greska").innerHTML = "Greska na bazi!";
                }
            }
            ajax.open("POST", "http://localhost:3000/registrujNastavnika", true);
            ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");     
            ajax.send("nastavnik=" + JSON.stringify(json));
        }
    },
    registrujStudenta: function(imeprezime, korisnickoIme, brojindeksa, brojgrupe, AkGod, sifra, bibucketURL, bitbucketSSH, nazivrep){    
        if(document.getElementById("greska").innerHTML == "Uspjesno dodan novi korsinik!" || document.getElementById("greska").innerHTML == "Greska na bazi!")
            document.getElementById("greska").innerHTML == "";
        if(document.getElementById("greska").innerHTML == ""){ 
            var json = {
                imeprezime: imeprezime,
                korisnickoIme: korisnickoIme,
                brojindeksa: brojindeksa,
                brojgrupe: brojgrupe,
                AkGod: AkGod,
                sifra: sifra,
                bibucketURL: bibucketURL,
                bitbucketSSH: bitbucketSSH,
                nazivrep: nazivrep
            };
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200){
                    if(ajax.responseText == "OK")
                        document.getElementById("greska").innerHTML = "Uspjesno dodan novi korsinik!";
                }
                if (ajax.readyState == 4 && ajax.status == 404) {
                    document.getElementById("greska").innerHTML = "Greska na bazi!";
                }
            }
            ajax.open("POST", "http://localhost:3000/registrujStudenta", true);
            ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");     
            ajax.send("student=" + JSON.stringify(json));
        }
    }
}
}());