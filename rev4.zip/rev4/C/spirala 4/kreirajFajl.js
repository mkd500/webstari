var KreirajFajl =  (function(){
    //16527
    return{
        kreirajBodove:function(spirala,index,fnCallback){
            var ajax=new XMLHttpRequest();
            var x = {
                spiralaKljuc:spirala,
                indexKljuc:index
            };
            
            ajax.onreadystatechange = function(){

                if(x.index.length <1  && x.spirala.length<1){
                    //fnCallback.err=-1;
                    //fnCallback.data="Neispravni parametri";
                    fnCallback(-1,"Neispravni parametri");
            }

                if(ajax.readyState===4 & ajax.status===200){
                  //fnCallback.err = null;
                  //fnCallback.data=ajax.responseText;  
                  fnCallback(null,ajax.responseText);
                }
                if(ajax.readyState===4 ){
                    //fnCallback.err = ajax.status;
                    //fnCallback.data=ajax.responseText; 
                    fnCallback(ajax.status,ajax.responseText); 
                  }
            }


            ajax.open("POST","/bodovi",true);
            ajax.setRequestHeader('Content-Type','application/json');
            ajax.send(JSON.stringify(x));  
        },
        kreirajIzvjestaj:function(spirala,index,fnCallback){
            var ajax=new XMLHttpRequest();
            var x = {
                spiralaKljuc:spirala,
                indexKljuc:index
            };
            
            ajax.onreadystatechange = function(){

                if(x.index.length <1  && x.spirala.length<1){
                    //fnCallback.err=-1;
                    //fnCallback.data="Neispravni parametri";
                    fnCallback(-1,"Neispravni parametri");
            }

                if(ajax.readyState===4 & ajax.status===200){
                  //fnCallback.err = null;
                  //fnCallback.data=ajax.responseText;  
                  fnCallback(null,ajax.responseText);
                }
                if(ajax.readyState===4 ){
                    //fnCallback.err = ajax.status;
                    //fnCallback.data=ajax.responseText;  
                    fnCallback(ajax.status,ajax.responseText);
                  }
            }


            ajax.open("POST","/izvjestaj",true);
            ajax.setRequestHeader('Content-Type','application/json');
            ajax.send(JSON.stringify(x));  
        },
        kreirajListu: function(godina,nizRepozitorija,fnCallback){
            var ajax=new XMLHttpRequest();
            var x = {
                godinaKljuc:godina,
                nizRepozitorijaKljuc:nizRepozitorija
            };
            
            ajax.onreadystatechange = function(){

                if(x.godina.length <1  && x.nizRepozitorija.length<1){
                    //fnCallback.err=-1;
                    //fnCallback.data="Neispravni parametri";
                    fnCallback(-1,"Neispravni parametri");
            }

                if(ajax.readyState===4 & ajax.status===200){
                  //fnCallback.err = null;
                  //fnCallback.data=ajax.responseText;  
                  fnCallback(null,ajax.responseText);
                }
                if(ajax.readyState===4 ){
                    //fnCallback.err = ajax.status;
                    //fnCallback.data=ajax.responseText;  
                    fnCallback(ajax.status,ajax.responseText);
                  }
            }


            ajax.open("POST","/lista",true);
            ajax.setRequestHeader('Content-Type','application/json');
            ajax.send(JSON.stringify(x));
        },
        kreirajKomentar : function(spirala,index,sadrzaj,fnCallback){
            var ajax=new XMLHttpRequest();
            var x = {
                spiralaKljuc:spirala,
                indexKljuc:index,
                sadrzajKljuc:sadrzaj
            };
            
            ajax.onreadystatechange = function(){
                    //Object.keys(sadrzaj)<3 koliko u sadrzaju ima json objekata posto je niz
                if(x.spirala.length <=1 && x.index.length<=1 && Object.prototype.toString.call(sadrzaj) === '[object Array]'
            && Object.keys(sadrzaj)<3 &&!(sadrzaj.hasOwnProperty('sifra_studenta')&&sadrzaj.hasOwnProperty('tekst')&&sadrzaj.hasOwnProperty('ocjena'))){
                //fnCallback.err=-1;
                //fnCallback.data="Neispravni parametri";
                fnCallback(-1,"Neispravni parametri");
                //ZASTO SE IZNAD U IFU ISPITIVALO IZ x zar ne treba ono sto jer serve vratio ?
            }

                if(ajax.readyState==4 & ajax.status==200){
                  //fnCallback.err = null;
                  //fnCallback.data=ajax.responseText;  
                  fnCallback(null,ajax.responseText);
                }
                if(ajax.readyState<4 ){
                    //fnCallback.err = ajax.status;
                    //fnCallback.data=ajax.responseText;  
                    fnCallback(ajax.status,ajax.responseText);
                  }
            }


            ajax.open("POST","/komentar",true);
            ajax.setRequestHeader('Content-Type','application/json');
            ajax.send(JSON.stringify(x));
            
        }
    }
})();


