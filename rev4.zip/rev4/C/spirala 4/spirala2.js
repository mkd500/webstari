var Validacija=(function(){
var maxGrupa=7;
var trenutniSemestar=0;//0 za zimski, 1 za ljetni semestar

return{
	
	validirajFakultetski(email){
		var reg = /^\d*[a-z]{1,}\d*\@etf.unsa.ba/;
		return reg.test(email);
	},
	
	
	validirajIndex(index){
		var reg =/^1\d{4}$/;
		return reg.test(index);
		
	},
	
	validirajGrupu(grupa){
	return (grupa>=0 && grupa<maxGrupa+1);
	},
	
	validirajAkGod(godina){
		//zbog automatske konverzije 0 je false 1 je true..
		var tmpGodine = godina.split("/");
		var prviDio = tmpGodine[0];
		var drugiDio = tmpGodine[1];
		var reg = /^\d{4}\/\d{4}$/;
		
		
		if(reg.test(godina)&&!trenutniSemestar){
			var vrijednost = new Date().getFullYear()==parseInt(prviDio) ;
			var vrijednost2 = parseInt(drugiDio)==parseInt(prviDio)+1;
			return vrijednost&&vrijednost2;
		}
		
		if(reg.test(godina)&&trenutniSemestar){
			return  new Date().getFullYear()==parseInt(drugiDio)&& parseInt(drugiDio)==parseInt(prviDio)+1;
		}
		
			//ako nije do sad vratio nista znaci da nesto nije uredu sa stringom
			return false;
	},
	validirajPassword(sifra){
		var imaVeliko=false;
		var imaMalo=false;
		var imaBroj=false;
		
		var regVeliko = /[A-Z]/;
		var regMalo =/[a-z]/;
		var regBroj = /[0-9]/;
		
		var niz = sifra.split("");
		for(var i=0; i<niz.length;i++){
			if(regVeliko.test(niz[i]))imaVeliko=true;
			if(regMalo.test(niz[i]))imaMalo=true;
			if(regBroj.test(niz[i]))imaBroj=true;
		}
		if(niz.length>20&&niz.length<7) return false;
		
		return (imaVeliko&&imaMalo&&imaBroj);
	},
	validirajPotvrdu(sifra1,sifra2){
		return Validacija.validirajPassword(sifra1) &&Validacija.validirajPassword(sifra2)&&sifra1==sifra2;
		
		
	},
	//^https:\/\/\w+\@\w+\.org\/\w+\/\w+\.git$
	validirajBitbucketURL(urlLink){
		validanLink = /^https:\/\/\w+\@\w+\.org\/\w+\/\w+\.git$/;
		if(!validanLink.test(urlLink)) return false;
		//https://aomerovic2@bitbucket.org/aomerovic2/wtprojekat16527.git
		var niz = urlLink.split("/");
		//wtprojekat16527.git
		var tmpNaziv = niz[4];
		var nazivRepa = tmpNaziv.split(".");
		//u js varijabla moze promjeniti tip bilo kad bilo gdje..
		nazivRepa=nazivRepa[0];
		if(!Validacija().validirajNazivRepozitorija(null,nazivRepa)) return false;

		return true;
		
	},
	//git@bitbucket.org:aomerovic2/wtprojekat16527.git
	validirajBitbucketSSH(urlSSH){
		validanSSH=/git@bitbucket.org:\w+\/\w+\.git/;
		if(!validanSSH.test(urlSSH)) return false;
		
		var niz = urlSSH.split("/");
		//wtprojekat16527.git
		var tmpNaziv = niz[1];
		var nazivRepa = tmpNaziv.split(".");
		//u js varijabla moze promjeniti tip bilo kad bilo gdje..
		nazivRepa=nazivRepa[0];
		if(!Validacija().validirajNazivRepozitorija(null,nazivRepa)) return false;

		return true;


	},
	validirajNazivRepozitorija(regex,imeRepa){
		var regTmp = /^wt[Pp]rojekat\d{5}$/;
		if(regex == null) return regTmp.test(imeRepa);
		return regex.test(imeRepa);
	},
	validirajImeiPrezime(imePrezime){
		var regZnak  =/^([^-']\w+)/;
		var neSmijeBiti = /[^\d\/\\\.\*\n\r\-\_\t\s\:\;]/;
		if(!regZnak.test(imePrezime)) return false;
		var tmp1 = imePrezime.split("-");
		
		var tmpImePrezime ="";
		for (var i=0; i<tmp1.length; i++){
			tmpImePrezime+=tmp1[i].split("'").join("");
		}

		if (tmpImePrezime.length<3|tmpImePrezime.length>12) return false;

		var tmp2=tmpImePrezime.split("");

		for(var j=0; j<tmp2.length;j++)
			if(!neSmijeBiti.test(tmp2[j])) return false;
		
			
		
		 return true;
	},
	postaviMaxGrupa(novaGrupa){
		maxGrupa=novaGrupa;
	},
	postaviTrenSemestar(noviSemestar){
		trenutniSemestar = noviSemestar;
	}

}
})();
//console.log(Validacija().validirajImeiPrezime("-HarisPalics"));
