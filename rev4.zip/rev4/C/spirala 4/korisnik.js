const Sequelize = require("sequelize");

module.exports = function(sequelize,DataTypes){
    const Korisnik = sequelize.define("korisnik",{
        username:Sequelize.STRING,
        password:Sequelize.STRING,
        id_role:Sequelize.INTEGER,
        verified:Sequelize.BOOLEAN
    })
    return Korisnik;
};
