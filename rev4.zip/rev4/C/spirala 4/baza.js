const Sequelize = require("sequelize");
const sequelize = new Sequelize('spirala4', 'root', '', {
    host: 'localhost',
    dialect: 'mysql',
    pool: {
      max: 10,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  });

  const db={};
  db.Sequelize = Sequelize;  
  db.sequelize = sequelize;

  db.korisnik = sequelize.import(__dirname+'/korisnik.js');
  db.role = sequelize.import(__dirname+'/rola.js');
  db.licniPodaci = sequelize.import(__dirname+'/licniPodaci.js');
  //db.biblioteka = sequelize.import(__dirname+'/biblioteka.js');

  //db.role.hasOne(db.korisnik,{foreignKey:'id_role'}); ili
  db.korisnik.belongsTo(db.role,{foreignKey:'id_role'});
  db.korisnik.belongsTo(db.licniPodaci,{foreignKey:'id_licniPodaci'});

module.exports = db;