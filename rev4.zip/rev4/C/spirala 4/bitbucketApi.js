import { urlencoded } from "../../../../AppData/Local/Microsoft/TypeScript/2.6/node_modules/@types/express";
import { posix } from "path";
//ovo gore iznad nisam pisao samo se generiralo..
var BitbucketApi = (function(){
    return{
        dohvatiAccessToken: function(key,secret,fnCallback){
               
                    var ajax = new XMLHttpRequest();

                    ajax.onreadystatechange = function(){
                        if(ajax.readyState ===4 && ajax.status ===200){
                                if(key == null || secret == null){
                                    //fnCallback.error=-1;
                                    //fnCallback.data="Key ili secret nisu pravilno raspoređeni";
                                    fnCallback(-1,"Key ili secret nisu pravilno raspoređeni");
                                    return;
                                }

                            //fnCallback.error=null;
                            //fnCallback.data=JSON.parse(ajax.responseText).access_token;
                            fnCallback(null,JSON.parse(ajax.responseText).access_token);
                            
                        }
                        //proslijedi(null,JSON.parse(ajax.responseText))

                        if(ajax.readyState===4 &&ajax.status!=200){
                            //fnCallback.error=ajax.status;
                            //fnCallback.data=null;
                            fnCallback(ajax.status,null);

                        }
                         
                    }
                    
                
                    ajax.open("POST","https://bitbucket.org/site/oauth2/access_token",true);
                    ajax.setRequestHeader("Content-Tyoe", "application/x-www-form-urlencoded");
                    ajax.setRequestHeader("Authorization","Basic "+btoa(key+':'+secret));
                    ajax.send('grant_type='+encodeURIComponent('client_credentials'));

        },
        dohvatiRepozitorije:function(token,godina,naziv,branch,fnCallback){

            var ajax = new XMLHttpRequest();
            
            ajax.onreadystatechange = function(){
                if(ajax.readyState===4 && ajax.status===200){
                    //fnCallback.error=null;
                    //fnCallback.data=ajax.responseText;
                    //kako se trazi niz SSH adresa repozitorija a sa ajax.responseText dobijemo neki veliki JSON objekat potrebo je iz njega dobaviti ove informacije
                    var tmpJSON = JSON.parse(ajax.responseText).values;
                    var tmpNizSSH =[];
                    //dobavi niz
                    for(let i =0; i<tmpJSON.length; i++){
                            tmpNizSSH.push(JSON.stringify(tmpJSON[i].links.clone[1].href));
                    }

                    //ne znam jel se sad treba ovaj niz pretvarat u nesto ? 
                    //fnCallback.data = tmpNizSSH;
                    fnCallback(null,tmpNizSSH);
                }
                if(ajax.readyState===4 && ajax.status!=200){
                    //fnCallback.error=ajax.status;
                    //fnCallback.data=null;
                    fnCallback(ajax.status,null);
                }
            }
            
            
            var tmpGodina = new Date(Parseint(godina),01,01,00,00,00,00);
            var tmpNarednaGodina = new Date(Parseint(godina)+1,12,30,24,59,59,00);

            var tmpName = encodeURIComponent('"'+name+'"');
            var tmpBranch = encodeURIComponent('"'+branch+'"');
            var tmpNaredniDatum = encodeURIComponent(tmpNarednaGodina.toDateString);
            var tmpDatum = encodeURIComponent(tmpGodina.toString);
            //encodeURI ( je %28, a ) je %29, = je %3D
            
            //name~name AND (reated_on (datetime) OR created_on (datetime+1)) AND branch!=source.branch.name
            //var query ="?q=name~"+name+"AND"+"created_on("+tmpGodina+")";
            //treba enkodirat ove zagrade != = itd..
            //var query = '?q=name'+tmpName+'AND'+'(created_on>='+tmpDatum+'OR'+'reated_on<='+tmpNaredniDatum+')'+'AND'+'source.branch.name!='+tmpBranch;
           //var query = '?q=name~'+name+'+AND+'+'(created_on>='+tmpGodina+'+OR+'+'reated_on<='+tmpNaredniDatum+')'+'+AND+'+'source.branch.name!='+branch;
           var query ='&pagelen=150'+ '&q=name~'+tmpName+'+AND+'+'%28created_on%3E%3D'+tmpGodina+'+OR+'+'created_on%3C%3D'+tmpNaredniDatum+'%29'+'+AND+'+'source.branch.name%21%3D'+tmpBranch;

            ajax.open("GET","https://api.bitbucket.org/2.0/repositories?role=member"+query,false);
            ajax.setRequestHeader("Authorization", 'Bearer ' + token);
            ajax.send();
        },
        dohvatiBranch:function(token,url,naziv,fnCallback){

           var ajax = new XMLHttpRequest(); 

           ajax.onreadystatechange= function(){

            var tmpJSON = JSON.parse(ajax.responseText).values;

            if(ajax.readyState==4 && ajax.status ==200 ){
                //fnCallback.error=null;
               // fnCallback.data=false;
               var postoji = false;
                
                for(let i = 0; i<tmpJSON.length; i++){
                    if(tmpJSON[i].links.branches.href===naziv){
                        //fnCallback.data = true;
                        fnCallback(null,true);
                        postoji=true;
                        break;
                    }
                }

                if(!postoji) fnCallback(null,false);
            }

            if(ajax.readyState<4 && ajax.status!=200){
                //fnCallback.error=ajax.status;
                //fnCallback.data=null;
                fnCallback(ajax.status,null);
            }

           }

           ajax.open('GET',url,true);
           ajax.setRequestHeader("Authorization", 'Bearer ' + token);
           ajax.send();
        }
    }
})();