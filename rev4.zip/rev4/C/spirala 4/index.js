//za administratora username:adnan, pw: adnan
const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');
const csv = require("csvtojson");
const _ = require('underscore');
var db = require('./baza.js');
//spirala4
//const Sequelize = require('sequelize');
//const sequelize = require('./baza.js');
//const korisnik = sequelize.import(__dirname+"/korisnik.js");
//const rola = sequelize.import(__dirname+"/rola.js");
const bcrypt = require('bcrypt');
const session = require('express-session');

db.sequelize.sync({force:true}).then(function(){
    inicializacija();
    console.log("baza i tabele kreirane");
    //process.exit();
});

const app = express();

//app.use(express.static('css'));//da moze ucitat css fajlove vezane za taj html
app.use(express.static('public'));//da umjesto index bude neka druga po defaultu stranica,{index:'index.html'}
app.use(express.static('public/css'));
app.use(express.static(__dirname));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(session({
    secret: 'adpkasdasd904s45s4dasd',//ovo treba biti zasticeno tako je je tesko doci, nejbolje koristiti gore iznad vec ukljuceni bcrypt
    resave: true,
    saveUninitialized: true
 }));

 function inicializacija(){ 
    db.role.create({rola:'administrator'}).then(function(k){
    });

    db.role.create({rola:'nastavnik'}).then(function(k){
    });

    db.role.create({rola:'student'}).then(function(k){
    });
            //pw hesirano adnan za sve ..
    db.korisnik.create({username:'adnan',password:'$2a$10$gcf4ksH3i8/4ROtxoIhItOurP3t5CJSbtZCoaqn.dAHb6toCTe1dq',id_role:1}).then(function(){
        db.korisnik.create({username:'aida',password:'$2a$10$gcf4ksH3i8/4ROtxoIhItOurP3t5CJSbtZCoaqn.dAHb6toCTe1dq',id_role:2,verified:true}).then(function(){
            db.korisnik.create({username:'haris',password:'$2a$10$gcf4ksH3i8/4ROtxoIhItOurP3t5CJSbtZCoaqn.dAHb6toCTe1dq',id_role:3});
        });
    });
    
   

 }


    app.post('/registrujNastavnika',function(req,res){
        

         bcrypt.hash(req.body.password, 10, function(err, hash) {
        
                db.licniPodaci.create({
                    ime_i_prezime: req.body.ime_i_prezime,
                    korisnicko_ime:req.body.korisnicko_ime,
                    email: req.body.email,
                    grupa: req.body.grupa,
                    ssh: req.body.ssh,
                    url: req.body.url,
                    semestar: req.body.semestar,
                    godina: req.body.godina,
                    index: req.body.index,
                    regex: req.body.regex,
                    nazivRepozitorija: req.body.nazivRepozitorija,
                    max_broj_grupa: req.body.max_broj_grupa 
                      
                }).then(function(ubaceniRed){

                    db.korisnik.create({
                        username:req.body.korisnicko_ime, 
                        password:hash,
                        id_role:2,
                        id_licniPodaci:ubaceniRed.dataValues.id
                    }).then(function(ubaceniKorisnik){
                         res.status(200).send('dodan');
                    })
                }
            );
      });

      
});

app.post('/registrujStudenta',function(req,res){
        

    bcrypt.hash(req.body.password, 10, function(err, hash) {
   
           db.licniPodaci.create({
               ime_i_prezime: req.body.ime_i_prezime,
               korisnicko_ime:req.body.korisnicko_ime,
               email: req.body.email,
               grupa: req.body.grupa,
               ssh: req.body.ssh,
               url: req.body.url,
               semestar: req.body.semestar,
               godina: req.body.godina,
               index: req.body.index,
               regex: req.body.regex,
               nazivRepozitorija: req.body.nazivRepozitorija,
               max_broj_grupa: req.body.max_broj_grupa 
                 
           }).then(function(ubaceniRed){

               db.korisnik.create({
                   username:req.body.korisnicko_ime, 
                   password:hash,
                   id_role:3,//3 je student, 2 je nastavnik,1 admin
                   id_licniPodaci:ubaceniRed.dataValues.id
               }).then(function(ubaceniKorisnik){
                    res.status(200).send('dodan');
               })
           }
       );
 });
 
});



app.get('/dajSveKorisnike',function(req,res){
    if(req.session.role=='administrator'){
        db.korisnik.findAll().then(sviKorisnici => {
            //sviKorisnici je neki niz tako da ovdje treba for petlja..
            let tmpNiz =[];
            let tmpData;

            for(let i=0; i<sviKorisnici.length; i++){
                tmpData={
                    username:sviKorisnici[i].username,
                    verified:sviKorisnici[i].verified,
                    id_role:sviKorisnici[i].id_role
                };

                tmpNiz.push(tmpData);
            }
            console.log(tmpData);
           
    
            res.writeHead(200,{'Content-type': 'application/json'});
            res.end(JSON.stringify( tmpNiz));
            
          })
    }else res.status(401).end('<a href="index.html"> nemate pristup</a>');
    
});

app.post('/pretraga',function(req,res){
    if(req.session.role=='administrator'){
        db.korisnik.findAll({
            where: {username: req.body.korisnicko_ime}
        }).then(sviKorisnici => {
            //sviKorisnici je neki niz tako da ovdje treba for petlja..
            let tmpNiz =[];
            let tmpData;

            for(let i=0; i<sviKorisnici.length; i++){
                tmpData={
                    username:sviKorisnici[i].username,
                    verified:sviKorisnici[i].verified,
                    id_role:sviKorisnici[i].id_role
                };

                tmpNiz.push(tmpData);
            }
            console.log(tmpData);
           
    
            res.writeHead(200,{'Content-type': 'application/json'});
            res.end(JSON.stringify( tmpNiz));
            
          })
    }else res.status(401).end('<a href="index.html"> nemate pristup</a>');
    
});

app.post('/verify',function(req,res){
    if(req.session.role=='administrator'){
     
          
        db.korisnik.update(
            {verified: true },
          
            { where: { username: req.body.korisnicko_ime } }
          )
            .then(result =>{
                res.status(200).end('verifikacija uspjesna, rezulatat ='+result);
            }
                
            )
            .catch(err =>{
                res.status(401).end(err);
            }
               
            ) 


    }else res.status(401).end('<a href="index.html"> nemate pristup</a>');
    
});

app.post('/unverify',function(req,res){
    if(req.session.role=='administrator'){

        
          db.korisnik.update(
            {verified: false },
          
            { where: { username: req.body.korisnicko_ime } }
          )
            .then(result =>{
                res.status(200).end('un-verifikacija uspjesna, rezulatat ='+result);
            }
                
            )
            .catch(err =>{
                res.status(401).end(err);
            }
               
            ) 



    }else res.status(401).end('<a href="index.html"> nemate pristup</a>');
    
});




//SPIRALA 4
app.post('/korisnik',function(req,res){
   // if(req.body.email.length ==0) return;

   // res.redirect('/student');
    let kriptovaniPW;

    bcrypt.hash(req.body.password, 10, function(err, hash) {
        // Store hash in database
        kriptovaniPW=hash;
        db.korisnik.findAll({
            //email je unikat, pa cemo provjeriti samo hesirane passworde..
            where: {username: req.body.email},
            attributes: ['id_role','username', 'password','verified']
        }).then(korisnici => {
            if(korisnici===null){console.log('nema Korisnika'); return;}

            if(!korisnici[0].dataValues.verified &&korisnici[0].dataValues.id_role ==2) {
             res.status(404).end('<a href="index.html"> nemate pristup</a>');
                    //res.redirect('/unosSpiska');
                return;
            }


                //sad cemo provjeriti pw
               
                bcrypt.compare(req.body.password, korisnici[0].dataValues.password, function(err, resH) {
                    if(resH) {
                        //posto je sifra ok, treba mu dodijeliti sesiju i unutar sesije upisati rolu ( nastavnik,admin, student)
                         
                    db.role.findAll({
                        where:{id:korisnici[0].dataValues.id_role},
                        attributes:['rola']
                   }).then(rolaT =>{
                   //ovdje dodamo koje ce opcije imati u sesiji i redirektat cemo ga na odgovarajuci index.html
                       

                        switch(rolaT[0].dataValues.rola){
                            case 'administrator':
                                req.session.role = rolaT[0].dataValues.rola;//
                                fs.readFile(__dirname+'/public/listaKorisnika.html','utf8',function(err,data){
                                    if(err) throw err;

                                    let tmpData ={
                                        rola:'administrator',
                                        stranica:data

                                    };

                                    res.writeHead(200,{'Content-type': 'application/json'});
                                    res.end(JSON.stringify( tmpData));
                                });
                               // res.redirect('/administrator');
                            break;
                            case 'nastavnik':
                                req.session.role = rolaT[0].dataValues.rola;//
                                fs.readFile(__dirname+'/public/nastavnik.html','utf8',function(err,data){
                                    if(err) throw err;

                                    let tmpData ={
                                        rola:'nastavnik',
                                        stranica:data

                                    };

                                    res.writeHead(200,{'Content-type': 'application/json'});
                                    res.end(JSON.stringify( tmpData));
                                });
                            break;
                            case 'student':
                                req.session.role = rolaT[0].dataValues.rola;//
                                fs.readFile(__dirname+'/public/statistika.html','utf8',function(err,data){
                                    if(err) throw err;

                                    let tmpData ={
                                        rola:'student',
                                        stranica:data

                                    };

                                    res.writeHead(200,{'Content-type': 'application/json'});
                                    res.end(JSON.stringify( tmpData));
                                });
                            break;
                        }

                    }).catch(function(err){
               res.send(err);
           });     
                    
    
            } else {
             // Passwords don't match
             //fulio sifru ili se lazno predstavlja.. treba ga sankcionisati..
             res.redirect('/');
            } 
          });
    
        });
  });

});

/*

app.get('/administrator',function(req,res){
    //document.getElementById('unosSpiska').style.display ='none';
   // res.render('index',{},function)
   //res.sendFile(__dirname+'/public/statistika.html');
   fs.readFile(__dirname+'/public/statistika.html',function(err,data){
    if(err) throw err;
    res.writeHead(200,{'Content-Type':'text/html'});
    res.end(data);
})

});

*/


//SPIRALA 4

app.get('/',function(req,res){
    //console.log(__dirname+'/public/index.html');
    res.sendFile(__dirname+'/public/index.html',function(err){
        if(err) throw err;
    
    });
});

app.get('/listaKorisnika',function(req,res){
    if(req.session.role==='administrator'){

    res.sendFile(__dirname+'/public/listaKorisnika.html',function(err){
        if(err) throw err;
    
    });

    }else{
        //req.session.destroy();
        res.send('error 404');
    }
});

app.get('/statistika',function(req,res){
    //res.sendFile(__dirname+'/public/statistika.html',function(err){
        //if(err) throw err;
        if(req.session.role==='student'){
         fs.readFile(__dirname +'/public/statistika.html',function(err,data){
            if(err) throw err;
             res.writeHead(200,{'Content-Type':'text/html' });
             res.end(data);
         });
        }else{
            //req.session.destroy();
            res.send('error 404');
        }

    });


    app.get('/login',function(req,res){
        fs.readFile(__dirname+'/public/login.html',function(err,data){
            if(err) throw err;
            res.writeHead(200,{'Content-Type':'text/html'});
            res.end(data);
        })
    });

    app.get('/unoskomentara',function(req,res){
        if(req.session.role==='student'){
            fs.readFile(__dirname+'/public/unoskomentara.html',function(err,data){
                if(err) throw err;
                res.writeHead(200,{'Content-Type':'text/html'});
                res.end(data);
            });
        }else{
            //req.session.destroy();
            res.send('error 404');
        }
       
        
    });

    app.get('/unosSpiska',function(req,res){
        if(req.session.role==='nastavnik'){
            fs.readFile(__dirname+'/public/unosSpiska.html',function(err,data){
                if(err) throw err;
                res.writeHead(200,{'Content-Type':'text/html'});
                res.end(data);
            });
        }else{
            //req.session.destroy();
            //res.send('error 404');
            res.status(401).end('<a href="index.html"> nemate pristup</a>');
        }
        
    });

    app.get('/nastavnik',function(req,res){
        if(req.session.role==='nastavnik'){
            fs.readFile(__dirname+'/public/nastavnik.html',function(err,data){
                if(err) throw err;
                res.writeHead(200,{'Content-Type':'text/html'});
                res.end(data);
            })
        }else res.status(401).end('<a href="index.html"> nemate pristup</a>');
        
    });

    app.get('/bitbucketPozivi',function(req,res){
          if(req.session.role==='nastavnik'){
            fs.readFile(__dirname+'/public/bitbucketPozivi.html',function(err,data){
                if(err) throw err;
                res.writeHead(200,{'Content-Type':'text/html'});
                res.end(data);
            })
          }else res.status(401).end('<a href="index.html"> nemate pristup</a>');
        
    });
    

    app.post('/unosSpiskaa',function(req,res){
        
        if(req.session.role==='nastavnik'){

        let saveNizNizova =[];
        let saveNiz=[];

        let tijeloZahtjeva = req.body.textAreaid;
        //let uJSONformatu = JSON.parse(tijeloZahtjeva);
        let tmpNizIndexa = tijeloZahtjeva.split('\n');
        
        let kolonaA=[];
        let kolonaB=[];
        let kolonaC=[];
        let kolonaD=[];
        let kolonaE=[];
        let kolonaX=[];
        //treba provjeriti da li se index ponavlja samo jednom,
        //treba biti tacno 6 kolona
        for(let i=0; i<tmpNizIndexa.length; i++){
            let tmpIndexi = tmpNizIndexa[i].split(',');

            saveNiz=[];
           
            if(tmpIndexi.length!=6) 
             {
                 //res.send(500,'neispravan format');
                 res.writeHead(200,{'Content-Type':'application/json;charset=utf8'});
                 res.end(JSON.stringify({poruka:'neispravan format'})); 
                 return;
                 
                }
            //=== provjerava i po tipu i po vrijednosti..
            for(let j=0; j<6;j++){

                
                for(let k=j+1; k<6; k++)
                if(tmpIndexi[j]===tmpIndexi[k]) 
                  { 
                      //res.send(500,'red '+i.toString+' nema sve razlicite indexe'); 
                      res.writeHead(200,{'Content-Type':'application/json;charset=utf8'});
                      res.end(JSON.stringify({poruka:'red '+(i+1).toString()+' nema sve razlicite indexe'}));
                      return;
                    }

                  switch(j){
                    case 0:kolonaX.push(tmpIndexi[j]);
                    break;
                    case 1:kolonaA.push(tmpIndexi[j]);
                    break;
                    case 2:kolonaB.push(tmpIndexi[j]);
                    break;
                    case 3:kolonaC.push(tmpIndexi[j]);
                    break;
                    case 4:kolonaD.push(tmpIndexi[j]);
                    break;
                    case 5:kolonaE.push(tmpIndexi[j]);
                    break;
                    default:
                }
                    
                saveNiz.push(tmpIndexi[j]);
            }
            saveNizNizova.push(saveNiz);
              
        }
               //ako prezivi dovde onda je sve ok..
              //samo ga trebamo pretvoriti u JSON i sacuvati
              let kljucevi = ['X','A','B','C','D','E'];
              let vrijednost =[kolonaX.join(), kolonaA.join(),kolonaB.join(),kolonaC.join(),kolonaD.join(),kolonaE.join()];

             let tmpSpisak = _.object(kljucevi, vrijednost);
            //ovo iznad je uradjeno po kolonama mislio sam da cu nekako uspjeti iz ovoga dobiti kao sto je trazeno
            //rjesnje je jednostavnije sa saveNiz i saveNizNizova

           // res.end(JSON.stringify({poruka: "Uspjesno dodan red"})); 
           
            
            fs.appendFile('spisakS'+req.body.brojSpirale+'.json',JSON.stringify(saveNizNizova),function(err){
                if(err) throw err;
                //res.json({poruka: "Uspjesno dodan red"});
            }); 
            
            res.writeHead(200,{'Content-Type':'application/json;charset=utf8'});
            res.end(JSON.stringify(tmpSpisak)); 

        }else res.status(401).end('<a href="index.html"> nemate pristup</a>');

    }); 



    app.post('/komentar',function(req,res){

        if(!(req.body.spiralaKljuc.length <=1 && req.body.indexKljuc.length<=1 && Object.prototype.toString.call(req.body.sadrzajKljuc) === '[object Array]'
            && Object.keys(req.body.sadrzajKljuc)<3 &&!(req.body.sadrzajKljuc.hasOwnProperty('sifra_studenta')&&req.body.sadrzajKljuc.hasOwnProperty('tekst')&&req.body.sadrzajKljuc.hasOwnProperty('ocjena')))){


                fs.appendFile(' markS'+req.body.spiralaKljuc+req.body.indexKljuc+'.json'+req.body.brojSpirale+'.json',JSON.stringify(req.body.sadrzajKljuc),function(err){
                    if(err) throw err;
                    //res.json({poruka: "Uspjesno dodan red"});
                }); 

                res.writeHead(200,{'Content-Type':'application/json;charset=utf8'});
                 res.end(JSON.stringify( {'message':'Uspješno kreiranadatoteka!','data': req.body.sadrzajKljuc}));
                 return;
            }
            
            res.writeHead(200,{'Content-Type':'application/json;charset=utf8'});
            res.end(JSON.stringify( {'message':'Podaci nisu u traženom formatu!','data':null}));
    });

    app.post('/lista',function(req,res){
            
        if(req.body.godinaKljuc.length >1  && req.body.nizRepozitorijaKljuc.length>1){
            let izdvojeniRepozitoriji = [];
            for(let i =0; i<req.body.nizRepozitorijaKljuc.length; i++)
                if(req.body.nizRepozitorijaKljuc[i].indexOf(req.body.godinaKljuc.toString())!=-1)
                  izdvojeniRepozitoriji.push(req.body.nizRepozitorijaKljuc[i]+'\n');

            fs.appendFile('spisak'+req.body.godinaKljuc+'.txt',izdvojeniRepozitoriji.toString(),function(err){
                if(err) throw err;
               
            }); 

            res.writeHead(200,{'Content-Type':'application/json;charset=utf8'});
            res.end(JSON.stringify( {'message':'Lista uspjesno kreirana','data':izdvojeniRepozitoriji.length}));

        }else{
            res.writeHead(200,{'Content-Type':'application/json;charset=utf8'});
            res.end(JSON.stringify( {'message':'Podaci nisu u traženom formatu!','data':null}));
    
        }    
        
    });

    //izvjestaj
    app.post('/izvjestaj',function(req,res){

        let procitaniFajlJSON ;
        let index = req.body.indexKljuc;
        let spirala =req.body.spiralaKljuc;
        let SpasiKomentare = [];

        let redImaIndex = false;
        let sifra = '\n';

        fs.readdir(__dirname +'spisakS'+spirala+'.json',function(err,data){
            procitaniFajlJSON = JSON.parse(data);
        });

        for(let i=0; i<procitaniFajlJSON.length; i++){
            let tmpNizIndexa = procitaniFajlJSON[i];
            redImaIndex=false;

            for(let j=1; j<tmpNizIndexa.length/*ili 6 ako je ispravan format*/;j++){

                if(tmpNizIndexa[j]===index){
                    redImaIndex=true;
    
                    switch(j){
                       
                        case 1:sifra = 'A';
                        break;
                        case 2:sifra = 'B';
                        break;
                        case 3:sifra = 'C';
                        break;
                        case 4:sifra = 'D';
                        break;
                        case 5:sifra = 'E';
                        break;
                        default:sifra = '\n'
                    }

                } else sifra = '\n';
             

            } 
            
            if(redImaIndex)
             SpasiKomentare.push('Iz datoteke markS'+spirala+index+'.json pročitamo komentar studenta sa šifrom' +sifra);
            else SpasiKomentare.push(sifra);

            if(i!=procitaniFajlJSON.length-1)
            SpasiKomentare.push('##########');//Komentari trebaju biti odvojeni linijom koja sadrži samo “##########”
              
        }
        //gore iznad smo trazili index, projekti koji su komentarisani su izdvojeni i sad ih treba spasiti

        fs.appendFile('izvjestajS'+spirala+index+'.txt',SpasiKomentare.toString(),function(err){
            if(err) throw err;
             
            });

    });

    app.post('/bodovi',function(req,res){
           let procitaniFajlJSONniz;
           let tmpObjekat;
           let tmpOcjena =0;

           fs.readdir(__dirname +'markS'+spirala+index+'.json',function(err,data){
                     procitaniFajlJSONniz = JSON.parse(data).sadrzaj;
            });

            for(let i=0; i<procitaniFajlJSONniz.length; i++){
                tmpObjekat = procitaniFajlJSONniz[i];
                tmpOcjena=parseInt(tmpObjekat.ocjena,10);
            }
            
        res.writeHead(200,{'Content-Type':'application/json;charset=utf8'}); //moze se dijeliti i sa 5 jer pregleda 5 projekata
        res.end(JSON.stringify(  {'poruka':'Student 12345 je ostvariou prosjeku' +parseInt(tmpOcjena/procitaniFajlJSONniz.length, 10)+ 'mjesto'}));

    });


app.listen(3000);




