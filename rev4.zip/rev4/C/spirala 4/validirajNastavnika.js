function validirajIme() {
	var tmpIme = document.getElementById("ime_prezime_nastavnika");
	if(!Validacija.validirajImeiPrezime(tmpIme.value)){
	var x = document.getElementById("greske");
    x.innerHTML =x.outerHTML+"imePrezime,";
	}
    
}

function validirajPassword() {
	var tmPassword = document.getElementById("password_reg");
	if(!Validacija.validirajPassword(tmPassword.value)){

   var x = document.getElementById("greske");
    x.innerHTML =x.outerHTML+"Password,";
	}
    
}

function potvrdaPassworda() {
	var tmPassword = document.getElementById("password_reg");//c_password
	var tmPasswordConfirm = document.getElementById("c_password");
	
	if(!Validacija.validirajPotvrdu(tmPassword.value,tmPasswordConfirm.value)){

   var x = document.getElementById("greske");
    x.innerHTML =x.outerHTML+"PasswordConfirm,";
	}
}
function potvrdaEmail() {
	var tmpEmail = document.getElementById("email_reg");
	if(!Validacija.validirajFakultetski(tmpEmail.value)){

   var x = document.getElementById("greske");
    x.innerHTML =x.outerHTML+"Email,";
	}
}


function potvrdaGrupa() {
	var tmpGrupa = document.getElementById("max_grupa");
	if(!Validacija.validirajGrupu(tmpGrupa.value)){

   var x = document.getElementById("greske");
    x.innerHTML =x.outerHTML+"Grupa,";
	}
}

function potvrdaSemestra() {
	var tmpSemestar = document.getElementById("trenutni_semestar");
	if(tmpSemestar.value!=0 &&tmpSemestar.value!=1){

   var x = document.getElementById("greske");
    x.innerHTML =x.outerHTML+"Semestar,";
	}
}


function potvrdaAkademske() {
	var tmpAkademska = document.getElementById("akademska_godina");
	if(!Validacija.validirajAkGod(tmpAkademska.value)){

   var x = document.getElementById("greske");
    x.innerHTML =x.outerHTML+"Akademska,";
	}
}

/*ISPOD SLIJEDE FUNKCIJE ZA TESTIRANJE REGISTRACIJE STUDENTA SA FORME*/
/*validacija imena je isto kao i za nastavnika*/
function validirajImeStudenta() {
	var tmpIme = document.getElementById("ime_prezime_studenta");
	if(!Validacija.validirajImeiPrezime(tmpIme.value)){
	var x = document.getElementById("greskeKodStudenta");
    x.innerHTML =x.outerHTML+"imePrezime,";
	}
    
}

function potvrdaIndexa() {
	var tmpIndex = document.getElementById("broj_indexa");
	if(!Validacija.validirajIndex(tmpIndex.value)){

		var x = document.getElementById("greskeKodStudenta");
    x.innerHTML =x.outerHTML+"Index,";
	}
}

function potvrdaGrupaStudenta() {
	var tmpGrupa = document.getElementById("broj_grupe");
	if(!Validacija.validirajGrupu(tmpGrupa.value)){

   var x = document.getElementById("greskeKodStudenta");
    x.innerHTML =x.outerHTML+"Grupa,";
	}
}

function potvrdaAkademskeStudenta() {
	var tmpAkademska = document.getElementById("akademska_godina_studenta");
	if(!Validacija.validirajAkGod(tmpAkademska.value)){

   var x = document.getElementById("greskeKodStudenta");
    x.innerHTML =x.outerHTML+"Akademska,";
	}
}

function validirajPasswordStudenta() {
	var tmPassword = document.getElementById("password_reg_studenta");
	if(!Validacija.validirajPassword(tmPassword.value)){

   var x = document.getElementById("greskeKodStudenta");
    x.innerHTML =x.outerHTML+"Password,";
	}
    
}

function potvrdaPasswordaStuenta() {
	var tmPassword = document.getElementById("password_reg_studenta");//c_password
	var tmPasswordConfirm = document.getElementById("c_password_studenta");
	
	if(!Validacija.validirajPotvrdu(tmPassword.value,tmPasswordConfirm.value)){

   var x = document.getElementById("greskeKodStudenta");
    x.innerHTML =x.outerHTML+"PasswordConfirm,";
	}
}

function potvrdaBitBucketURL() {
	var tmpURL = document.getElementById("bit_bucket_URL");
	if(!Validacija.validirajBitbucketURL(tmpURL.value)){

   var x = document.getElementById("greskeKodStudenta");
    x.innerHTML =x.outerHTML+"Bit bucket URL,";
	}
}

function potvrdaBitBucketSSH() {
	var tmpSSH = document.getElementById("bit_bucket_SSH");
	if(!Validacija.validirajBitbucketSSH(tmpSSH.value)){

   var x = document.getElementById("greskeKodStudenta");
    x.innerHTML =x.outerHTML+"Bit bucket SSH,";
	}
}

function potvrdaNazivRepa() {
	var tmpNaziv = document.getElementById("naziv_repozitorija");
	if(!Validacija.validirajNazivRepozitorija(null,tmpNaziv.value)){

   var x = document.getElementById("greskeKodStudenta");
    x.innerHTML =x.outerHTML+"naziv repa,";
	}
}

function registrujNastavnika(){
	var formNastavnika = document.getElementById("forma_registracija_nastavnika").style.display = "block";
	var fromStudenta = document.getElementById("forma_registracija_studenta").style.display="none";
	formNastavnika.style.display = "block"
	fromStudenta.style.display="none";


	
}



