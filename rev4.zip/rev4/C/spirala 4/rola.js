const Sequelize = require("sequelize");

module.exports = function(sequelize,DataTypes){
    const Role = sequelize.define("role",{
        rola:Sequelize.STRING
    })
    return Role;
};
