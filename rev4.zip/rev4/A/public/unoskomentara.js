function zamijeniIznad(broj) {
	var pozicija=parseInt(broj);
	if (pozicija==1){
		return;
	} else if(pozicija==2) {

		var trenutniK=document.getElementById('komS2').value;
		//var trenutniO=document.getElementById('ocjenaS2').value;
		var trenutniS=document.getElementById('sifra2').innerHTML;
		var trenutniL=document.getElementById('link2').innerHTML;
		var iznadK=document.getElementById('komS1').value;
		//var iznadO=document.getElementById('ocjenaS1').value;
		var iznadS=document.getElementById('sifra1').innerHTML;
		var iznadL=document.getElementById('link1').innerHTML;

		document.getElementById('komS2').value=iznadK;
		document.getElementById('komS1').value=trenutniK;
		//document.getElementById('ocjenaS2').value=iznadO;
		//document.getElementById('ocjenaS1').value=trenutniO;
		document.getElementById('sifra2').innerHTML=iznadS;
		document.getElementById('sifra1').innerHTML=trenutniS;
		document.getElementById('link2').innerHTML=iznadL;
		document.getElementById('link1').innerHTML=trenutniL;

	} else if (pozicija==3) {

		var trenutniK=document.getElementById('komS3').value;
		//var trenutniO=document.getElementById('ocjenaS3').value;
		var trenutniS=document.getElementById('sifra3').innerHTML;
		var trenutniL=document.getElementById('link3').innerHTML;
		var iznadK=document.getElementById('komS2').value;
		//var iznadO=document.getElementById('ocjenaS2').value;
		var iznadS=document.getElementById('sifra2').innerHTML;
		var iznadL=document.getElementById('link2').innerHTML;

		document.getElementById('komS3').value=iznadK;
		document.getElementById('komS2').value=trenutniK;
		//document.getElementById('ocjenaS3').value=iznadO;
		//document.getElementById('ocjenaS2').value=trenutniO;
		document.getElementById('sifra3').innerHTML=iznadS;
		document.getElementById('sifra2').innerHTML=trenutniS;
		document.getElementById('link3').innerHTML=iznadL;
		document.getElementById('link2').innerHTML=trenutniL;

	} else if (pozicija==4) {

		var trenutniK=document.getElementById('komS4').value;
		//var trenutniO=document.getElementById('ocjenaS4').value;
		var trenutniS=document.getElementById('sifra4').innerHTML;
		var trenutniL=document.getElementById('link4').innerHTML;
		var iznadK=document.getElementById('komS3').value;
		//var iznadO=document.getElementById('ocjenaS3').value;
		var iznadS=document.getElementById('sifra3').innerHTML;
		var iznadL=document.getElementById('link3').innerHTML;

		document.getElementById('komS4').value=iznadK;
		document.getElementById('komS3').value=trenutniK;
		//document.getElementById('ocjenaS4').value=iznadO;
		//document.getElementById('ocjenaS3').value=trenutniO;
		document.getElementById('sifra4').innerHTML=iznadS;
		document.getElementById('sifra3').innerHTML=trenutniS;
		document.getElementById('link4').innerHTML=iznadL;
		document.getElementById('link3').innerHTML=trenutniL;

	} else {

		var trenutniK=document.getElementById('komS5').value;
		//var trenutniO=document.getElementById('ocjenaS5').value;
		var trenutniS=document.getElementById('sifra5').innerHTML;
		var trenutniL=document.getElementById('link5').innerHTML;
		var iznadK=document.getElementById('komS4').value;
		//var iznadO=document.getElementById('ocjenaS4').value;
		var iznadS=document.getElementById('sifra4').innerHTML;
		var iznadL=document.getElementById('link4').innerHTML;

		document.getElementById('komS5').value=iznadK;
		document.getElementById('komS4').value=trenutniK;
		//document.getElementById('ocjenaS5').value=iznadO;
		//document.getElementById('ocjenaS4').value=trenutniO;
		document.getElementById('sifra5').innerHTML=iznadS;
		document.getElementById('sifra4').innerHTML=trenutniS;
		document.getElementById('link5').innerHTML=iznadL;
		document.getElementById('link4').innerHTML=trenutniL;

	}
}

function zamijeniIspod(pozicija){
	if (pozicija==5){
		return;
	} else {
		zamijeniIznad(pozicija+1);
	}
}