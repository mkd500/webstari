function showStudent(teacherForm,studentForm) {
    document.getElementById('teacherForm').style.display = "none";
    document.getElementById('studentForm').style.display = "block";
    for(i=0;i<11;i++)
    {
        Poruke.ocistiGresku(i);
    }
    document.getElementById('errorReport').innerHTML="";
}

function showTeacher(teacherForm,studentForm) {
    document.getElementById('teacherForm').style.display = "block";
    document.getElementById('studentForm').style.display = "none";
    for(i=0;i<11;i++)
    {
        Poruke.ocistiGresku(i);
    }
    document.getElementById('errorReport').innerHTML="";
}

function writeMessage(msgNum,validate){
    if(!validate)
    {
        Poruke.dodajPoruku(msgNum);
        Poruke.ispisiGreske();
    }
    else{
        Poruke.ocistiGresku(msgNum);
        Poruke.ispisiGreske();
    }
}

function validateSchoolEmail(schoolEmail){
    var validate=Validacija.validirajFakultetski(document.getElementById('schoolEmail').value);
    var msgNum = 0;
    writeMessage(msgNum,validate);
}

function validateIndexNum(indexNum){
    var validate=Validacija.validirajIndex(document.getElementById('indexNum').value);
    var msgNum = 1;
    writeMessage(msgNum,validate);
}

function validateGroupNumber(groupNum){
    var validate=Validacija.validirajGrupu(document.getElementById('groupNum').value);
    var msgNum = 2;
    writeMessage(msgNum,validate);
}

function validateAcademicYearTeacher(academicYearTeacher){
    var validate=Validacija.validirajAkGod(document.getElementById('academicYearTeacher').value);
    var msgNum = 10;
    writeMessage(msgNum,validate);
}

function validateAcademicYearStudent(academicYearStudent){
    var validate=Validacija.validirajAkGod(document.getElementById('academicYearStudent').value);
    var msgNum = 10;
    writeMessage(msgNum,validate);
}

function validateTeacherPassword(teacherPassword){
    var validate=Validacija.validirajPassword(document.getElementById('teacherPassword').value);
    var msgNum = 6;
    writeMessage(msgNum,validate);
}

function validateStudentPassword(studentPassword){
    var validate=Validacija.validirajPassword(document.getElementById('studentPassword').value);
    var msgNum = 6;
    writeMessage(msgNum,validate);
}

function validateTeacherPasswordConfirm(teacherPassword,teacherPassConfirm){
    var validate=Validacija.validirajPotvrdu(document.getElementById('teacherPassword').value, document.getElementById('teacherPassConfirm').value);
    var msgNum = 7;
    writeMessage(msgNum,validate);
}

function validateStudentPasswordConfirm(studentPassword,studentPassConfirm){
    var validate=Validacija.validirajPotvrdu(document.getElementById('studentPassword').value, document.getElementById('studentPassConfirm').value);
    var msgNum = 7;
    writeMessage(msgNum,validate);
}

function validateBitBucketUrl(bitbucketUrl)
{
    var validate=Validacija.validirajBitbucketURL(document.getElementById('bitbucketUrl').value);
    var msgNum = 3;
    writeMessage(msgNum,validate);
}

function validateBitBucketSSH(bitbucketSSH)
{
    var validate=Validacija.validirajBitbucketSSH(document.getElementById('bitbucketSSH').value);
    var msgNum = 4;
    writeMessage(msgNum,validate);
}

function validateRepositoryName(repositoryRegex,repositoryName)
{
    var validate=Validacija.validirajNazivRepozitorija(document.getElementById('repositoryRegex').value, document.getElementById('repositoryName').value);
    var msgNum = 5;
    writeMessage(msgNum,validate);
}

function validateNameStudent(fullNameStudent)
{
    var validate=Validacija.validirajImeiPrezime(document.getElementById('fullNameStudent').value);
    var msgNum = 8;
    writeMessage(msgNum,validate);
}

function validateNameTeacher(fullNameTeacher)
{
    var validate=Validacija.validirajImeiPrezime(document.getElementById('fullNameTeacher').value);
    var msgNum = 8;
    writeMessage(msgNum,validate);
}

function setErrorDiv(divID)
{
    // console.log(divID)
    Poruke.postaviIdDiva(divID);
}



