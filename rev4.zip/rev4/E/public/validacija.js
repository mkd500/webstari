var Validacija = (function(){
    var maxGrupa=7;
    var trenutniSemestar=0;//0 za zimski, 1 za ljetni semestar

    return{
        validirajFakultetski: function(email){
            var mailRegex = /^[\-\_a-zA-Z\.\d]+@etf\.unsa\.ba/g;
            if(email.match(mailRegex)) {
                console.log("True");
                return true;
            }
            else{
                console.log("False");
                return false;
            }
        },
        validirajIndex: function(indexNum){
            var indexRegex = /^(1)[0-9]{4}$/g;
            if(indexNum.match(indexRegex)) {
                console.log("True");
                return true;
            }
            else{
                console.log("False");
                return false;
            }
        },
        validirajGrupu: function(groupNum){
            if(parseInt(groupNum) > 0 && parseInt(groupNum) <= parseInt(maxGrupa)) {
                console.log("True");
                return true;
            }
            else{
                console.log("False");
                return false;
            }
        },
        validirajAkGod: function(date){
            var dateRegex = /^20[0-9]{2}\/20[0-9]{2}$/g;
            if(date.match(dateRegex)){
                var first = parseInt(date.substring(2, 4));
                var second = parseInt(date.substring(7, date.length));
                if(first+1 === second) { console.log("True"); return true;}
                else{
                    console.log("False");
                    return false;
                }
            }
            else{
                console.log("False");
                return false;
            }
        },
        validirajPassword: function(password){
            var passwordRegex = /(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{7,20}/g;
            if(password.match(passwordRegex)) { console.log("True"); return true;}
            else{
                console.log("False");
                return false;
            }
        },
        validirajPotvrdu: function(password1, password2){
            if(password1 === password2) {
                console.log("True");
                return true;
            }
            else{
                console.log("False");
                return false;
            }
        },
        validirajBitbucketURL: function(bitbucketUrl){
            var bitbucketRegex = /^https:\/\/[a-zA-Z0-9]*@bitbucket\.org\/[a-zA-Z0-9]*\/[a-zA-Z0-9]*\.git$/g;
            if(bitbucketUrl.match(bitbucketRegex)) {
                console.log("True");
                return true;
            }
            else{
                console.log("False");
                return false;
            }
        },
        validirajBitbucketSSH: function(bitbucketssh){
            var regSSH = /^git@bitbucket\.org:[a-zA-Z0-9]*\/[a-zA-Z0-9]*\.git$/g
            if(bitbucketssh.match(regSSH)) { console.log("True"); return true;}
            else{
                console.log("False");
                return false;
            }
        },

        validirajNazivRepozitorija: function(repositoryRegex, repositoryName){
            // console.log("first" +repositoryRegex.value);
            if(repositoryRegex === ""){
                // console.log("second" + repositoryRegex.value);
                repositoryRegex = new RegExp("(wtProjekat[0-9]{5}|wtprojekat[0-9]{5})$");
                // console.log(repositoryName);
                // console.log(repositoryRegex);

                if(repositoryRegex.test(repositoryName)) {
                    console.log("True");
                    return true;
                }
                else{
                    console.log("False");
                    return false;
                }
            }
            else{
                // console.log("third" + repositoryRegex.value);

                //_________________________________________________________________________________________________________________
                // nisam siguran sta treba uraditi posto je regex u drugoj formi i prosljeđuje se undefined value
                // jedino sto bi imalo smisla je radit cross validaciju, ali u ovom slucaju ne vidim potrebu za tim
                //
                //_________________________________________________________________________________________________________________

                // var tempRegex= new RegExp(repositoryRegex);
                // if(tempRegex.test(repositoryName)) {
                //     console.log("True defined");
                //     return true;
                // }
                // else{
                //     console.log("False defined");
                //     return false;
                // }
            }
        },
        validirajImeiPrezime: function(fullName) {
            var fullNameRegex = /([A-ZĐŽŠĆČ][a-zšćžđč'-]{2,11}\s*)+/g;
            if(fullNameRegex.test(fullName)) {
                console.log("True");
                return true;
            }
            else{
                console.log("False");
                return false;
            }
        },
        postaviMaxGrupa: function(numberOfGroups){
            maxGrupa = numberOfGroups;
        },
        postaviTrenSemestar: function(selectedSemester){
            trenutniSemestar = selectedSemester;
        },
    }
})();