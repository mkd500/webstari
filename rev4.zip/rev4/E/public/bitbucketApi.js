var BitbucketApi = (function(){
    return {
        dohvatiAccessToken: function(key, secret, fnCallback){
            
            var ajax = new XMLHttpRequest();
             
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200)
                    fnCallback(null,JSON.parse(ajax.responseText).access_token);
                else if (ajax.readyState == 4 && ajax.status == 404)
                    fnCallback(ajax.status,null);
                else if( !key  || !secret) 
                    {
                        fnCallback(-1,"Key ili secret nisu pravilno proslijeđeni!");
                    }
                else if (ajax.readyState == 4)
                {
                    fnCallback(ajax.status,null);
                }
            }
            ajax.open("POST", "https://bitbucket.org/site/oauth2/access_token", true);
            ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            ajax.setRequestHeader("Authorization", 'Basic ' + btoa(key+':'+secret));
            ajax.send("grant_type="+encodeURIComponent("client_credentials"));
        },
        dohvatiRepozitorije: function dohvatiRepozitorije(token, godina, naziv, branch, fnCallback){
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function(){
                if (ajax.readyState == 4 && ajax.status == 200)
                    {
                        fnCallback(null,JSON.parse(ajax.responseText).access_token);
                    }
                else if (ajax.readyState == 4 && ajax.status == 404)
                   {
                    fnCallback(ajax.status,null);
                   }
                else if (ajax.readyState == 4)
                    {
                    fnCallback(ajax.status,null);
                    }
                }
                ajax.open("GET","https://api.bitbucket.org/2.0/repositories?q=full_name%3D%22haris_h%2F"+naziv+"%22+AND+created_on+%3E%3D"+godina+"-01-01&role=member&pagelen=150");
                ajax.setRequestHeader("Authorization", 'Bearer ' + token);
                ajax.send();
        },
        dohvatiBranch: function(token, url, naziv, fnCallback){
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function(){
                if (ajax.readyState == 4 && ajax.status == 200)
                    {
                        var retrievedResponse = JSON.parse(ajax.responseText);
                        var returnBranches = [];
                        
                        for(var i=0;i<retrievedResponse.values.length;i++)
                        {
                            if(retrievedResponse.values[i].name == naziv)
                            {
                                returnBranches.push(retrievedResponse.values[i].name);
                            }
                        }
                    }
                    else if (ajax.readyState == 4)
                    {
                        fnCallback(ajax.status,null);
                    }
                }
                ajax.open("GET",url);
                ajax.setRequestHeader("Authorization", 'Bearer ' + token);
                ajax.send();
        }
    }
})();
