var KreirajFajl=(function(){
    
    return {
        kreirajKomentar = function(spirala, index, sadrzaj, fnCallback){
                
                var arrayIsCorrect = true;

                for(i=0;i<sadrzaj.length;i++){
                    console.log(sadrzaj[i])
                    if( !sadrzaj[i].hasOwnProperty('sifra_studenta') || !sadrzaj[i].hasOwnProperty('tekst') || !sadrzaj[i].hasOwnProperty('ocjena') || (Object.keys(sadrzaj[i]).length !== 3))
                    {
                        arrayIsCorrect = false;
                        break;
                    }
                }

                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function() {
                    if (ajax.readyState == 4 && ajax.status == 200)
                        {
                            fnCallback(null,JSON.parse(ajax.responseText));
                        }
                    if (ajax.readyState == 4)
                        {
                            fnCallback(ajax.status,JSON.parse(ajax.responseText));
                        }
                    if( spirala === "" || index === "" ||  !arrayIsCorrect || ajax.readyState == 4 ) 
                        {
                            fnCallback(-1,"Neispravni parametri");
                        }
                var params = {"spirala": spirala,"index": index,"sadrzaj":sadrzaj};
                ajax.open("POST", "http://localhost:3000/komentar", true);
                ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                ajax.send(JSON.stringify(params));
                }
            },
        kreirajListu = function(godina, nizRepozitorija, fnCallback){
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function() {
                        if (ajax.readyState == 4 && ajax.status == 200)
                            {
                                fnCallback(null,JSON.parse(ajax.responseText));
                            }
                        if (ajax.readyState == 4 )
                            {
                                fnCallback(ajax.status,JSON.parse(ajax.responseText));
                            }
                        if( godina === "" || nizRepozitorija.length === 0 || ajax.readyState == 4 ) 
                            {
                                fnCallback(-1,"Neispravni parametri");
                            }
                    var params = {"godina":godina,"nizRepozitorija":nizRepozitorija}
                    ajax.open("POST", "http://localhost:3000/lista", true);
                    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                    ajax.send(JSON.stringify(params));
                }
            },
        kreirajIzvjestaj = function(spirala,index, fnCallback){
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function() {
                    if (ajax.readyState == 4 && ajax.status == 200)
                    {
                        fnCallback(null,JSON.parse(ajax.responseText));
                    }
                if (ajax.readyState == 4 )
                    {
                        fnCallback(ajax.status,JSON.parse(ajax.responseText));
                    }
                if( spirala === "" || index === "" || ajax.readyState == 4 ) 
                    {
                        fnCallback(-1,"Neispravni parametri");
                    }
                var params = {"spirala": spirala,"index": index };
                ajax.open("POST", "http://localhost:3000/izvjestaj", true);
                ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                ajax.send(JSON.stringify(params));
            }
        },
        kreirajBodove = function(spirala,index, fnCallback){
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200)
                    {
                        fnCallback(null,JSON.parse(ajax.responseText));
                    }
                if (ajax.readyState == 4)
                    {
                        fnCallback(ajax.status,JSON.parse(ajax.responseText));
                    }
                if( spirala === "" || index === "" || ajax.readyState == 4 ) 
                    {
                        fnCallback(-1,"Neispravni parametri");
                    }
                    var params = {"spirala": spirala,"index": index };
                    ajax.open("POST", "http://localhost:3000/izvjestaj", true);
                    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                    ajax.send(JSON.stringify(params));
            }
        }
    }
})();
