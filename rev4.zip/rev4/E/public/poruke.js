var Poruke = (function(){
    var idDivaPoruka= 'errorReport';
    var mogucePoruke = ['Email koji ste napisali nije validan fakultetski email',
        'Indeks kojeg ste napisali nije validan',
        'Nastavna grupa koju ste napisali nije validna',
        'Bitbucket URL koji ste unijeli nije validan',
        'Bitbucket SSH koji ste unijeli nije validan',
        'Naziv repozitorija nije validno unesen',
        'Sifra koju ste unijeli nije validna',
        'Potvrdna sifra se ne poklapa sa sifrom',
        'Ime i prezime koje ste unijeli nije validno',
        'Broj grupa nije validno unesen',
        'Akademska godina nije validno unesena'];

    var porukeZaIspis = [];
    return{

        ispisiGreske: function() {
            document.getElementById(idDivaPoruka).innerHTML="";
            for (var i = 0; i < porukeZaIspis.length; i++) {
                document.getElementById(idDivaPoruka).innerHTML+= porukeZaIspis[i] + '<hr>';
            }
        },

        postaviIdDiva: function(divID) {
            // console.log(divID);
            idDivaPoruka=divID;
        },

        dodajPoruku: function(errorNumber){
            if(!porukeZaIspis.includes(mogucePoruke[errorNumber]) && errorNumber >= 0 && errorNumber <= 11){
                porukeZaIspis.push(mogucePoruke[errorNumber]);
            }
        },

        ocistiGresku: function(errorNumber){
            var message = mogucePoruke[errorNumber];
            var index = porukeZaIspis.indexOf(message);
            if(index !== -1)
            porukeZaIspis.splice(index, 1);
        }
    }
})();
