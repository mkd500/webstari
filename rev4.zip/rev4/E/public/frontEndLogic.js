

function onNavMenuClick(input)
{
    switch(input) {
        case 1:
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200)
                    document.getElementById("main").innerHTML = ajax.responseText;
                if (ajax.readyState == 4 && ajax.status == 404)
                    document.getElementById("main").innerHTML = "Greska: nepoznat URL";
            }
            ajax.open("GET", "/login", true);
            ajax.send();
            break;
        case 2:
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200)
                    document.getElementById("main").innerHTML = ajax.responseText;
                if (ajax.readyState == 4 && ajax.status == 404)
                    document.getElementById("main").innerHTML = "Greska: nepoznat URL";
            }
            ajax.open("GET", "/unosKomentara", true);
            ajax.send();
            break;
        case 3:
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200)
                    document.getElementById("main").innerHTML = ajax.responseText;
                if (ajax.readyState == 4 && ajax.status == 404)
                    document.getElementById("main").innerHTML = "Greska: nepoznat URL";
            }
            ajax.open("GET", "/statistika", true);
            ajax.send();
            break;
        case 4:
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200)
                    document.getElementById("main").innerHTML = ajax.responseText;
                if (ajax.readyState == 4 && ajax.status == 404)
                    document.getElementById("main").innerHTML = "Greska: nepoznat URL";
            }
            ajax.open("GET", "/unosSpirala", true);
            ajax.send();
            break;
        case 5:
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200)
                    document.getElementById("main").innerHTML = ajax.responseText;
                if (ajax.readyState == 4 && ajax.status == 404)
                    document.getElementById("main").innerHTML = "Greska: nepoznat URL";
            }
            ajax.open("GET", "/teacherGenerateReports", true);
            ajax.send();
            break;
        case 6:
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200)
                    document.getElementById("main").innerHTML = ajax.responseText;
                if (ajax.readyState == 4 && ajax.status == 404)
                    document.getElementById("main").innerHTML = "Greska: nepoznat URL";
            }
            ajax.open("GET", "/bitbucket", true);
            ajax.send();
            break;
        case 7:
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200)
                    document.getElementById("main").innerHTML = ajax.responseText;
                if (ajax.readyState == 4 && ajax.status == 404)
                    document.getElementById("main").innerHTML = "Greska: nepoznat URL";
            }
            ajax.open("GET", "/userList", true);
            ajax.send();
            break;
        default:
            console.log('default')
    }
}

function loginUser()
{
    var ajax = new XMLHttpRequest();
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200){
            document.getElementById("navigation").innerHTML = ajax.responseText;
        }
        else
        {
            console.log(ajax.responseText);
        }
    }
    ajax.open("POST","/login",true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(JSON.stringify({username:username,password:password}));
}

function verify(id)
{
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200){
            document.getElementById("main").innerHTML = ajax.responseText;
        }
    }
    ajax.open("GET","/verify/"+id,true);
    ajax.send();
}
function unverify(id)
{
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200){
            document.getElementById("main").innerHTML = ajax.responseText;
        }
    }
    ajax.open("GET","/unverify/"+id,true);
    ajax.send();
}