function findLowerRow(node){
    node=node.nextElementSibling;
    return node;
}

function findUpperRow(node){
    node=node.previousElementSibling;
    return node;
}

function shiftUp(){
    var table,row = this.parentNode;
    while(row.nodeName != "TR")
    {
        row = row.parentNode;
    }

    table=row.parentNode;
    var upperRow=findUpperRow(row);

    if(upperRow != null)
    {
        table.insertBefore(row,upperRow);
    }
}

function shiftDown(){
    var table,row = this.parentNode;
    while(row.nodeName != "TR")
    {
        row = row.parentNode;
    }

    table=row.parentNode;
    var lowerRow=findLowerRow(row);

    if(lowerRow != null)
    {
        table.insertBefore(lowerRow,row);
    }
}
