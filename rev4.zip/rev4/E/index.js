const express = require('express');
const bodyParser = require('body-parser');
var htmlencode = require('htmlencode');
var path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const session = require("express-session");
var htmlencode = require('htmlencode');

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));


const Sequelize = require('sequelize');
const sequelize = require('./databaseFile/bazaPodataka.js');
const Korisnik = sequelize.import(__dirname+"/databaseFile/korisnik.js");
const Rola = sequelize.import(__dirname+"/databaseFile/rola.js");
const LicniPodaci = sequelize.import(__dirname+"/databaseFile/licniPodaci.js");

const saltRounds = 10;
const authorizationDeniedMsg = "Nemate pravo pristupa!";

Korisnik.drop();
Rola.drop();
LicniPodaci.drop();
Rola.sync().then(function()
{
    Rola.findOrCreate({where: {id: 1}, defaults: {naziv: 'Student'}})
    Rola.findOrCreate({where: {id: 2}, defaults: {naziv: 'Nastavnik'}})
    Rola.findOrCreate({where: {id: 3}, defaults: {naziv: 'Administrator'}})
});
LicniPodaci.sync();
Korisnik.sync().then(function()
{
    bcrypt.hash('admin', saltRounds).then(function(hash) {
        Korisnik.findOrCreate({where: {username: 'admin'}, defaults: {password: hash, RolaId: 3}})
    });
});


app.use(session({
    secret: 'skafiskafnjak',
    resave: true,
    saveUninitialized: true
 }));

 
app.post('/registerStudent',function(req,res){

    if(req.body['fullNameStudent']!='')
    {
        console.log(req.body['fullNameStudent'])
        console.log(req.body['studentPassword'])
        bcrypt.hash(req.body['studentPassword'], saltRounds).then(function(hash) {
            LicniPodaci.create({fullName:htmlencode.htmlEncode(req.body['fullNameStudent']),
                                indexNumber:htmlencode.htmlEncode(req.body['indexNum']),
                                group:htmlencode.htmlEncode(req.body['groupNum']),
                                verified:null,
                                bitbucketUrl:htmlencode.htmlEncode(req.body['bitbucketUrl']),
                                bitbucketSsh:htmlencode.htmlEncode(req.body['bitbucketSSH']),
                                repositoryName:htmlencode.htmlEncode(req.body['repositoryName'])
                        })
                        .then(function(zapis){
                            Korisnik.create({
                                password:hash, 
                                username:req.body['fullNameStudent'],
                                LicniPodaciId:zapis.id,
                                RolaId:1
                            });
                            res.send(zapis);
                        })
                        .catch(function(err){
                            res.send(err);
                        });
                    });
    }
    else
    {
        res.send('Neispravan unos!');
    }
});

 app.post('/registerTeacher',function(req,res){

    if(req.body['fullNameTeacher'] != ''){
        bcrypt.hash(req.body['teacherPassword'], saltRounds).then(function(hash) {
        LicniPodaci.create({fullName:req.body['fullNameTeacher'],
                            workEmail:req.body['schoolEmail'],
                            maxGroupNumber:req.body['maxGroupNum'],
                            validationRegex:req.body['repositoryRegex'],
                            currentSemester:req.body['semester'],
                            academicYear:req.body['academicYearTeacher'],
                            verified:false, 
                    })
                    .then(function(zapis){
                        Korisnik.create({
                            username:req.body['userName'],
                            password:hash,
                            LicniPodaciId:zapis.id,
                            RolaId:2
                        });
                        res.send(zapis);
                    })
                    .catch(function(err){
                        res.send(err);
                    });
                });
    }
    else
    {
        res.send('Neispravan unos!');
    }
});


 app.post('/login',function(req,res){
    // sequelize
    // .authenticate()
    // .then(() => {
    // console.log('Connection has been established successfully.');
    // })
    // .catch(err => {
    // console.error('Unable to connect to the database:', err);
    // });
    var data = req.body;
    
    var username = htmlencode.htmlEncode(data.username);
    var password = htmlencode.htmlEncode(data.password);
    
    Korisnik.findOne({
        where: {
          username: username
        }
      }).then(function(query){
        if(!query)
        {
            res.send('Korisnik nije u bazi!');
            res.end();
        }
        else
        {
            var user = query.dataValues;
            
            // console.log('Uneseno:' + password);
            // console.log('Hash:' + korisnik.password);
            bcrypt.compare(password, user.password, function(err, result) {
                if (err) throw err;
                if(result === true)
                {
                    LicniPodaci.findOne(
                    {
                        where:{
                            id: user.LicniPodaciId
                        }
                    })
                    .then(function(result){
                        req.session.permission = user.RolaId;
                          
                        if(req.session.permission === 1)
                            res.sendFile(__dirname + '/public/navMenuStudent.html');
                        else if(req.session.permission === 2){
                            if(result.dataValues.verified === true)
                                res.sendFile(__dirname + '/public/navMenuTeacher.html');
                            else
                            {
                                res.send('Korisnik nije verifikovan');
                            }
                        }
                        else if(req.session.permission === 3)
                            res.sendFile(__dirname + '/public/navMenuAdmin.html');
                    })
                }
                else
                {
                    res.send('Pogresan password!');
                }
            });
        }
    });
});

app.get('/verify/:id',function(req,res)
{
    var id = req.params.id;
    
    LicniPodaci.findById(id)
    .then(function (data) {
    if (data) {
        data.updateAttributes({
        verified: true
      })
      res.send('Korisnik ' + data.fullName + ' verifikovan!');
    }
  })
});

app.get('/unverify/:id',function(req,res)
{
    var id = req.params.id;

    LicniPodaci.findById(id)
    .then(function (data) {
    if (data) {
        data.updateAttributes({
        verified: false
      })
      res.send('Korisnik ' + data.fullName + ' odverifikovan!');
    }
  })
});


app.get('/userList',function(req,res){
    if(req.session.permission != 3)
    {
        res.send(authorizationDeniedMsg);
        res.end();
    }
    LicniPodaci.findAll()
    .then(function(query){
        var rows = [];
        for(i = 0; i < query.length;i++)
        {

            var entries = query[i].dataValues;
            var row = '<tr><td>' + entries.fullName+ '</td>';

            if(entries.verified == false)
            {
                row += '<td><button onClick="verify('+ entries.id + ')">Verify</button></td>';
            }
            else if(entries.verified == true)
            {
                row += '<td><button onClick="unverify('+ entries.id +')">Unverify</button></td>';
            }

            row += '</tr>';
            rows.push(row);
        }
        //tragedija nekoristenja pug-a
        htmlTemplate = '<input id="search"><button onclick=search()>Pretrazi</button>';
        htmlTemplate += '<table>';
        for(i = 0; i < rows.length;i++)
        {
            htmlTemplate += rows[i];
        }
        htmlTemplate += '</table>';
        res.send(htmlTemplate);
        res.end();
    });
});

app.get('/userList/:query',function(req,res){
    if(req.session.permission != 3)
    {
        res.send(permissionError);
        res.end();
    }
    var query = req.params.query;
    query = htmlencode.htmlEncode(query);

    LicniPodaci.findAll({
        include: [{
          model: Korisnik,
          required: true
         }]
      })
      .then(function(query){
        var rows = [];
        for(i = 0; i < query.length;i++)
        {

            var entries = query[i].dataValues;
            var row = '<tr><td>' + entries.fullName+ '</td>';

            if(entries.verified == false)
            {
                row += '<td><button onClick="verify('+ entries.id + ')">Verify</button></td>';
            }
            else if(entries.verified == true)
            {
                row += '<td><button onClick="unverify('+ entries.id +')">Unverify</button></td>';
            }

            row += '</tr>';
            rows.push(row);
        }
        //tragedija nekoristenja pug-a
        htmlTemplate = '<input id="search"><button onclick=search()>Pretrazi</button>';
        htmlTemplate += '<table>';
        for(i = 0; i < rows.length;i++)
        {
            htmlTemplate += rows[i];
        }
        htmlTemplate += '</table>';
        res.send(htmlTemplate);
        res.end();
    });
});

app.post('/komentar',function(req,res){
    var retrievedData = req.body;
    if(!retrievedData.hasOwnProperty('spirala') || !retrievedData.hasOwnProperty('index') || !retrievedData.hasOwnProperty('sadrzaj')){
        res.json({message:"Podaci nisu u traženom formatu!",data:null});
    }

    var fileName = 'marksS' + retrievedData.spirala + retrievedData.index + '.json';
    
    fs.truncate(fileName, 0, function() {
        fs.writeFile(fileName, JSON.stringify(retrievedData.sadrzaj), function (err) {
            if (err) throw err;
            res.json({message:"Uspješno kreirana datoteka!",data: retrievedData.sadrzaj});
        });
    });
});

app.post('/lista',function(req,res){
    
    var retrievedData = req.body;
    if(!retrievedData.hasOwnProperty('godina') || !retrievedData.hasOwnProperty('nizRepozitorija')){
        res.json({message:"Podaci nisu u traženom formatu!",data:null});
    }

    var fileName = 'spisak' + retrievedData.godina + '.txt';

    var returnJson = JSON.stringify(retrievedData.nizRepozitorija);
    returnJson = returnJson.replace('[','').replace(']','');
    var redovi = returnJson.split(',');
    var returnRows = [];
    for(i = 0 ; i < redovi.length;i++)
    {
        if(redovi[i].includes(retrievedData.godina))
        {
            returnRows.push(redovi[i].replace('"','').replace('"',''));
        }
    }
    
    fs.truncate(fileName, 0, function() {
        fs.writeFile(fileName, returnRows.join('\n'), function (err) {
            if (err) throw err;
            res.json({message:"Lista uspješno kreirana",data: returnRows.length});
        });
    });
});

app.get('/unosSpirala', function(req,res){
    res.sendFile(path.join(__dirname + '/public/unosSpiska.html'))
});


app.post('/unosSpirala', function(req,res){
    let returnArr=req.body;
    var tempArr=[];
    var row=returnArr['spiral-list'].toString();
  
    var rows=row.split('\n');

    for(i=0; i<rows.length;i++){
        var jsonArr=[];
        var rowValues=rows[i].split(',');

        var sorted_arr = rowValues.slice().sort(); 
        var results = [];
        for (var i = 0; i < sorted_arr.length - 1; i++) {
            if (sorted_arr[i + 1] == sorted_arr[i]) {
                res.json({message:"Red broj "+(i+1)+" sadrži duple unose"});
            }
        }  
      
       for(j=0; j<rowValues.length;j++)
       {
        jsonArr.push(rowValues[j].trim());
       }

       tempArr.push(jsonArr);
    }

    fs.appendFile('spiralList.json',JSON.stringify(tempArr),function(err){
        if(err) throw err;
        res.json({message:"Uspješno napravljena datoteka", data:tempArr});
    })
});

app.get('/', function(req, res) {
    res.sendFile(path.join(__dirname + '/index.html'));
});

app.get('/login',function(req,res){
    res.sendFile(__dirname + '/public/login.html');
});

app.get('/unosKomentara',function(req,res){
    if(req.session.permission === 1)
    res.sendFile(__dirname + '/public/unoskomentara.html');
    else
        res.send(authorizationDeniedMsg);
});
app.get('/teacherGenerateReports',function(req,res){
    if(req.session.permission === 2)
    res.sendFile(__dirname + '/public/teacherGenerateReports.html');
    else
        res.send(authorizationDeniedMsg);
   
});


app.get('/bitbucket', function(req, res){
    if(req.session.permission === 2)
    res.sendFile(__dirname + '/public/bitbucket.html');
    else
        res.send(authorizationDeniedMsg);
});

app.get('/statistika', function(req, res){
    if(req.session.permission === 1)
    res.sendFile(__dirname + '/public/statistika.html');
    else
        res.send(authorizationDeniedMsg);
});

app.get('/userList', function(req, res){
        res.sendFile(__dirname + '/public/userList.html');
});

app.listen(3000);