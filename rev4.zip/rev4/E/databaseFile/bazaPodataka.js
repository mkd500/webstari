const Sequelize = require("sequelize");
const sequelize = new Sequelize("sql11217513","sql11217513","VCrsHQCrTA",{host:"sql11.freemysqlhosting.net",dialect:"mysql"});
module.exports = sequelize;