const Sequelize = require("sequelize");
const sequelize = require("./bazaPodataka.js");
const Korisnik = sequelize.define('Korisnik',{
    username: Sequelize.STRING(50),
    password: Sequelize.STRING(250)
})

const LicniPodaci = sequelize.import(__dirname+"/licniPodaci.js");
const Rola = sequelize.import(__dirname+"/rola.js");

LicniPodaci.hasOne(Korisnik, {foreignKey: 'LicniPodaciId'});
Rola.hasOne(Korisnik, {as: 'Rola', foreignKey: 'RolaId'});


module.exports = function(sequelize,DataTypes){
    return Korisnik;
}