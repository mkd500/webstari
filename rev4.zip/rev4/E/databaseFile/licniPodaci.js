const Sequelize = require("sequelize");
const sequelize = require("./bazaPodataka.js");
const LicniPodaci = sequelize.define('LicniPodaci',{
    fullName: Sequelize.STRING(150),
    indexNumber: Sequelize.STRING(6),
    group: Sequelize.STRING(5),
    academicYear: Sequelize.STRING(9),
    bitbucketUrl: Sequelize.STRING,
    bitbucketSsh: Sequelize.STRING,
    repositoryName: Sequelize.STRING(30),
    workEmail: Sequelize.STRING(30),
    maxGroupNumber: Sequelize.INTEGER,
    validationRegex: Sequelize.STRING(15),
    currentSemester: Sequelize.STRING(15),
    verified: Sequelize.BOOLEAN
})

module.exports = function(sequelize,DataTypes){
    return LicniPodaci;
}