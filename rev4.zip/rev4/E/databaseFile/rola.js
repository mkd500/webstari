const Sequelize = require("sequelize");
const sequelize = require("./bazaPodataka.js");
const Rola = sequelize.define('Rola',{
    naziv: Sequelize.STRING(15),
})
module.exports = function(sequelize,DataTypes){
    return Rola;
}