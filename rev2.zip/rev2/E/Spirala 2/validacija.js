var Validacija= (function(){
  var maxGrupa=7;
  var trenutniSemestar=0; //0 za zimski, 1 za ljetni trenutniSemestar
  var repoRegex=/wt(P|p)rojekat1\d{4}$/;

  return{
    validirajFakultetski: function(email){
      var regex=/etf\.unsa\.ba$/;
      return regex.test(email);
    },
    validirajIndex: function(index){
      var regex=/1\d{4}$/;
      return regex.test(String(index));
    },
    validirajGrupu: function(grupa){
      return Boolean(grupa>=1 & grupa<=10);

    },
    validirajAkGod: function(akGod){
      var regex = /^\d{4}\/\d{4}$/;
      if (regex.test(akGod)) {
        var godine=akGod.split('/');
        if (parseInt(godine[0])==parseInt(godine[1])-1)return true;
      }
      return false;
    },
    validirajPassword: function(password){
      var regex=/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,20}$/;
      return regex.test(password);
    },
    validirajPotrvrdu: function(pass1, pass2){
      if(this.validirajPassword(pass1) & this.validirajPassword(pass2)){
        if (pass1==pass2) {
          return true;
        }
      }
      return false;
    },
    validirajBitbucketURL: function(url){
      var regex=/^https:\/\/\w+@bitbucket\.org\/\w+\/\w+\.git$/;
      if (!regex.test(url))return false;
      var repo=url.split('/')[3].split('.')[0];//uzimam zadnju riječ iz linka da testiram ime repozitorija
      if(repoRegex!=null) {
        return repoRegex.test(repo);
      }
      else return true;
    },
    validirajBitbucketSSH: function(ssh){
      var regex=/^git@bitbucket\.org:\w+\/\w+\.git$/;
      if (!regex.test(ssh))return false;
      var repo=ssh.split('/')[3].split('.')[0];//uzimam zadnju riječ iz linka da testiram ime repozitorija
      if(repoRegex!=null) {
        return repoRegex.test(repo);
      }
      else return true;
    },
    validirajNazivRepozitorija: function(regex,nazivRepozitorija){
      repoRegex=regex;
      return regex.test(nazivRepozitorija);
    },
    validirajImeiPrezime: function (imeIPrezime) {
      var regex =/^(\s)*[A-Za-z]+((\s)?((\'|\-|\.)?([A-Za-z])+))*(\s)*$/;
      return regex.test(imeiPrezime);

  },
    dajRegex: function(){return repoRegex;},
    postaviMaxGrupa:function(max){maxGrupa=max;},
    postaviTrenSemestar:function(sem){trenutniSemestar=sem;},
    postaviRegex: function (reg){repoRegex=reg;}

  }
}());
