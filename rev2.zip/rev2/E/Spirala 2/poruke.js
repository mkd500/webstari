function findIfExists (niz,vrijednost){
  for (var i=0; i<niz.length; i++){
    if(niz[i]==vrijednost) return i;
  }
  return -1;
}


var Poruke = (function(){
  var idDivaPoruka;
  var mogucePoruke=[
    " Email koji ste napisali nije validan fakultetski email",
    " Indeks kojeg ste napisali nije validan",
    " Nastavna grupa koju ste napisali nije validna",
    " Akademska godina koju ste napisali nije validna",
    " Password koji ste napisali nije validan",
    " Passwordi se ne poklapaju ili nisu validni",
    " Bitbucket URL koji ste napisali nije validan",
    " Bitbucket SSH koji ste napisali nije validan",
    " Naziv repozitorija koji ste napisali nije validan",
    " Ime i prezime koje ste napisali nije validno"]
  var porukeZaIspis=[];

  return {
    ispisiGreske: function(){
      var konacnaPoruka=porukeZaIspis.join("<br>");
      document.getElementById(idDivaPoruka).innerHTML=konacnaPoruka;
    },
    postaviIdDiva: function(id){idDivaPoruka=id;},
    dodajPoruku: function(ind){
      if (findIfExists(porukeZaIspis,mogucePoruke[ind])<0)
      porukeZaIspis.push(mogucePoruke[ind]);
    },
    ocistiGresku: function(ind){
      var p=findIfExists(porukeZaIspis,mogucePoruke[ind]);
      if (p>=0)porukeZaIspis.splice(p,1);}
  }
}());

function poruka(text) {
  Poruke.postaviIdDiva("porukeValidacije");
  var passForVal="";

  switch (text.name) {
    case "fakultetskiMail":
      if(Validacija.validirajFakultetski(text.value))Poruke.ocistiGresku(0);
      else Poruke.dodajPoruku(0);
      break;
    case "index":
      if(Validacija.validirajIndex(text.value))Poruke.ocistiGresku(1);
      else Poruke.dodajPoruku(1);
      break;
    case "grupa":
      if(Validacija.validirajGrupu(text.value))Poruke.ocistiGresku(2);
      else Poruke.dodajPoruku(2);
      break;
    case "akGodina":
      if(Validacija.validirajAkGod(text.value))Poruke.ocistiGresku(3);
      else Poruke.dodajPoruku(3);
      break;
    case "pass":
      if(Validacija.validirajPassword(text.value)){
        Poruke.ocistiGresku(4);
        passForVal=text.value;
      }
      else Poruke.dodajPoruku(4);
      break;
    case "verifyPass":
      if(Validacija.validirajPotrvrdu(text.value,passForVal))Poruke.ocistiGresku(5);
      else Poruke.dodajPoruku(5);
      break;
    case "bitbucketURL":
      if(Validacija.validirajBitbucketURL(text.value))Poruke.ocistiGresku(6);
      else Poruke.dodajPoruku(6);
      break;
    case "bitbucketSSH":
      if(Validacija.validirajBitbucketSSH(text.value))Poruke.ocistiGresku(7);
      else Poruke.dodajPoruku(7);
      break;
    case "nazivRepozitorija":
      if(Validacija.validirajNazivRepozitorija(Validacija.dajRegex(),text.value))Poruke.ocistiGresku(8);
      else Poruke.dodajPoruku(8);
      break;
    case "imeiPrezime":
      if(Validacija.validirajImeiPrezime(text.value))Poruke.ocistiGresku(9);
      else Poruke.dodajPoruku(9);
      break;
  }
  Poruke.ispisiGreske();


}
function postavi(text) {
  switch (text.name) {
    case "maxGrupe":
    Validacija.postaviMaxGrupa(text.value);
    break;
    case "repoRegex":
    Validacija.postaviRegex(text.value);
    break;
    case "trenutniSemestar":
    Validacija.postaviTrenSemestar(text.value);
    break;
  }
}
