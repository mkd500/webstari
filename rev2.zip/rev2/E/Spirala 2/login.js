
function prebaciNaNastavnika(){
  document.getElementById('registerStudent').style.display="none";
  document.getElementById('registerNastavnik').style.display="table-cell";
}
function prebaciNaStudenta(){
  document.getElementById('registerNastavnik').style.display="none";
  document.getElementById('registerStudent').style.display="table-cell";
}
