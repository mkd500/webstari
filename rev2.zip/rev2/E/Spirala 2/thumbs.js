function moveUp(r) {
  if(r.parentNode.parentNode.rowIndex>1){
    var row = r.parentNode.parentNode,
        sibling = row.previousElementSibling,
        parent = row.parentNode;

    parent.insertBefore(row, sibling);
  }
}
function moveDown(r)
 {
   if(r.parentNode.parentNode.rowIndex<document.getElementById("tabela").rows.length-1){
     var row = r.parentNode.parentNode,
         sibling = row.nextElementSibling,
         parent = row.parentNode;

     parent.insertBefore(sibling, row);
   }
 }
