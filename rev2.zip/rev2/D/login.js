var EMAIL_MESSAGE = 0;
var INDEX_MESSAGE = 1;
var GROUP_MESSAGE = 2;
var AYEAR_MESSAGE = 3;
var PW_MESSAGE = 4;
var PW_COMPARE_MESSAGE = 5;
var BURL_MESSAGE = 6;
var BSSH_MESSAGE = 7;
var REPO_NAME_MESSAGE = 8;
var NAME_MESSAGE = 9;
var SEMESTER_MESSAGE = 10;


Poruke.postaviIdDiva("errorDiv");
function obrisiSve() {
    Poruke.ocistiGresku(EMAIL_MESSAGE);
    Poruke.ocistiGresku(INDEX_MESSAGE);
    Poruke.ocistiGresku(GROUP_MESSAGE);
    Poruke.ocistiGresku(AYEAR_MESSAGE);
    Poruke.ocistiGresku(PW_MESSAGE);
    Poruke.ocistiGresku(PW_COMPARE_MESSAGE);
    Poruke.ocistiGresku(BURL_MESSAGE);
    Poruke.ocistiGresku(BSSH_MESSAGE);
    Poruke.ocistiGresku(REPO_NAME_MESSAGE);
    Poruke.ocistiGresku(NAME_MESSAGE);
    Poruke.ocistiGresku(SEMESTER_MESSAGE);
    Poruke.ispisiGreske();
}

function buttonTeacher() {
    document.getElementById("registerTeacherButton").style.backgroundColor = "#E63946";
    document.getElementById("registerStudentButton").style.backgroundColor = "brown";
    document.getElementById("registrationForm").style.display = "none";
    document.getElementById("teacherRegistrationForm").style.display = "block";
    obrisiSve();
    
}

function buttonStudent() {
    document.getElementById("registerTeacherButton").style.backgroundColor = "brown";
    document.getElementById("registerStudentButton").style.backgroundColor = "#E63946";
    document.getElementById("registrationForm").style.display = "block";
    document.getElementById("teacherRegistrationForm").style.display = "none";
    obrisiSve();
}



function validateEmail(x) {
    if( !Validacija.validirajIndex(x) ) {
        Poruke.dodajPoruku(EMAIL_MESSAGE);
        Poruke.ispisiGreske();
    } else {
        Poruke.ocistiGresku(EMAIL_MESSAGE);
        Poruke.ispisiGreske();
    }
}

function validateIndex(x) {
    if( !Validacija.validirajIndex(x) ) {
        Poruke.dodajPoruku(INDEX_MESSAGE);
        Poruke.ispisiGreske();
    } else {
        Poruke.ocistiGresku(INDEX_MESSAGE);
        Poruke.ispisiGreske();
    }
}

function validateGroup(x) {
    if( !Validacija.validirajGrupu(x) ) {
        Poruke.dodajPoruku(GROUP_MESSAGE);
        Poruke.ispisiGreske();
    } else {
        Poruke.ocistiGresku(GROUP_MESSAGE);
        Poruke.ispisiGreske();
    }
}

function validateYear(x) {
    if( !Validacija.validirajAkGod(x) ) {
        Poruke.dodajPoruku(AYEAR_MESSAGE);
        Poruke.ispisiGreske();
    } else {
        Poruke.ocistiGresku(AYEAR_MESSAGE);
        Poruke.ispisiGreske();
    }
}
var pw;
function validatePassword(x) {
    if( !Validacija.validirajPassword(x) ) {
        Poruke.dodajPoruku(PW_MESSAGE);
        Poruke.ispisiGreske();
    } else {
        Poruke.ocistiGresku(PW_MESSAGE);
        Poruke.ispisiGreske();
    }
    pw = x;
}

function validatePasswordCheck(x) {
    if( !Validacija.validirajPassword(x,pw) ) {
        Poruke.dodajPoruku(PW_COMPARE_MESSAGE);
        Poruke.ispisiGreske();
    } else {
        Poruke.ocistiGresku(PW_COMPARE_MESSAGE);
        Poruke.ispisiGreske();
    }
}

function validateBitbucketURL(x) {
    if( !Validacija.validirajPassword(x) ) {
        Poruke.dodajPoruku(BURL_MESSAGE);
        Poruke.ispisiGreske();
    } else {
        Poruke.ocistiGresku(BURL_MESSAGE);
        Poruke.ispisiGreske();
    }
}

function validateBitbucketSSH(x) {
    if( !Validacija.validirajPassword(x) ) {
        Poruke.dodajPoruku(BSSH_MESSAGE);
        Poruke.ispisiGreske();

    } else {
        Poruke.ocistiGresku(BSSH_MESSAGE);
        Poruke.ispisiGreske();
    }
}

function validateRepoName(x) {

    if( !Validacija.validirajNazivRepozitorija(null,x) ) {
        Poruke.dodajPoruku(REPO_NAME_MESSAGE);
        Poruke.ispisiGreske();
    } else {
        Poruke.ocistiGresku(REPO_NAME_MESSAGE);
        Poruke.ispisiGreske();
    }
}

function validateName(x) {
    if( !Validacija.validirajImeiPrezime(x) ) {
        Poruke.dodajPoruku(NAME_MESSAGE);
        Poruke.ispisiGreske();
    } else {
        Poruke.ocistiGresku(NAME_MESSAGE);
        Poruke.ispisiGreske();
    }
}

function validateSemester(x) {
    if( x==="ljetni" || x==="Ljetni" ) {
        Validacija.postaviTrenSemestar(1);
        Poruke.ocistiGresku(SEMESTER_MESSAGE);
        Poruke.ispisiGreske();
    } else if( x==="zimski" || x==="Zimski" ) {
        Validacija.postaviTrenSemestar(0);
        Poruke.ocistiGresku(SEMESTER_MESSAGE);
        Poruke.ispisiGreske();
    } else {
        Poruke.dodajPoruku(SEMESTER_MESSAGE);
        Poruke.ispisiGreske();
    }
}