var redovi=[1,2,3,4,5];


function moveDown(index)
{
    stvarna_pozicija=redovi[index-1];

    var rows = document.getElementById("table_id").rows, parent = rows[stvarna_pozicija ].parentNode;

         if(stvarna_pozicija < rows.length -1){
            parent.insertBefore(rows[stvarna_pozicija+1],rows[stvarna_pozicija]);
            for(var i=0; i<rows.length-1; i++){
                if(stvarna_pozicija+1==redovi[i]) redovi[i]--;
                else if(stvarna_pozicija==redovi[i]) redovi[i]++;
            }
        }
}

function moveUp(index)
{
    stvarna_pozicija=redovi[index-1];
    var rows = document.getElementById("table_id").rows, parent = rows[stvarna_pozicija].parentNode;

        if(stvarna_pozicija > 1){
            parent.insertBefore(rows[stvarna_pozicija],rows[stvarna_pozicija - 1]);
            for(var i=0; i<rows.length-1; i++){
                if(stvarna_pozicija-1==redovi[i]) redovi[i]++;
                else if(stvarna_pozicija==redovi[i]) redovi[i]--;
            }
        }
}
