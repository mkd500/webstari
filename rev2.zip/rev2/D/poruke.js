var Poruke=(function(){
    var idDivaPoruka;
    var mogucePoruke=["Email koji ste napisali nije validan fakultetski email",
    "Indeks kojeg ste napisali nije validan",
    "Nastavna grupa koju ste napisali nije validna",
    "Akademska godina koju ste unijeli nije ispravna",
    "Password ne zadovoljava uslove za password. Potrebno je imati bar jedan broj, jedno veliko i jedno malo slovo.",
    "Passwordi koje ste unijeli se ne poklapaju",
    "Unijeli ste Bitbucket URL koji nije validan",
    "Unijeli ste Bitbucket SSH koji nije validan",
    "Naziv repozitorija koji ste unijeli nije ispravan",
    "Ime i prezime koje ste unijeli nije ispravno",
    "Semestar može biti ili ljetni ili zimski"];
    var porukeZaIspis=[];
    
    
    ispisi=function(){ //​… funkcija koja ispisuje greške u div
        var tekst="";
        for(var i=0; i<porukeZaIspis.length; i++)
        {
            tekst=tekst  +porukeZaIspis[i] + "\n";
        }
        
        document.getElementById(idDivaPoruka).innerText=tekst;
    }
    postavi=function(divID){// ​… funkcija koja postavlja id diva
        idDivaPoruka=divID;
    }
    dodaj=function(broj){//​… funkcija koja dodaje poruku u niz poruka za ispis
        var index = porukeZaIspis.indexOf(mogucePoruke[broj]);
        if(index==-1) porukeZaIspis.push(mogucePoruke[broj]);
    }
    ocisti=function(broj){//… funkcija koja brise iz niza gresku (ako postoji)
        var index = porukeZaIspis.indexOf(mogucePoruke[broj]);
        
        if (index > -1) {
           porukeZaIspis.splice(index, 1);
        }

        ispisi();
    }
    return{
        ispisiGreske: ispisi,
        postaviIdDiva: postavi,
        dodajPoruku: dodaj,
        ocistiGresku: ocisti
    }
}());