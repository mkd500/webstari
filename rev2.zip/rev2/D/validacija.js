
var Validacija=(function(){
    var maxGrupa=7;
    var trenutniSemestar=0;//0 za zimski, 1 za ljetni semestar

    var Fakultetski = function(email)
    {
        var re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@(etf.unsa.ba)*$/igm;
        return re.test(email);
    }

    var Index = function(index)
    {
        var re =/^[1][0-9]{4}$/g;
        return re.test(index);
    }

    var Grupa = function(grupa)
    {
        if(grupa>0 && grupa<=maxGrupa)return true;
        return false;
    }
    var AkGod = function(godina){
        try 
        {
            godine=godina.split("/");
            var re=/[0-9]{4}/g;
            if(!re.test(godine[0])) return false;
            var re=/[0-9]{4}/g;
            if(!re.test(godine[1])) return false;
            var zimski =godine[0][2]+godine[0][3];
            var ljetni=godine[1][2]+godine[1][3];
            var zs=parseInt(zimski); 
            var ls=parseInt(ljetni);
            return (ls==(zs+1));

        }
        catch(err){
            return false;
        }
    }
    var Password = function(pw)
    {
        var re=/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d$@$!%*?&]{7,20}$/g;
        return re.test(pw);
    }

    var Potvrda = function(sifra1,sifra2)
    {
        return sifra1===sifra2;
    }

    var BitbucketURL = function(urlBitbucket)
    {
        var re = /^(http[s]?:\/\/){0,1}[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@(bitbucket.org)*\/[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+\/[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+(.git)$/g;
        return re.test(urlBitbucket);
    }
    
    var BitbucketSSH = function(ssh)
    {
        var re = /^(git@bitbucket.org:)[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+\/[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+(.git)$/g;
        return re.test(ssh);
    }

    var NazivRepozitorija = function(reg, naziv)
    {
        if(reg==null){
            reg=/^(wt[Pp]rojekat)1[0-9]{4}$/g;
            return reg.test(naziv);
        }
        return reg.test(naziv);
    }

    var ImeiPrezime = function(ime)
    {
        if(ime.length==0) return false;
        var regex = /^([A-ZŠĆĐŽČ][a-zšđžćč']{2,11}[-\s]?)*$/g;
        return regex.test(ime);
    }

    var MaxGrupa = function(mgrupa)
    {
        MaxGrupa=mgrupa;
    }

    var TrenSemestar = function(semestar)
    {
      if(semestar!=0 && semestar!=1) return false;
      trenutniSemestar=semestar;
      return true;
    }

    return{
    validirajFakultetski: Fakultetski,
    validirajIndex: Index,
    validirajGrupu: Grupa,
    validirajAkGod: AkGod,
    validirajPassword: Password,
    validirajPotvrdu: Potvrda,
    validirajBitbucketURL: BitbucketURL,
    validirajBitbucketSSH: BitbucketSSH,
    validirajNazivRepozitorija: NazivRepozitorija,
    validirajImeiPrezime: ImeiPrezime,
    postaviMaxGrupa: MaxGrupa,
    postaviTrenSemestar: TrenSemestar
    }
}());

