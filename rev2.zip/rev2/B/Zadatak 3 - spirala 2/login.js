var x = document.getElementById("regNastavikaDiv");
var y = document.getElementById("regStudentaDiv");



function registrujNastavnika() {
 
    if (x.style.display == "none" || x.style.display == "") {
    	y.style.display = "none";
        x.style.display = "inline-block";
        document.getElementById("poruke").style.display = "none";
    } 
}
function registrujStudenta() {

    if (y.style.display == "none") {
    	x.style.display = "none";
        y.style.display = "inline-block";
        document.getElementById("poruke2").style.display = "none";
    } 
}
function validirajImePrezimeNastavnika(){
	var imeprezime = document.getElementById("imeprezimeinputnastavnik").value;
    document.getElementById("imeValidateLabel").innerHTML =  "";
    Poruke.postaviIdDiva("poruke2");
    Poruke.ocistiGresku(1);
    Poruke.ispisiGreske();
    if(!Validacija.validirajImeiPrezime(imeprezime)){
	   document.getElementById("imeValidateLabel").innerHTML = "Unesite ispravno ime i prezime nastavnika!"
	   Poruke.dodajPoruku(1);
	   Poruke.ispisiGreske();
	}
}
function validirajMailNastavnika(){
	var mail = document.getElementById("mailInput").value;
	document.getElementById("mailLabel").innerHTML = "";
	Poruke.postaviIdDiva("poruke2");
	Poruke.ocistiGresku(9);
	Poruke.ispisiGreske();
	if(!Validacija.validirajFakultetski(mail)){
		document.getElementById("mailLabel").innerHTML = "Email neispravno unesen!";
		Poruke.dodajPoruku(9);
  	    Poruke.ispisiGreske();
	}
}
function validirajPassword(){
	var pass = document.getElementById("passwordNastavnika").value;
	document.getElementById("passValidateNastavik").innerHTML = "";
	Poruke.postaviIdDiva("poruke2");
	Poruke.ocistiGresku(2);
	Poruke.ispisiGreske();
	if(!Validacija.validirajPassword(pass)){
		document.getElementById("passValidateNastavik").innerHTML = "Neispravno unesen password!"
		Poruke.dodajPoruku(2);
	    Poruke.ispisiGreske();
	}
}
function validacijaStudentPass(){
	
	var pass = document.getElementById("passStudent").value;
	document.getElementById("passStudentValLabel").innerHTML = "";
	 Poruke.postaviIdDiva("poruke");
	 Poruke.ocistiGresku(2);
	 Poruke.ispisiGreske();
	if(!Validacija.validirajPassword(pass)){
		document.getElementById("passStudentValLabel").innerHTML = "Neispravno unesen password!"
		Poruke.dodajPoruku(2);
	    Poruke.ispisiGreske();
	}
}
function validirajPotvrduPassworda(){
	var potPass = document.getElementById("passwordNastavnika").value;
	var pass = document.getElementById("passwordPotvrdaInput").value;
	document.getElementById("passwordPotvrdaLabel").innerHTML="";
	Poruke.postaviIdDiva("poruke");
	Poruke.ocistiGresku(4);
	Poruke.ispisiGreske();
	if(!Validacija.validirajPotvrdu(potPass,pass)){
	   document.getElementById("passwordPotvrdaLabel").innerHTML="Neispravno potvrden password!";
	   Poruke.dodajPoruku(4);
	   Poruke.ispisiGreske();
	}
}
function validirajImePrezimeStudenta(){
	var imeprezime = document.getElementById("imeprezimeinputstudent").value;

    document.getElementById("imeprezStduentaVal").innerHTML =  ""
    Poruke.postaviIdDiva("poruke");
    Poruke.ocistiGresku(1);
    Poruke.ispisiGreske();
	if(imeprezime == ""){
		document.getElementById("imeprezStduentaVal").innerHTML = "Unesite ime i prezime studenta!"
	}
	else if(!Validacija.validirajImeiPrezime(imeprezime)){
	   document.getElementById("imeprezStduentaVal").innerHTML = "Unesite ispravno ime i prezime studenta!"
	   Poruke.dodajPoruku(1);
	   Poruke.ispisiGreske();
	}
}
function validirajIndexStudenta(){
	var index = document.getElementById("indexStudenta").value;
	document.getElementById("indexValLabel").innerHTML = "";
	Poruke.postaviIdDiva("poruke");
	Poruke.ocistiGresku(10);
	Poruke.ispisiGreske();
	if(!Validacija.validirajIndex(index)){
		document.getElementById("indexValLabel").innerHTML = "Neispravno unesen broj indexa!";
		Poruke.dodajPoruku(10);
	    Poruke.ispisiGreske();
	}
}

function validirajPotvrduPassStudenta(){
	var potPass = document.getElementById("studentPassPotvrdaInput").value;
	var pass = document.getElementById("passStudent").value;
	Poruke.postaviIdDiva("poruke");
	Poruke.ocistiGresku(4);
	Poruke.ispisiGreske();
	document.getElementById("passPotvrdaStudentValLabel").innerHTML="";
	if(!Validacija.validirajPotvrdu(potPass,pass)){
		document.getElementById("passPotvrdaStudentValLabel").innerHTML="Neispravno potvrden password!";
		Poruke.dodajPoruku(4);
	    Poruke.ispisiGreske();
	}
}
function validirajStudentSSH(){
	document.getElementById("bitbucketValLabel").innerHTML ="";
	var sshString = document.getElementById("sshInput").value;
	var korIme = document.getElementById("korisnickoImeInput").value;
	var repoz = document.getElementById("nazivRepozInput").value;
	Validacija.korisnickoIme = korIme;
	Validacija.nazivRepozitorija = repoz;
	Poruke.postaviIdDiva("poruke");
	Poruke.ocistiGresku(7);
	Poruke.ispisiGreske();
	if(korIme == "") {
		document.getElementById("bitbucketValLabel").innerHTML ="Morate unijeti korisnicko ime iznad!";
		Poruke.dodajPoruku(7);
	   	Poruke.ispisiGreske();
	}
	
	else if(!Validacija.validirajNazivRepozitorija(null, repoz)){
		document.getElementById("bitbucketValLabel").innerHTML ="Moreate unijeti ispravan naziv repozitorija iznad!";
		Poruke.dodajPoruku(7);
	   	Poruke.ispisiGreske();
	}
	else if(!Validacija.validirajBitbucketSSH(sshString)){
		Poruke.dodajPoruku(7);
	   	Poruke.ispisiGreske();
		document.getElementById("bitbucketValLabel").innerHTML ="Neispravno unesen SSH! Provjerite korisnicko ime i naziv repozitorija";
	}
}
function validirajKorisnickoIme(){
	var username = document.getElementById("korisnickoImeInput").value;
	document.getElementById("korImeLabelStudent").innerHTML = "";
	if(username=="") {
		document.getElementById("korImeLabelStudent").innerHTML = "Unesite korisnicko ime!";
	}
}
function validirajNazivRepoz(){
	var repoz = document.getElementById("nazivRepozInput").value;
	document.getElementById("nazivRepozValLabel").innerHTML = "";
	Poruke.postaviIdDiva("poruke");
  	Poruke.ocistiGresku(11);
  	Poruke.ispisiGreske();
	if(!Validacija.validirajNazivRepozitorija(null,repoz))
		document.getElementById("nazivRepozValLabel").innerHTML = "Neispravno unesen naziv repozitorija!";
		Poruke.dodajPoruku(11);
	   	Poruke.ispisiGreske();
}

function validirajAkGod(){
	if(!x.style.display == "" ){
		var akGod = document.getElementById("akGodNast").value;
		document.getElementById("akgodNastLabel").innerHTML = "";
		Poruke.postaviIdDiva("poruke2");
		Poruke.ocistiGresku(5);
		Poruke.ispisiGreske();
		if(!Validacija.validirajAkGod(akGod)){
			document.getElementById("akgodNastLabel").innerHTML = "Niste unjieli ispravan format akademske godine 20AB/20CD!";
			Poruke.dodajPoruku(5);
		    Poruke.ispisiGreske();
		}
	}
	var akGod = document.getElementById("akGodInput").value;
	document.getElementById("akGodLabelVal").innerHTML = "";
	Poruke.postaviIdDiva("poruke");
	Poruke.ocistiGresku(5);
	Poruke.ispisiGreske();
	if(akGod == ""){
		document.getElementById("akGodLabelVal").innerHTML = "Unesite akademsku godinu!";
		Poruke.dodajPoruku(5);
	    Poruke.ispisiGreske();
	  }
	else if(!Validacija.validirajAkGod(akGod)){
		document.getElementById("akGodLabelVal").innerHTML = "Niste unjieli ispravan format akademske godine 20AB/20CD!";
		Poruke.dodajPoruku(5);
	    Poruke.ispisiGreske();
	}
}
function validirajStudentURL(){
	var url = document.getElementById("bitcuketURLInput").value;
	document.getElementById("bitbucketURLValLabel").innerHTML ="";
	Poruke.postaviIdDiva("poruke");
	Poruke.ocistiGresku(6);
	Poruke.ispisiGreske();
	if(!Validacija.validirajBitbucketURL(url)){
		document.getElementById("bitbucketURLValLabel").innerHTML ="Niste unijeli ispravan bit bucket URL!";
		Poruke.dodajPoruku(6);
	    Poruke.ispisiGreske();
	}
}

function validirajBrojGrupeStudenta(){
	var broj = document.getElementById("brGrupeStudenta").value;
	document.getElementById("brGrupeLabel").innerHTML = "";
	Poruke.postaviIdDiva("poruke");
	Poruke.ocistiGresku(0);
	Poruke.ispisiGreske();
	if(!Validacija.validirajGrupu(broj)){
		document.getElementById("brGrupeLabel").innerHTML = ("Broj grupa je preko maksimalnog broja 7");
		Poruke.dodajPoruku(0);
		Poruke.ispisiGreske();
	}
}



