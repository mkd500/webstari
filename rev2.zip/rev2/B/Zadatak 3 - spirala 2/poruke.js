var Poruke =(function(){
    var idDivaPoruka = "";
	var maxBroj=20;
	var mogucePoruke=[
	/*0*/"Broj gupre je max 7 ",
	/*1*/"Neispravno ime i prezime! ",
	/*2*/"Neispravan password!  ",
	/*3*/"Unesite ime i prezime!  ",
	/*4*/"Passwordi se ne poklapaju!  ",
	/*5*/"Akademska godian nije ispravnog formata ili nije unijeta!  ",
	/*6*/"Bitbucket URL neispravan!  ",
	/*7*/"SSH nije ispravan!  ",
	/*8*/"Neispravan index!  ",
	/*9*/"Neispravno unesen mail!  ",
	/*10*/"Neispravan broj indexa!  ",
	/*11*/"Neispravan format naziva repozitorija! "];
	var porukeZaIspis=[];
    var ispisiGreske = function(){
		document.getElementById(idDivaPoruka).innerHTML = porukeZaIspis;
		console.log(porukeZaIspis);
		console.log(mogucePoruke);

	}
	var postaviIdDiva = function(idDiva){
		idDivaPoruka = idDiva;
	}
	var dodajPoruku = function(broj){
		if(broj>=0 && broj < maxBroj ){
			porukeZaIspis.push(mogucePoruke[broj]);
		}
		
	}
	var ocistiGresku = function(broj){
		var index = porukeZaIspis.indexOf(mogucePoruke[broj]);
		if (index >= 0) {
		 porukeZaIspis.splice(index,1);
		}
	}
	
    return {
     	ispisiGreske:ispisiGreske,
		postaviIdDiva:postaviIdDiva,
		dodajPoruku:dodajPoruku,
		ocistiGresku:ocistiGresku
  }

}());
