function upClick(){
	var table = document.getElementById("ukTable");
	index = this.rowIndex;
	var rows = document.getElementById("ukTable").rows,parent = rows[index].parentNode;
        if(direction === "up")
        {
            if(index > 1){
                parent.insertBefore(rows[index],rows[index - 1]);
                // when the row go up the index will be equal to index - 1
                index--;
            }
        }
}