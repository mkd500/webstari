
/*Validacija model*/
var Validacija = (function() {
  var korisnickoIme;
  var username;
  var username2;
  var nazivRepozitorija;
  var maxGrupa = 7;
  var trenutniSemestar = 0; //0   za   zimski,   1   za   ljetni   semestar
  //a
  var validirajFakultetski = function(email) {
    var re = new RegExp('^[a-zA-Z0-9_]+@etf.unsa.ba$');
    return re.test(email);
  };
  //b
  var validirajIndex = function(index) {
    var re1 = new RegExp('^1[0-9]{4}$');
    return re1.test(index);
  };
  //c
  var validirajGrupu = function(grupa) {
    grupa = parseInt(grupa);
    if (grupa > 0 && grupa <= maxGrupa) return true;
    return false;
  };
  //d
  var validirajAkGod = function(akGodine) {
    //deifniram regex koji ce provjeriri da li je formata 20AB/20CD
    var re2 = new RegExp('^20[0-9]{2}[/w]20[0-9]{2}');
    //ako je regex u datom formatu i ako posljednja cifra prve godine je za jedno manja
    //onda pogledati da li je trenutni semestar zimski ili ljetni
    if ( re2.test(akGodine) && parseInt(akGodine[3]) + 1 == parseInt(akGodine[8])
    ) {
      //ako je zimski onda podstring od 0 - 4 tj prva godina unutar stringa mora biti jednaka trenutnoj godini
      if (trenutniSemestar == 0) {
        if (parseInt(akGodine.substring(0, 4)) == new Date().getFullYear())
          return true;
      } else {
        //ako je ljetni onda podstring od 5 - 9 tj druga godina mora biti jednaka trenutnoj godini
        if (parseInt(akGodine.substring(5, 9)) == new Date().getFullYear())
          return true;
      }
    }
    //u suprotnom je false
    return false;
  };
  //e
  var validirajPassword = function(password) {
    var validated = true;
    if (password.length < 7 || password.length > 20) validated = false;
    if (!/\d/.test(password)) validated = false;
    if (!/[a-z]/.test(password)) validated = false;
    if (!/[A-Z]/.test(password)) validated = false;

    return validated;
  };
  //f
  var validirajPotvrdu = function(pass1, pass2) {
    if (validirajPassword(pass1) && validirajPassword(pass2) && pass1 == pass2)
      return true;
    return false;
  };
  //g
  var validirajBitbucketURL = function(str) {
    
    // https://   protokolom   nakon   čega   slijedi username@bitbucket.org/username2/nazivRepozitorija.git.
    var regURL = new RegExp(
      'https://' +
        Validacija.username +
        '@bitbucket.org/' +
        Validacija.username2 +
        '/[a-zA-Z0-9_]+.git$'
    );

    return regURL.test(str);
  };
  //h
  var validirajBitbucketSSH = function(sshstring) {
    //Validan   SSH   počinje   sa   git@bitbucket.org   nakon   čega   slijedi :korisnickoIme/nazivRepozitorija.git.
    var regSSH = new RegExp(
      "^git@bitbucket.org:" + Validacija.korisnickoIme + "/" + Validacija.nazivRepozitorija + ".git$"
    );
    return regSSH.test(sshstring);
  };
  //i
  var validirajNazivRepozitorija = function(regNaziv, naziv) {
    if (regNaziv !== null) {
      return regNaziv.test(naziv);
    }

    var regLocal = new RegExp('^wtProjekat[0-9]{5}$');
    return regLocal.test(naziv);
  };
  //j
  var validirajImeiPrezime = function(strIM) {
    var regIme = new RegExp('([A-Z][a-z“”\'"-]{2,12}s*)+$');
    return regIme.test(strIM);
  };
  return {
    validirajFakultetski: validirajFakultetski,
    validirajIndex: validirajIndex,
    validirajGrupu: validirajGrupu,
    validirajAkGod: validirajAkGod,
    validirajPassword: validirajPassword,
    validirajPotvrdu: validirajPotvrdu,
    validirajBitbucketURL: validirajBitbucketURL,
    validirajBitbucketSSH: validirajBitbucketSSH,
    validirajNazivRepozitorija: validirajNazivRepozitorija,
    validirajImeiPrezime: validirajImeiPrezime,
  };
})();
