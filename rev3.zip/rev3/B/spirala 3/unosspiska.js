var Unosspiska = (function() {
return { kreirajSpisakFn:function() {
  var spisak=document.getElementById('spisak').value;
  var spirala=document.getElementById('spirala').value;

  var ajax = new XMLHttpRequest();
  ajax.onreadystatechange = function() {
    if (ajax.readyState == 4 && ajax.status == 200)
    {
      console.log('Uspješno ste kreirali fajl.');
    }
    else if (ajax.readyState == 4) {
      console.log("doslo je do greske")
    }
  }
  ajax.open("POST", "http://localhost:3000/spisak", true);
  ajax.setRequestHeader("Content-Type", "application/json");
  ajax.send(JSON.stringify({
    spisak,
    spirala
  }));
  }
}
}());
