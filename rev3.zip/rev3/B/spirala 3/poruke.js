var poruke=(function(){
  var idDivaPoruka;
  var mogucePoruke=["Email koji ste napisali nije validan fakultetski email  ",
  "Indeks kojeg ste napisali nije validan",
  "Nastavna grupa koju ste napisali nije validna",
  "Odabrana akademska godina nije validna",
  "Uneseni password nije validan",
  "Uneseni password nije potvrđen",
  "Uneseni Bitbucket Url nije validan",
  "Uneseni Bitbucket SSH nije validan",
  "Uneseni naziv repozitorija nije validan",
  "Uneseno ime i prezime nije validno"
];
  var porukeZaIspis=[];

  return{
  //ispisiGreske: ​… funkcija koja ispisuje greške u div,
  //postaviIdDiva: ​… funkcija koja postavlja id diva,
  dodajPoruku:function(broj){
    if(porukeZaIspis.length==0)
    {
      porukeZaIspis.push(mogucePoruke[broj]);
      console.log("hhhh");
      return;
    }
    for(i=0;i<porukeZaIspis.length;i++){
      if(mogucePoruke[broj]===porukeZaIspis[i])
        return;
      //  if(i==porukeZaIspis.length)porukeZaIspis.push(mogucePoruke[broj]);
      }
      porukeZaIspis.push(mogucePoruke[broj]);
    },


// Treba obrisati pogresan
    ocistiGresku:function(broj){
      for(i=0;i<porukeZaIspis.length;i++){
        if(mogucePoruke[broj]===porukeZaIspis[i])
          porukeZaIspis.splice(i,1);
      }


    //  porukeZaIspis.splice(broj-1,1);
    },

    postaviIdDiva:function(div){
      idDivaPoruka=div;
    },

    ispisiGreske:function(){
      console.log("ispisi greskuu");
      idDivaPoruka.innerHTML = "";
      for(i=0;i<porukeZaIspis.length;i++){
      idDivaPoruka.innerHTML+=porukeZaIspis[i]+"<br>";
      }
    }


  //ocistiGresku: ​… funkcija koja brise iz niza gresku (ako postoji)
}
}());
