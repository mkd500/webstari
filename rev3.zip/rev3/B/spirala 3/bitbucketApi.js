var BitbucketApi = (function(){
    return {
        dohvatiAccessToken: function(key, secret, fnCallback){
          if (key === null || secret === null) {
          fnCallback(-1, "Key ili secret nisu pravilno proslijeđeni!");
          return;
        }
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function() {
          if (ajax.readyState == 4 && ajax.status == 200)
            fnCallback(null, JSON.parse(ajax.responseText).access_token);
          else if (ajax.readyState == 4)
            fnCallback(ajax.status, null);
        }
        ajax.open("POST", "https://bitbucket.org/site/oauth2/access_token", true);
        ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        ajax.setRequestHeader("Authorization", 'Basic ' + btoa(key + ":" + secret));
        ajax.send("grant_type=" + encodeURIComponent("client_credentials"));
        },
        dohvatiRepozitorije: function(token, godina, naziv, branch, fnCallback){},

        dohvatiBranch: function(token, url, naziv, fnCallback){
     if(token==null || url==null){
         fnCallback(-1,"Key ili secret nisu pravilno proslijedjeni!")
     }

     var ajax = new XMLHttpRequest();

      ajax.onreadystatechange = function() {
            if (ajax.readyState == 4 && ajax.status == 200)
            {
             var tmp=ajax.responseText;
             for(var i=0; i<tmp.values.length;i++){
                 if(tmp.values[i].name==naziv)
                 fnCallback(null,true);}

            }
            else if (ajax.readyState == 4)
                fnCallback(ajax.status, false);
        }
        ajax.open("GET", url, true);
        ajax.setRequestHeader("Authorization", 'Bearer ' + token);
        ajax.send();

 }
    }
})();
