var express = require('express');
var bodyParser = require('body-parser');
var fs = require('fs');
var app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(express.static(__dirname));
//"public"
app.get('/', function(request, response) {
  // if(!request.query.godina){
  //   console.log("Nije postavljenja godina")
  // }
  response.sendFile('index.html', {
    root: __dirname
  });
});

app.get('/login.html', function(request, response) {
  //bilo koji link
  response.sendFile('login.html', {
    root: __dirname
  });
});

app.get('/statistika.html', function(request, response) {
  response.sendFile('statistika.html', {
    root: __dirname
  });
});

app.get('/unoskomentara.html', function(request, response) {
  response.sendFile('unoskomentara.html', {
    root: __dirname
  });
})

app.get('/unosspiska.html', function(request, response) {
  response.sendFile('unoskomentara.html', {
    root: __dirname
  });
})

app.get('/nastavnik.html', function(request, response) {
  response.sendFile('nastavnik.html', {
    root: __dirname
  });
})

app.post('/spisak', function(req, res) {
  console.log(req.body);
  console.log('_______');
  req.body.spisak = req.body.spisak.split('\n');
  var rez = [];
  for(var i = 0; i < req.body.spisak.length; i++){
    rez.push(req.body.spisak[i].split(','));
  }
  fs.writeFile('spisakS' + req.body.spirala + '.json', JSON.stringify(rez,null,2), function(err) {
    if (err) throw err;
    res.json({
      message: "Uspješno dodan red",
      data: null
    });
  });
})



app.post('/komentar', function(req, res) {
  console.log(req.body);
  console.log("III");
  fs.writeFile('markS' + req.body.spirala + req.body.index + ".json", JSON.stringify(req.body.sadrzaj,null,2), function(err) {
    if (err) res.json({
      message: "Podaci nisu u trazenom formatu!",
      data: null
    });
    else
    res.json({
      message: "Uspješno kreirana datoteka!",
      data: req.body.sadrzaj
    });
  });
});





app.post('/lista', function(req, res) {
  console.log(req.body);
  fs.writeFile('spisak' + req.body.godina, req.body.sadrzaj, function(err) {
    if (err) res.json({
      message: "Podaci nisu u trazenom formatu!",
      data: null
    });
    res.json({
      message: "Lista uspješno kreirana",
      data: 100
    });
  });
  res.send("nesta");
});


app.post('/bodovi', function(req, res) {
  console.log(req.body);
  console.log("Zasto ova nije");

  fileocjene = "markS" + req.body.spirala + req.body.index + ".json";
  var arrLines = [];
  var zbirOcjena = 0;
  var prosjecnaOcjena;
  fs.stat(fileocjene, function(err, stat) {
    var data = JSON.parse(fs.readFileSync(fileocjene));
    console.log(data);
    arrLines = data;
    for (var i = 0; i < arrLines.length; i++) {
      zbirOcjena += arrLines[i].ocjena;
    }

    prosjecnaOcjena = zbirOcjena / arrLines.length;
    if (prosjecnaOcjena < 1) prosjecnaOcjena = 0;
    else if (prosjecnaOcjena < 2 && prosjecnaOcjena >= 1) prosjecnaOcjena = 1 + 1;
    else if (prosjecnaOcjena < 3 && prosjecnaOcjena >= 2) prosjecnaOcjena = 2 + 1;
    else if (prosjecnaOcjena < 4 && prosjecnaOcjena >= 3) prosjecnaOcjena = 3 + 1;
    else if (prosjecnaOcjena < 5 && prosjecnaOcjena >= 5) prosjecnaOcjena = 4 + 1;
    else prosjecnaOcjena = 5 + 1;

    console.log(prosjecnaOcjena);
    console.log(prosjecnaOcjena);

    res.json({
      message: "Prosjecno osvojeno mjesto je: " + prosjecnaOcjena,
      data: 100
    });
  });

});




app.post('/izvjestaj', function(req, res) {
  //console.log(req.body);
  var tekst = "";
  var file2read = "spisakS" + req.body.spirala + ".json";
  fs.readFile(file2read, function(err, fileContents) {
    if (err) throw err;
    //console.log(fileContents)
  });
  var spisak = require("./" + file2read);
  var moguceSifre = ["A", "B", "C", "D", "E", "Z"];
  var brIndexa = [];
  var sifre = [];

  for (var i = 0; i < spisak.length; i++) {
    var brIndexa_tmp = spisak[i][0];
    for (var j = 1; j < spisak[i].length; j++) {

      if (spisak[i][j] == req.body.index) {
        var br_sifre = j - 1;
        if (br_sifre > 0) {
          var sifre_tmp = moguceSifre[br_sifre];
          brIndexa.push(brIndexa_tmp);
          sifre.push(sifre_tmp);
        }
      }
    }
  }
  var komentari = "";
  for (var i = 0; i < brIndexa.length; i++) {
    fileocjene = "markS" + req.body.spirala + brIndexa[i] + ".json";
    var arrLines = [];
    //fs.stat(fileocjene, function(err, stat) {
    var data = JSON.parse(fs.readFileSync(fileocjene));
      arrLines = data;
      for (var j = 0; j < arrLines.length; j++) {
        if (arrLines[j].siifra_studenta == sifre[i]) {
          komentari += arrLines[j].tekst + "\n##########\n";
        }
        if(sifre[i]=="Z")
        komentari += "\n##########\n";
      }
  }
  console.log(komentari);

  fs.writeFile('izvjestajS' + req.body.spirala + req.body.index + ".txt", komentari, function(err) {
    if (err) res.json({
      message: "Podaci nisu u trazenom formatu!",
      data: null
    });
    else
    res.json({
      message: "Lista uspješno kreirana",
      data: komentari.lenghth
    });
  });
});
app.listen(3000);;
