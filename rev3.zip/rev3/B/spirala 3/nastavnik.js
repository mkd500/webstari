var Nastavnik = (function() {
  function brojDiva(id){
    var elementdiv = document.getElementById(id);
    var i = 0;
    while(elementdiv.previousElementSibling != null){
      elementdiv = elementdiv.previousElementSibling;
      i++;
    }
    return i;
  }
  return {
    generisiIzvjestajFn: function() {
      var index = document.getElementById('indexId').value;
      var spirala = document.getElementById('spiralaId').value;
      KreirajFajl.kreirajIzvjestaj(spirala, index, function(error, data) {
        if (error != null) {
          console.log(erorr);
        } else {
          console.log(data);
        }
      });
    },
    generisiBodoveFn: function() {
      console.log("Pozvana");
      var index = document.getElementById('indexId').value;
      var spirala = document.getElementById('spiralaId').value;
      KreirajFajl.kreirajBodove(spirala, index, function(error, data) {
        if (error != null) {
          console.log(error);
        } else {
          console.log(data);
        }
      });
    },
    kreirajKomentarFn: function() {
      console.log("Pozvana");
      var index = document.getElementById('indexId').value;
      var spirala = document.getElementById('spiralaId').value;
      var sadrzaj = [];
      var sifreStudenata = [];
      var komentari = [];
      var ocjene = [];
        console.log(document.getElementById('sifra1').name);

        sadrzaj.push({
          sifreStudenta: 'A',
          tekst: document.getElementById('sifra1').value,
          ocjena: brojDiva('A')

        },);
        sadrzaj.push({
          sifreStudenta: 'B',
          tekst: document.getElementById('sifra2').value,
          ocjena: brojDiva('B')
        },);
        sadrzaj.push({
          sifreStudenta: 'C',
          tekst: document.getElementById('sifra3').value,
          ocjena: brojDiva('C')
        },);
        sadrzaj.push({
          sifreStudenta: 'D',
          tekst: document.getElementById('sifra4').value,
          ocjena: brojDiva('D')
        },);
        sadrzaj.push({
          sifreStudenta: 'E',
          tekst: document.getElementById('sifra5').value,
          ocjena: brojDiva('E')
        });

      KreirajFajl.kreirajKomentar(spirala, index, sadrzaj, function(error, data) {
        if (error != null) {
          console.log(error);
        } else {
          console.log(data);
        }
      });

    },
    brojDiva:brojDiva
  }
}());
