var KreirajFajl = (function() {
  return {
    kreirajKomentar: function(spirala, index, sadrzaj, fnCallback) {
      console.log(sadrzaj);
      if (spirala != null && index != null && sadrzaj != null) {
        var sadrzaj_tmp = sadrzaj;
        if (!sadrzaj_tmp[0].hasOwnProperty('sifra_studenta') || !sadrzaj_tmp[0].hasOwnProperty('tekst') || !sadrzaj_tmp[0].hasOwnProperty('ocjena'))
          fnCallback(-1, "Neispravni parametri");
      } else if (spirala == null || index == null || sadrzaj == null) {
        fnCallback(-1, "Neispravni parametri");
      }

      var jsonOdg = {
        spirala,
        index,
        sadrzaj
      };

      var ajax = new XMLHttpRequest();

      ajax.onreadystatechange = function() {
        if (ajax.readyState == 4 && ajax.status == 200)
          document.getElementById("kontenjer").innerHTML = ajax.responseText;
        fnCallback(null, ajax.responseText);
        if (ajax.readyState == 4 && ajax.status == 404)
          document.getElementById("kontenjer").innerHTML = "Greska: nepoznat URL";
        fnCallback(ajax.status, ajax.responseText);

      }

              ajax.open("POST","komentar", true);
              ajax.setRequestHeader("Content-Type", "application/json");
              ajax.send(JSON.stringify(jsonOdg));
    },
    /*ajax.open("POST", "http://localhost:3000/komentar", true);
    ajax.setRequestHeader("Content-Type", "application/json");
    var JSONobjekat = { spirala: spirala, index: index, sadrzaj: sadrzaj};
    //{‘spirala’:’1’,’index’:’12345’,’sadrzaj’:[{‘sifra_studenta’:’A’,’tekst’:’Neki tekst’,’ocjena’:0},...]},
    ajax.send("spirala=" + spirala + "&index=" + index + "&sadrzaj=" + sadrzaj );*/



    kreirajListu: function(godina, nizRepozitorija, fnCallback) {

      if (godina != null && nizRepozitorija != null) {
        if (nizRepozitorija.length == 0)
          fnCallback(-1, "Neispravni parametri");
      } else if (godina == null || nizRepozitorija == null) {
        fnCallback(-1, "Neispravni parametri");
      }

      var jsonOdg = {
        godina,
        nizRepozitorija
      };

      var ajax = new XMLHttpRequest();

      ajax.onreadystatechange = function() {
        if (ajax.readyState == 4 && ajax.status == 200)
          document.getElementById("kontenjer").innerHTML = ajax.responseText;
        fnCallback(null, ajax.responseText);
        if (ajax.readyState == 4 && ajax.status == 404)
          document.getElementById("kontenjer").innerHTML = "Greska: nepoznat URL";
        fnCallback(ajax.status, ajax.responseText);


      }
      ajax.open("POST", serverIP + "/lista", true);
      ajax.setRequestHeader("Content-Type", "application/json");
      ajax.send(JSON.stringify(jsonOdg));
    },

    kreirajIzvjestaj: function(spirala, index, fnCallback) {
      if (spirala == null || index == null) {
        fnCallback(-1, "Neispravni parametri");
      }
      var jsonOdg = {
        spirala,
        index
      };
      var ajax = new XMLHttpRequest();
      ajax.onreadystatechange = function() {
        if (ajax.readyState == 4 && ajax.status == 200)
          document.getElementById("kontenjer").innerHTML = ajax.responseText;
        fnCallback(null, ajax.responseText);
        if (ajax.readyState == 4 && ajax.status == 404) {
          document.getElementById("kontenjer").innerHTML = "Greska: nepoznat URL";
          fnCallback(ajax.status, ajax.responseText);
        }
      }
      ajax.open("POST", "izvjestaj", true);
      ajax.setRequestHeader("Content-Type", "application/json");
      ajax.send(JSON.stringify(jsonOdg));

    },

    kreirajBodove: function(spirala, index, fnCallback) {
      console.log("I  ova");
      if (spirala == null || index == null) {
        fnCallback(-1, "Neispravni parametri");
      }
      var jsonOdg = {
        spirala,
        index
      };
      var ajax = new XMLHttpRequest();
      ajax.onreadystatechange = function() {
        if (ajax.readyState == 4 && ajax.status == 200)
          document.getElementById("kontenjer").innerHTML = ajax.responseText;
        fnCallback(null, ajax.responseText);
        if (ajax.readyState == 4){
          document.getElementById("kontenjer").innerHTML = "Greska: nepoznat URL";
        fnCallback(ajax.status, ajax.responseText);
      }
console.log("provjera");
      }
      ajax.open("POST", "bodovi", true);
      ajax.setRequestHeader("Content-Type", "application/json");
      ajax.send(JSON.stringify(jsonOdg));
    }
  }
}());
