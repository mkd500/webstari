function otvoriFormuZaNastavnika() {
  document.getElementById("registracijaStudenta").style.display="none";
  document.getElementById("registracijaNastavnika").style.display="block";
  console.log("pozvana");
}

function otvoriFormuZaStudenta() {
  document.getElementById("registracijaNastavnika").style.display="none";
  document.getElementById("registracijaStudenta").style.display="block";
  console.log("pozvana");
}
