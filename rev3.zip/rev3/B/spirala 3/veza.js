var Veza=(function(){
  return{
    validirajFakultetskiVeza:function(div,divIspisa,input){
      if(!Validacija.validirajFakultetski(input)){
         poruke.dodajPoruku(0);
         poruke.postaviIdDiva(divIspisa);
         poruke.ispisiGreske();
       }
       else{
      poruke.ocistiGresku(0);
      poruke.postaviIdDiva(divIspisa);
      poruke.ispisiGreske();
      }
    },

    validirajIndexVeza:function(div,divIspisa,input){
      if(!Validacija.validirajIndex(input)){
         poruke.dodajPoruku(1);
         poruke.postaviIdDiva(divIspisa);
         poruke.ispisiGreske();
       }
       else{
         poruke.ocistiGresku(1);
         poruke.postaviIdDiva(divIspisa);
         poruke.ispisiGreske();
       }
     },

     validirajGrupuVeza:function(div,divIspisa,input){
       if(!Validacija.validirajGrupu(input)){
          poruke.dodajPoruku(2);
          poruke.postaviIdDiva(divIspisa);
          poruke.ispisiGreske();
        }
        else{
          poruke.ocistiGresku(2);
          poruke.postaviIdDiva(divIspisa);
          poruke.ispisiGreske();
        }
      },

      validirajAkGodVeza:function(div,divIspisa,input){
        if(!Validacija.validirajAkGod(input)){
           poruke.dodajPoruku(3);
           poruke.postaviIdDiva(divIspisa);
           poruke.ispisiGreske();
         }
         else{
           poruke.ocistiGresku(3);
           poruke.postaviIdDiva(divIspisa);
           poruke.ispisiGreske();
         }
       },

       validirajPasswordVeza:function(div,divIspisa,input){
         if(!Validacija.validirajPassword(input)){
            poruke.dodajPoruku(4);
            poruke.postaviIdDiva(divIspisa);
            poruke.ispisiGreske();
          }
          else{
            poruke.ocistiGresku(4);
            poruke.postaviIdDiva(divIspisa);
            poruke.ispisiGreske();
          }
        },

        validirajPotvrduVeza:function(div,divIspisa,input){
          if(!Validacija.validirajPotvrdu(document.getElementById("psw"),input)){
             poruke.dodajPoruku(5);
             poruke.postaviIdDiva(divIspisa);
             poruke.ispisiGreske();
           }
           else{
             poruke.ocistiGresku(5);
             poruke.postaviIdDiva(divIspisa);
             poruke.ispisiGreske();
           }
         },

         validirajBitbucketURLVeza:function(div,divIspisa,input){
           if(!Validacija.validirajBitbucketURL(input)){
              poruke.dodajPoruku(6);
              poruke.postaviIdDiva(divIspisa);
              poruke.ispisiGreske();
            }
            else{
              poruke.ocistiGresku(6);
              poruke.postaviIdDiva(divIspisa);
              poruke.ispisiGreske();
            }
          },

          validirajBitbucketSSHVeza:function(div,divIspisa,input){
            if(!Validacija.validirajBitbucketSSH(input)){
               poruke.dodajPoruku(7);
               poruke.postaviIdDiva(divIspisa);
               poruke.ispisiGreske();
             }
             else{
               poruke.ocistiGresku(7);
               poruke.postaviIdDiva(divIspisa);
               poruke.ispisiGreske();
             }
           },

           validirajNazivRepozitorijaVeza:function(regex,div,divIspisa,input){
            if(regex==null) regex=/^wtProjekat1(\d{4})$/;
             if(!Validacija.validirajNazivRepozitorija(regex,input)){
                poruke.dodajPoruku(8);
                poruke.postaviIdDiva(divIspisa);
                poruke.ispisiGreske();
              }
              else{
                poruke.ocistiGresku(8);
                poruke.postaviIdDiva(divIspisa);
                poruke.ispisiGreske();
              }
            },

            validirajImeiPrezimeVeza:function(div,divIspisa,input){
              if(!Validacija.validirajImeiPrezime(input)){
                 poruke.dodajPoruku(9);
                 poruke.postaviIdDiva(divIspisa);
                 poruke.ispisiGreske();
               }
               else{
                 poruke.ocistiGresku(9);
                 poruke.postaviIdDiva(divIspisa);
                 poruke.ispisiGreske();
               }
             }


}
}());
