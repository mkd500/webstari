function openLogin() {
  var ajax = new XMLHttpRequest();
  ajax.onreadystatechange = function(){
    if (ajax.readyState == 4 && ajax.status == 200)
       document.getElementById("kontenjer").innerHTML = ajax.responseText;
    if (ajax.readyState == 4 && ajax.status == 404)
       document.getElementById("kontenjer").innerHTML = "Greska: nepoznat URL";
  }
  ajax.open("GET", "http://localhost:3000/login.html", true);
  ajax.send();
}

function openStatistika() {
  var ajax = new XMLHttpRequest();
  ajax.onreadystatechange = function(){
    if (ajax.readyState == 4 && ajax.status == 200)
       document.getElementById("kontenjer").innerHTML = ajax.responseText;
    if (ajax.readyState == 4 && ajax.status == 404)
      document.getElementById("kontenjer").innerHTML = "Greska: nepoznat URL";
  }
  ajax.open("GET", "http://localhost:3000/statistika.html", true);
  ajax.send();
}

function openUnoskomentara() {
  var ajax = new XMLHttpRequest();
  ajax.onreadystatechange = function() {// Anonimna funkcija
  	if (ajax.readyState == 4 && ajax.status == 200)
  		document.getElementById("kontenjer").innerHTML = ajax.responseText;
  	if (ajax.readyState == 4 && ajax.status == 404)
  		document.getElementById("kontenjer").innerHTML = "Greska: nepoznat URL";
  }
  ajax.open("GET", "http://localhost:3000/unoskomentara.html", true);
  ajax.send();
}
function openUnosspiska() {
  var ajax = new XMLHttpRequest();
  ajax.onreadystatechange = function() {// Anonimna funkcija
  	if (ajax.readyState == 4 && ajax.status == 200)
  		document.getElementById("kontenjer").innerHTML = ajax.responseText;
  	if (ajax.readyState == 4 && ajax.status == 404)
  		document.getElementById("kontenjer").innerHTML = "Greska: nepoznat URL";
  }
  ajax.open("GET", "http://localhost:3000/unosspiska.html", true);
  ajax.send();
}

function openNastavnik() {
  var ajax = new XMLHttpRequest();
  ajax.onreadystatechange = function() {// Anonimna funkcija
  	if (ajax.readyState == 4 && ajax.status == 200)
  		document.getElementById("kontenjer").innerHTML = ajax.responseText;
  	if (ajax.readyState == 4 && ajax.status == 404)
  		document.getElementById("kontenjer").innerHTML = "Greska: nepoznat URL";
  }
  ajax.open("GET", "http://localhost:3000/nastavnik.html", true);
  ajax.send();
}
