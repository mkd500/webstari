var zamjena=(function(div,smijer) {
  if(smijer==="up"){
    var trenutni=div.parentNode.parentNode;
    var iznad=div.parentNode.parentNode.previousElementSibling;
    if(iznad!=null)
    iznad.parentNode.insertBefore(trenutni,iznad);
  }
  else{
    var trenutni=div.parentNode.parentNode;
    var ispod=div.parentNode.parentNode.nextElementSibling;
    if(ispod!=null)
    ispod.parentNode.insertBefore(ispod,trenutni);
  }
})
