var Validacija=(function(){
  var maxGrupa=7;
  var trenutniSemestar=0;//0 za zimski, 1 za ljetni semestar
  return{
  validirajFakultetski:function(fakultetski_mail){
    if(!fakultetski_mail)
      return true;
    var dijelovi=fakultetski_mail.split("@");
    if(dijelovi.length!=2 || dijelovi[1]!="etf.unsa.ba"){
        console.log("pogresan mail");
      return false;}
    return true;
  },

  validirajIndex:function(index){
    if(!index) return true;
    var regex = /^1(\d{4})$/;
    if (regex.test(index)) {
      return true;
  }
  else {
    console.log("pogresan index");
      return false;
  }
  },
  validirajGrupu:function(br_grupe){
    if(!br_grupe) return true;
    var br_grupe_vrijednost=br_grupe;
    if(br_grupe<1 || br_grupe>maxGrupa) {
      console.log("pogresna grupa");
        return false;
    }
  else {
      return true;
  }
  },

  validirajAkGod:function(godina){
    if(!godina) return true;
    var dijelovi=godina.split("/");
    if(trenutniSemestar==0){
      if(parseInt(dijelovi[0])!=parseInt(new Date().getFullYear()) || parseInt(dijelovi[1])!=parseInt(new Date().getFullYear())+1)
        {
          console.log("pogresna akademska godina");
          return false;
        }
      else return true;
    }

    if(trenutniSemestar==1){
      if(parseInt(dijelovi[0])!=parseInt(new Date().getFullYear())-1 || parseInt(dijelovi[1])!=parseInt(new Date().getFullYear()))
        {
          console.log("pogresna akademska godina");
          return false;
        }
      else return true;
    }
  },


  /*  var godina_vrijednost=godina;
    var regex = /^20(\d\d)\/20(\d\d)$/g;
    var result=regex.exec(godina)
    if (parseInt(result[1])+1!=parseInt(result[2])){
       return false;
       console.log("pogresan index");}
      return true;
    }*/

    validirajPassword:function(password){
      if(!password) return true;
      var regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{7,20}$/;
      if (regex.test(password)) {
        return true;
    }
    else {
      console.log("pogresan password");
        return false;
    }
    },

    validirajPotvrdu:function(password,potvrda){
      psw=password.value;
      if(!potvrda) return true;
      if(potvrda!=psw)
      {
        console.log("Password nije potvrdjen");
          return false;
      }
        return true;
    },

    validirajBitbucketURL:function(BBUrl){
      if(!BBUrl) return true;
      var regex =/^https:\/\/[a-zA-Z0-9]+([._]?[a-zA-Z0-9]+)*\@bitbucket.org\/[a-zA-Z0-9]+([._]?[a-zA-Z0-9]+)*\/[a-zA-Z0-9]+([._]?[a-zA-Z0-9]+)*\.git$/;
      if (regex.test(BBUrl)) {
        return true;
      }
      else {
        console.log("pogresan Bitbucket URL");
          return false;
      }
    },

    validirajBitbucketSSH:function(BBSsh){
      if(!BBSsh) return true;
      var regex =/^git@bitbucket.org\/[a-zA-Z0-9]+([._]?[a-zA-Z0-9]+){2,15}\/[a-zA-Z0-9]+([._]?[a-zA-Z0-9]+){2,15}\.git$/;
      if (regex.test(BBSsh)) {
        return true;
      }
      else {
        console.log("pogresan Bitbucket SSH");
          return false;
      }
    },

    validirajNazivRepozitorija:function(regex_rep, repozitorij){
        if(!repozitorij) return true;
        var regex_=regex_rep;
        //if(!regex_rep) regex=/^wtProjekat1(\d{4})/;
        //if(!Boolean(regex_rep)) regex=/^wtProjekat1(\d{4})/;
        if (regex_.test(repozitorij)) {
          return true;
        }
        else {
          console.log("pogresan naziv repozitorija");
            return false;
          }
        },

      validirajImeiPrezime:function(ime_i_prezime){
        if(!ime_i_prezime) return true;
        var regex =/^([A-ZŠĐČĆŽ][a-zšđčćž]{2,11}[-' ]*){1,}$/;
        if (regex.test(ime_i_prezime)) {
          return true;
        }
        else {
          console.log("pogresno ime i prezime");
            return false;
        }

      },

      postaviMaxGrupa:function(max_grupa){
        if(!ime_i_prezime) return true;
        maxGrupa=max_grupa;
        console.log("max grupa");
      },

      postaviTrenSemestar:function(tren_semestar){
        if(!tren_semestar) return true;
        if(tren_semestar.toLowerCase()==ljetni){
          trenutniSemestar==1;
          return true;}
          else if (tren_semestar.toLowerCase()==zimski) {
            trenutniSemestar==0;
            return true;
          }
          else return false;
      }


  }
}());
