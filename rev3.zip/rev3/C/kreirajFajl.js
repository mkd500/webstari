var kreirajFajl = (function(){
	return {
		kreirajKomentar: function(spirala, index, sadrzaj, fnCallback) {
			var ajax = XMLHttpRequest();
			ajax.onreadystatechange = function() {
				if(ajax.readyState === 4) {
					if(ajax.status === 200) {
						error = null; 
						data = ajax.responseText;
					}
					else if(index.length < 1 || spirala.length < 1 || sadrzaj.length < 0) {
						error = -1;
						data = "Neispravni parametri";
					}
					else {
						error = ajax.status;
						data = ajax.responseText;
					}
				}
				fnCallback(error, data);
			}
			ajax.open("POST", "http://localhost:3000/komentar", true);
			ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send(JSON.stringify({spirala:spirala, index:index, sadrzaj:sadrzaj}));
		},
		kreirajListu: function(godina, nizRepozitorija, fnCallback) {
			var ajax = XMLHttpRequest();
			ajax.onreadystatechange = function() {
				if(ajax.readyState === 4) {
					if(ajax.status === 200) {
						error = null; 
						data = ajax.responseText;
					}
					else if(godina.length < 1 || nizRepozitorija.length < 1) {
						error = -1;
						data = "Neispravni parametri";
					}
					else {
						error = ajax.status;
						data = ajax.responseText;
					}
				}
				fnCallback(error, data);
			}
			ajax.open("POST", "http://localhost:3000/lista", true);
			ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send(JSON.stringify({godina:godina, nizRepozitorija:nizRepozitorija}));
		},
		kreirajIzvjestaj: function(spirala, index, fnCallback) {
			var ajax = XMLHttpRequest();
			ajax.onreadystatechange = function() {
				if(ajax.readyState === 4) {
					if(ajax.status === 200) {
						error = null; 
						data = ajax.responseText;
					}
					else if(spirala.length < 1 || index.length < 1) {
						error = -1;
						data = "Neispravni parametri";
					}
					else {
						error = ajax.status;
						data = ajax.responseText;
					}
				}
				fnCallback(error, data);
			}
			ajax.open("POST", "http://localhost:3000/izvjestaj", true);
			ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send(JSON.stringify({spirala:spirala, index:index}));
		},
		kreirajBodove: function(spirala, index, fnCallback) {
			var ajax = XMLHttpRequest();
			ajax.onreadystatechange = function() {
				if(ajax.readyState === 4) {
					if(ajax.status === 200) {
						error = null; 
						data = ajax.responseText;
					}
					else if(spirala.length < 1 || index.length < 1) {
						error = -1;
						data = "Neispravni parametri";
					}
					else {
						error = ajax.status;
						data = ajax.responseText;
					}
				}
				fnCallback(error, data);
			}
			ajax.open("POST", "http://localhost:3000/bodovi", true);
			ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send(JSON.stringify({spirala:spirala, index:index}));
		}
	}
})();