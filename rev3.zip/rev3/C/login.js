function klikStudent(forma_student, forma_nasatvnik) {
	document.getElementById('forma_student').style.display = "block";
	document.getElementById('forma_nastavnik').style.display = "none";
	for(var i=0; i<=9; i++)
		Poruke.ocistiGresku(i);
	var student_inputi = document.getElementById('forma_student').getElementsByTagName('input');
	for(var i = 0; i < student_inputi.length; i++) {
		if(student_inputi[i].value != "")
			validiraj(student_inputi[i]);
	}
}

function klikNastavnik(forma_student, forma_nastavnik) {
	document.getElementById('forma_student').style.display = "none";
    document.getElementById('forma_nastavnik').style.display = "block";
	for(var i=0; i<=9; i++)
		Poruke.ocistiGresku(i);
	var nastavnik_inputi = document.getElementById('forma_nastavnik').getElementsByTagName('input');
	for(var i = 0; i < nastavnik_inputi.length; i++) {
		if(nastavnik_inputi[i].value != "")
			validiraj(nastavnik_inputi[i]);
	}
}

function validiraj(ref) {
	if(ref.id == "studentime") {
		Poruke.postaviIdDiva("greska_student");
		if(Validacija.validirajImeiPrezime(ref.value)) 
			Poruke.ocistiGresku(9);
		else
			Poruke.dodajPoruku(9);
	}
	else if(ref.id == "studentindex") {
		Poruke.postaviIdDiva("greska_student");
		if(Validacija.validirajIndex(ref.value))
			Poruke.ocistiGresku(1);
		else
			Poruke.dodajPoruku(1);
	}
	else if(ref.id == "studentgrupa") {
		Poruke.postaviIdDiva("greska_student");
		if(Validacija.validirajGrupu(ref.value)) 
			Poruke.ocistiGresku(2);
		else
			Poruke.dodajPoruku(2);
	}
	else if(ref.id == "studentakgod") {
		Poruke.postaviIdDiva("greska_student");
		if(Validacija.validirajAkGod(ref.value))
			Poruke.ocistiGresku(3);
		else
			Poruke.dodajPoruku(3);
	}
	else if(ref.id == "studentpassword") {
		Poruke.postaviIdDiva("greska_student");
		if(Validacija.validirajPassword(ref.value))
			Poruke.ocistiGresku(4);
		else
			Poruke.dodajPoruku(4);
	}
	else if(ref.id == "studentpotvrda") {
		Poruke.postaviIdDiva("greska_student");
		if(Validacija.validirajPotvrdu(ref.value, document.getElementById("studentpassword").value))
			Poruke.ocistiGresku(5);
		else
			Poruke.dodajPoruku(5);
	}
	else if(ref.id == "studenturl") {
		Poruke.postaviIdDiva("greska_student");
		if(Validacija.validirajBitbucketURL(ref.value))
			Poruke.ocistiGresku(6);
		else 
			Poruke.dodajPoruku(6);
	}
	else if(ref.id == "studentssh") {
		Poruke.postaviIdDiva("greska_student");
		if(Validacija.validirajBitbucketSSH(ref.value)) 
			Poruke.ocistiGresku(7);
		else
			Poruke.dodajPoruku(7);
	}
	else if(ref.id == "studentrepozitorij") {
		Poruke.postaviIdDiva("greska_student");
		if(Validacija.validirajNazivRepozitorija(document.getElementById('nastavnikregex').value, ref.value))
			Poruke.ocistiGresku(8);
		else
			Poruke.dodajPoruku(8);
	}
	else if(ref.id == "nastavnikime") {
		Poruke.postaviIdDiva("greska_nastavnik");
		if(Validacija.validirajImeiPrezime(ref.value)) 
			Poruke.ocistiGresku(9);
		else
			Poruke.dodajPoruku(9);
	}
	else if(ref.id == "nastavnikusername") {
		//ne pise u zadatku sta raditi za username 
	}
	else if(ref.id == "nastavnikpassword") {
		Poruke.postaviIdDiva("greska_nastavnik");
		if(Validacija.validirajPassword(ref.value))
			Poruke.ocistiGresku(4);
		else
			Poruke.dodajPoruku(4);
	}
	else if(ref.id == "nastavnikpotvrda") {
		Poruke.postaviIdDiva("greska_nastavnik");
		if(Validacija.validirajPotvrdu(ref.value, document.getElementById("nastavnikpassword").value))
			Poruke.ocistiGresku(5);
		else
			Poruke.dodajPoruku(5);
	}
	else if(ref.id == "nastavnikemail") {
		Poruke.postaviIdDiva("greska_nastavnik");
		if(Validacija.validirajFakultetski(ref.value))
			Poruke.ocistiGresku(0);
		else
			Poruke.dodajPoruku(0);
	}
	else if(ref.id == "nastavnikmaxgrupa") {
		if(ref.value > 1)
			Validacija.postaviMaxGrupa(ref.value);
	}
	else if(ref.id == "nastavnikakgod") {
		Poruke.postaviIdDiva("greska_nastavnik");
		if(Validacija.validirajAkGod(ref.value))
			Poruke.ocistiGresku(3);
		else
			Poruke.dodajPoruku(3);
	}
	else if(ref.id == "nastavniksemestar") {
		if(ref.value == 0 || ref.value == 1)
			Validacija.postaviTrenSemestar(ref.value);
	}
	
	Poruke.ispisiGreske();
}