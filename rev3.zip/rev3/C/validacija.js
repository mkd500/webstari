var Validacija = (function(){
	var maxGrupa = 7;
	var trenutniSemestar = 0; //0-zimski 1-ljetni

	var validirajFakultetski = function(str){
		var regex = /^\w{4,11}@etf\.unsa\.ba\s*$/;
		return regex.test(str);
	}

	var validirajIndex = function(ind) {
		var regex = /^1\d{4}$/;
		return regex.test(ind.toString());
	}

	var validirajGrupu = function(gr) {
		if(!isNaN(gr))
			return gr>=1 && gr<=maxGrupa;
	}

	var validirajAkGod = function(str) {
		var regex = /^20\d\d\/20\d\d$/;
		if(regex.test(str))
		{
			var br1 = str.substr(2,4);
			var br2 = str.substr(7,9);
			if( parseInt(br1) + 1 == parseInt(br2)) {
				if((trenutniSemestar==0 && str.substr(0,4) == (new Date()).getFullYear().toString()) 
					|| (trenutniSemestar==1 && str.substr(5,9) == (new Date()).getFullYear().toString()))
					return true;
			}
		}
		return false;
	}

	var validirajPassword = function(str) {
		var regex1 = /^.*[a-z].*$/;
		var regex2 = /^.*[A-Z].*$/;
		var regex3 = /^.*\d.*$/;
		var regex4 = /^.{7,20}$/;
		if(regex1.test(str))
			if(regex2.test(str))
				if(regex3.test(str))
					if(regex4.test(str))
						return true;
		return false;
	}

	var validirajPotvrdu = function(str1, str2) {
		if(validirajPassword(str1) && validirajPassword(str2))
			return str1===str2;
		return false;
	}

	var validirajBitbucketURL = function(url) {
		var regex = /^https:\/\/[A-Za-z0-9čČćĆđĐšŠžŽ\_\-]{1,255}@bitbucket.org\/[A-Za-z0-9\_\-]{1,255}\/[^.][\w|čČćĆšŠđĐžŽ]{0,244}\.git$/;
		return regex.test(url);
	}

	var validirajBitbucketSSH = function(url) {
		var regex = /^git@bitbucket.org:[A-Za-z0-9čČćĆđĐšŠžŽ\_\-]{1,255}\/[^.][\w|čČćĆšŠđĐžŽ]{0,244}.git$/;
		return regex.test(url);
	}

	var validirajNazivRepozitorija = function(regex, str) {
		var regex_rezervni = /^wt[pP]rojekat1\d{4}$/;
		if(regex != null)
			return regex.test(str);
		return regex_rezervni.test(str);
	}

	var validirajImeiPrezime = function(str) {
		var regex = /^[A-Z][A-Za-zčČĆćŠšĐđŽž\-\']{2,11}( [A-Z][A-Za-zčČĆćŠšĐđŽž\'\-]{2,11})?$/;
		return regex.test(str);
	}

	var postaviMaxGrupa = function(x) {
		maxGrupa = x;
	}

	var postaviTrenSemestar = function(x) {
		trenutniSemestar = x;
	}

	return {
		validirajFakultetski: validirajFakultetski,
		validirajIndex: validirajIndex,
		validirajGrupu: validirajGrupu,
		validirajAkGod: validirajAkGod,
		validirajPassword: validirajPassword,
		validirajPotvrdu: validirajPotvrdu,
		validirajBitbucketURL: validirajBitbucketURL,
		validirajBitbucketSSH: validirajBitbucketSSH,
		validirajNazivRepozitorija: validirajNazivRepozitorija,
		validirajImeiPrezime: validirajImeiPrezime,
		postaviMaxGrupa: postaviMaxGrupa,
		postaviTrenSemestar: postaviTrenSemestar
	}
}());