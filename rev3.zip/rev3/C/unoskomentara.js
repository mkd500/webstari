function funkcija() {
	var niz = document.getElementsByClassName('up');
	for(let i=0; i<niz.length; i++) {
			niz[i].addEventListener("click", function pomjeriGore() {
		var red = this.parentNode.parentNode,
			prijasnji = red.previousElementSibling,
			tabela = red.parentNode;
			if(red.rowIndex != 0)
				tabela.insertBefore(red, prijasnji);
	}, false);
	}

	var niz2 = document.getElementsByClassName('down');
	for(let i=0; i<niz2.length; i++) {
		niz2[i].addEventListener("click", function pomjeriDole() {
			var red = this.parentNode.parentNode;
			var tabela = red.parentNode;
			if(red.rowIndex != niz2.length - 1) {
				var sljedeci = red.nextElementSibling;
				tabela.insertBefore(sljedeci, red);
			}
		}, false);
	}
}