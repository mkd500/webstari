var Poruke = (function(){
	var idDivaPoruke;
	var mogucePoruke = ["E-mail koji ste napisali nije validan fakultetski e-mail<br>",
						"Indeks kojeg ste napisali nije validan<br>",
						"Nastavna grupa koju ste napisali nije validna<br>",
						"Akademska godina koju ste napisali nije validna<br>",
						"Password koji ste napisali nije validan<br>",
						"Potvrda passworda koju ste napisali nije jednaka passwordu<br>",
						"Bitbucket URL koji ste napisali nije validan<br>",
						"Bitbucket SSH koji ste napisali nije validan<br>",
						"Naziv repozitorija koji ste napisali nije validan<br>",
						"Ime i prezime koje ste napisali nije validno<br>"];
	var porukeZaIspis = [];

	var ispisiGreske = function() {
		document.getElementById(idDivaPoruke).innerHTML = "";
		for(var i = 0; i < porukeZaIspis.length; i++)
			document.getElementById(idDivaPoruke).innerHTML += porukeZaIspis[i];
	}

	var postaviIdDiva = function(id) {
		idDivaPoruke = id;
	}

	var dodajPoruku = function(indeks) {
		if(indeks >= 0 && indeks < mogucePoruke.length)
			if(!porukeZaIspis.includes(mogucePoruke[indeks]))
				porukeZaIspis.push(mogucePoruke[indeks]);
	}

	var ocistiGresku = function(indeks) {
		if(indeks >= 0 && indeks < mogucePoruke.length)
			if(porukeZaIspis.includes(mogucePoruke[indeks]))
				porukeZaIspis.splice(porukeZaIspis.indexOf(mogucePoruke[indeks]),1);
	}

	return {
		ispisiGreske: ispisiGreske,
		postaviIdDiva: postaviIdDiva,
		dodajPoruku: dodajPoruku,
		ocistiGresku: ocistiGresku
	}
}());