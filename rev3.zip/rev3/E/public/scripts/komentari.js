const commentReplacement = () => {
	Array.prototype.forEach.call(
		document.getElementsByClassName('move-up'),
		element => {
			element.onclick = function() {
				var row = this.parentNode.parentNode;
				sibling = row.previousElementSibling;
				if (sibling.id == 'headline') return;

				parent = row.parentNode;
				parent.insertBefore(row, sibling);
			};
		}
	);

	Array.prototype.forEach.call(
		document.getElementsByClassName('move-down'),
		element => {
			element.onclick = function() {
				var row = this.parentNode.parentNode;
				sibling = row.nextElementSibling;
				if (!sibling) return;

				parent = row.parentNode;
				parent.insertBefore(sibling, row);
			};
		}
	);
};

const log = () => {
	let index = document.getElementById('komentari-index').value;
	let spirala = document.getElementById('komentari-spirala').value;
	let tabela = document.getElementById('komentari-tabela');

	let sadrzajkomentar = [];

	for (let i = 1; i < 6; i++) {
		let sifra_studenta = tabela.rows
			.item(i)
			.cells.item(0)
			.innerHTML.trim();

		let tekst = tabela.rows.item(i).getElementsByClassName('table-text')[0]
			.value;

		sadrzajkomentar.push({
			sifra_studenta,
			tekst,
			ocjena: i
		});
	}

	const fnCallback = (error, data) => {
		console.log(error);
		console.log(data);
	};

	KreirajFajl.kreirajKomentar(
		spirala,
		index,
		JSON.stringify(sadrzajkomentar),
		fnCallback
	);
};
