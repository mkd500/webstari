var KreirajFajl = (function() {
	const validirajSadrzajJSON = sadrzaj => {
		let object = JSON.parse(sadrzaj);
		return (
			object.length != 0 &&
			object[0].sifra_studenta &&
			object[0].tekst &&
			object[0].ocjena
		);
	};

	return {
		kreirajKomentar: (spirala, index, sadrzaj, fnCallback) => {
			if (spirala && index && validirajSadrzajJSON(sadrzaj)) {
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						fnCallback(null, xhttp.responseText);
					} else if (this.readyState == 4) {
						fnCallback(xhttp.status, xhttp.responseText);
					}
				};

				let body = JSON.stringify({
					spirala,
					index,
					sadrzaj
				});

				xhttp.open('POST', 'http://localhost:3000/komentar', true);
				xhttp.setRequestHeader('Content-Type', 'application/json');
				xhttp.send(body);
			} else {
				fnCallback(-1, 'Neispravni parametri');
			}
		},
		kreirajListu: (godina, nizRepozitorija, fnCallback) => {
			if (godina && nizRepozitorija.length !== 0) {
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						fnCallback(null, xhttp.responseText);
					} else if (this.readyState == 4) {
						fnCallback(xhttp.status, xhttp.responseText);
					}
				};

				let body = JSON.stringify({
					godina,
					nizRepozitorija
				});

				xhttp.open('POST', 'http://localhost:3000/lista', true);
				xhttp.setRequestHeader('Content-Type', 'application/json');
				xhttp.send(body);
			} else {
				fnCallback(-1, 'Neispravni parametri');
			}
		},
		kreirajIzvjestaj: function(spirala, index, fnCallback) {
			if (spirala && index) {
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						fnCallback(null, xhttp.responseText);
					} else if (this.readyState == 4) {
						fnCallback(xhttp.status, xhttp.responseText);
					}
				};

				let body = JSON.stringify({
					spirala,
					index
				});

				xhttp.open('POST', 'http://localhost:3000/izvjestaj', true);
				xhttp.setRequestHeader('Content-Type', 'application/json');
				xhttp.send(body);
			} else {
				fnCallback(-1, 'Neispravni parametri');
			}
		},
		kreirajBodove: (spirala, index, fnCallback) => {
			if (spirala && index) {
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						fnCallback(null, xhttp.responseText);
					} else if (this.readyState == 4) {
						fnCallback(xhttp.status, xhttp.responseText);
					}
				};

				let body = JSON.stringify({
					spirala,
					index
				});

				xhttp.open('POST', 'http://localhost:3000/bodovi', true);
				xhttp.setRequestHeader('Content-Type', 'application/json');
				xhttp.send(body);
			} else {
				fnCallback(-1, 'Neispravni parametri');
			}
		}
	};
})();
