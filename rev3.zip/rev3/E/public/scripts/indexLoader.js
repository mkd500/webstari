const get = (path, fnCallback) => {
	let xhttp = new XMLHttpRequest();
	xhttp.open('GET', path, true);
	xhttp.onreadystatechange = () => {
		if (xhttp.readyState == 4 && xhttp.status == '200') {
			fnCallback(xhttp.responseText);
		}
	};
	xhttp.send(null);
};

const unosSpiskaAPI = () => {
	var fnCallback = ret => {
		if (ret) {
			document.getElementById('index-error').innerHTML = ret;
		} else {
			document.getElementById('index-error').innerHTML = 'Uspjesno sacuvano.';
			document.getElementById('unos-spirala').value = '';
			document.getElementById('unos-spisak').value = '';
		}
	};
	let object = {
		spisak: document.getElementById('unos-spisak').value.trim(),
		spirala: document.getElementById('unos-spirala').value
	};

	let xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = () => {
		if (xhttp.readyState == 4 && xhttp.status == '200') {
			fnCallback(undefined);
		} else if (xhttp.readyState == 4) {
			fnCallback(xhttp.responseText);
		}
	};
	xhttp.open('POST', '/unesi_indexe', true);
	xhttp.setRequestHeader('Content-Type', 'application/json');
	xhttp.send(JSON.stringify(object));
};

const insertView = ime => {
	get('/views/' + ime + '.html', response => {
		document.getElementById('container').innerHTML = response;
		switch (ime) {
			case 'komentari':
				commentReplacement();
				break;
			case 'login':
				loginValidation();
				break;
			default:
		}
	});
};

const bitbucketPoziv = () => {
	let key = document.getElementById('bb-key').value;
	let secret = document.getElementById('bb-secret').value;
	let repozitorij = document.getElementById('bb-repozitorij').value;
	let branch = document.getElementById('bb-branch').value;
	let godina = document.getElementById('bb-godina').value;

	const innerinnerfnCallback = (error, data) => {
		document.getElementById('bb-error').innerHTML = data;
	};

	const innerfnCallback = (error, data) => {
		if (error) {
			document.getElementById('bb-error').innerHTML = data;
		} else {
			KreirajFajl.kreirajListu(godina, data, innerinnerfnCallback);
		}
	};

	const fnCallback = (error, data) => {
		if (error) {
			document.getElementById('bb-error').innerHTML = data;
		} else {
			BitbucketApi.dohvatiRepozitorije(
				data,
				godina,
				repozitorij,
				branch,
				innerfnCallback
			);
		}
	};

	BitbucketApi.dohvatiAccessToken(key, secret, fnCallback);
};

insertView('login');
