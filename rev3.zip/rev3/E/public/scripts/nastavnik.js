var generisiIzvjestaj = () => {
	let index = document.getElementById('nastavnik-index').value;
	let spirala = document.getElementById('nastavnik-spirala').value;

	const fnCallback = (status, text) => {
		if (status) {
			document.getElementById('nastavnik-error').innerHTML = text;
		} else {
			document.getElementById('nastavnik-error').innerHTML =
				'Uspjesno kreiran izvjestaj';
		}
	};

	KreirajFajl.kreirajIzvjestaj(spirala, index, fnCallback);
};

var generisiBodove = function() {
	let index = document.getElementById('nastavnik-index').value;
	let spirala = document.getElementById('nastavnik-spirala').value;

	console.log(index + ' ' + spirala);

	const fnCallback = (status, text) => {
		if (status) {
			document.getElementById('nastavnik-error').innerHTML = text;
		} else {
			document.getElementById('nastavnik-error').innerHTML = JSON.parse(
				text
			).poruka;
		}
	};

	KreirajFajl.kreirajBodove(spirala, index, fnCallback);
};
