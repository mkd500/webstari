var validacija = (function() {
	var maxGrupa = 7;
	var trenutniSemestar = 0; //0 za zimski, 1 za ljetni semestar

	return {
		validirajFakultetski: function(email) {
			var regex = /\w@etf\.unsa\.ba$/;
			return email.match(regex);
		},
		validirajIndex: function(index) {
			var regex = /^1\d\d\d\d$/;
			return index.match(regex);
		},
		validirajGrupu: function(grupa) {
			return grupa >= 1 && grupa <= maxGrupa;
		},
		validirajAkGod: function(akGod) {
			var regex = /^20\d\d\/20\d\d$/;
			var godina1 = parseInt(akGod.substring(0, 4));
			var godina2 = parseInt(akGod.substring(5, 9));
			var trenutnaGodina = new Date().getFullYear();

			if (!akGod.match(regex) || godina2 - godina1 !== 1) return false;

			return trenutniSemestar == 0
				? godina1 == trenutnaGodina
				: godina2 == trenutnaGodina;
		},
		validirajPassword: function(password) {
			if (password.length < 7 || password.length > 20) return false;

			var regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/;
			return password.match(regex);
		},
		validirajPotvrdu: function(password1, password2) {
			var regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/;
			return (
				password1.match(regex) &&
				password2.match(regex) &&
				password1 === password2
			);
		},
		validirajBitbucketURL: function(url) {
			var regex = /^https:\/\/\w+@bitbucket\.org\/\w+\/\w+\.git$/;
			return url.match(regex);
		},
		validirajBitbucketSSH: function(ssh) {
			var regex = /^git@bitbucket\.org:\w+\/\w+\.git$/;
			return ssh.match(regex);
		},
		validirajNazivRepozitorija: function(regex, naziv) {
			if (regex) {
				return naziv.match(regex);
			} else {
				var inner_regex_uppercase = /^wtProjekat1\d\d\d\d$/;
				var inner_regex_lowercase = /^wtprojekat1\d\d\d\d$/;
				return (
					naziv.match(inner_regex_lowercase) ||
					naziv.match(inner_regex_uppercase)
				);
			}
		},
		validirajImeiPrezime: function(naziv) {
			var regex = /^([A-ZŠĐŽČĆ]([a-zšđžčć]{2,12})[ '-]*)+$/;
			return naziv.match(regex);
		},
		//setteri koji su zahtijevani
		postaviMaxGrupa: function(novaMaxGrupa) {
			maxGrupa = novaMaxGrupa;
		},
		postaviTrenSemestar: function(noviSemestar) {
			trenutniSemestar = noviSemestar;
		}
	};
})();
