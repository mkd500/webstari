var Poruke = (function() {
	var idDivaPoruka;
	var mogucePoruke = [
		'Neispravan email',
		'Neispravan broj indeksa',
		'Neispravna grupa',
		'Neispravna akademska godina',
		'Neispravan format passworda',
		'Passwordi se ne podudaraju',
		'Neispravan Bitbucket URL',
		'Neispravan Bitbucket SSH',
		'Neispravan naziv repozitorija',
		'Neispravno ime i prezime'
	];
	var porukeZaIspis = [];

	return {
		ispisiGreske: function() {
			document.getElementById(idDivaPoruka).innerHTML = porukeZaIspis;
		},
		postaviIdDiva: function(id) {
			idDivaPoruka = id;
		},
		dodajPoruku: function(brojPoruke) {
			if (
				!porukeZaIspis.find(
					poruka =>
						poruka == mogucePoruke[brojPoruke] && porukeZaIspis.length < 10
				)
			) {
				porukeZaIspis.push(mogucePoruke[brojPoruke]);
			}
		},
		ocistiPoruku: function(indexPoruke) {
			let porukaZaIzbaciti = mogucePoruke[indexPoruke];
			let index = porukeZaIspis.indexOf(porukaZaIzbaciti);

			console.log(porukaZaIzbaciti, index);
			if (index != -1) porukeZaIspis.splice(index, 1);
		},
		ocistiSvePoruke: function() {
			porukeZaIspis = [];
		}
	};
})();
