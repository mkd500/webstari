var BitbucketApi = (function() {
	return {
		dohvatiAccessToken: (key, secret, fnCallback) => {
			let xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = () => {
				if (xhttp.readyState == 4 && xhttp.status == 200) {
					fnCallback(null, JSON.parse(xhttp.responseText).access_token);
				} else if (xhttp.readyState == 4) {
					fnCallback(-1, 'Key ili secret nisu ispravno proslijedjeni!');
				}
			};

			xhttp.open(
				'POST',
				'https://bitbucket.org/site/oauth2/access_token',
				true
			);
			xhttp.setRequestHeader(
				'Content-Type',
				'application/x-www-form-urlencoded'
			);
			xhttp.setRequestHeader(
				'Authorization',
				'Basic ' + btoa(key + ':' + secret)
			);
			xhttp.send('grant_type=' + encodeURIComponent('client_credentials'));
		},
		dohvatiRepozitorije: function(token, godina, naziv, branch, fnCallback) {
			let ispravniRepo = [];
			let repozitoriji = [];
			let visitCounter = 0;
			var finalCallback = function(error, data, index) {
				visitCounter++;
				if (!error && data) {
					ispravniRepo.push(repozitoriji[index].links.clone[1].href);
				}
				if (visitCounter == repozitoriji.length) {
					done();
				}
			};

			var done = function() {
				fnCallback(null, ispravniRepo);
			};

			let xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = () => {
				if (xhttp.readyState == 4 && xhttp.status == 200) {
					repozitoriji = JSON.parse(xhttp.responseText).values;
					repozitoriji = repozitoriji.filter(
						repo => repo.name.indexOf(naziv) != -1
					);
					repozitoriji = repozitoriji.filter(repo => {
						let year = new Date(repo.created_on).getFullYear();
						return year == godina || year == godina + 1;
					});

					repozitoriji.forEach(function(element, index) {
						BitbucketApi.dohvatiBranch(
							token,
							element.links.branches.href,
							branch,
							function(err, data) {
								finalCallback(err, data, index);
							}
						);
					});
				} else if (xhttp.readyState == 4) {
					fnCallback(xhttp.status, null);
				}
			};

			xhttp.open(
				'GET',
				'https://api.bitbucket.org/2.0/repositories?role=member&pagelen=150&name~' +
					naziv,
				true
			);
			xhttp.setRequestHeader('Authorization', 'Bearer ' + token);
			xhttp.send();
		},
		dohvatiBranch: function(token, url, naziv, fnCallback) {
			let xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = () => {
				if (xhttp.readyState == 4 && xhttp.status == 200) {
					let branchevi = JSON.parse(xhttp.responseText).values;
					let postoji =
						branchevi.findIndex(branch => branch.name == naziv) !== -1;
					fnCallback(null, postoji);
				} else if (xhttp.readyState == 4) {
					fnCallback(xhttp.status, null);
				}
			};

			xhttp.open('GET', url, true);
			xhttp.setRequestHeader('Authorization', 'Bearer ' + token);
			xhttp.send();
		}
	};
})();
