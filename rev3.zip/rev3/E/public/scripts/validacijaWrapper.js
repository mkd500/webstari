var password;

const loginValidation = () => {
	Poruke.postaviIdDiva('errors');

	document.getElementById('button-change-form').onclick = function() {
		var student = document.getElementById('register-student');
		var profesor = document.getElementById('register-profesor');

		if (student.style.display == 'none') {
			profesor.style.display = 'none';
			student.style.display = 'flex';
			this.innerHTML = 'Registruj profesora';
		} else {
			student.style.display = 'none';
			profesor.style.display = 'flex';
			this.innerHTML = 'Registruj studenta';
		}
		Poruke.ocistiSvePoruke();
		Poruke.ispisiGreske();
	};
};

function validirajFakultetski(value) {
	if (!validacija.validirajFakultetski(value)) {
		Poruke.dodajPoruku(0);

		Poruke.ispisiGreske();
	} else {
		Poruke.ocistiPoruku(0);
		Poruke.ispisiGreske();
	}
}

function validirajIndex(value) {
	if (!validacija.validirajIndex(value)) {
		Poruke.dodajPoruku(1);

		Poruke.ispisiGreske();
	} else {
		Poruke.ocistiPoruku(1);
		Poruke.ispisiGreske();
	}
}

function validirajGrupu(value) {
	if (!validacija.validirajGrupu(value)) {
		Poruke.dodajPoruku(2);

		Poruke.ispisiGreske();
	} else {
		Poruke.ocistiPoruku(2);
		Poruke.ispisiGreske();
	}
}

function validirajAkGod(value) {
	if (!validacija.validirajAkGod(value)) {
		Poruke.dodajPoruku(3);

		Poruke.ispisiGreske();
	} else {
		Poruke.ocistiPoruku(3);
		Poruke.ispisiGreske();
	}
}

function validirajPassword(value) {
	if (!validacija.validirajPassword(value)) {
		Poruke.dodajPoruku(4);

		Poruke.ispisiGreske();
	} else {
		password = value;

		Poruke.ocistiPoruku(4);
		Poruke.ispisiGreske();
	}
}

function validirajPotvrdu(value) {
	if (!validacija.validirajPotvrdu(value, password)) {
		Poruke.dodajPoruku(5);

		Poruke.ispisiGreske();
	} else {
		Poruke.ocistiPoruku(5);
		Poruke.ispisiGreske();
	}
}

function validirajBitbucketURL(value) {
	if (!validacija.validirajBitbucketURL(value)) {
		Poruke.dodajPoruku(6);

		Poruke.ispisiGreske();
	} else {
		Poruke.ocistiPoruku(6);
		Poruke.ispisiGreske();
	}
}

function validirajBitbucketSSH(value) {
	if (!validacija.validirajBitbucketSSH(value)) {
		Poruke.dodajPoruku(7);

		Poruke.ispisiGreske();
	} else {
		Poruke.ocistiPoruku(7);
		Poruke.ispisiGreske();
	}
}

function validirajNazivRepozitorija(value) {
	if (!validacija.validirajNazivRepozitorija(null, value)) {
		Poruke.dodajPoruku(8);

		Poruke.ispisiGreske();
	} else {
		Poruke.ocistiPoruku(8);
		Poruke.ispisiGreske();
	}
}

function validirajImeiPrezime(value) {
	if (!validacija.validirajImeiPrezime(value)) {
		Poruke.dodajPoruku(9);

		Poruke.ispisiGreske();
	} else {
		Poruke.ocistiPoruku(9);
		Poruke.ispisiGreske();
	}
}
