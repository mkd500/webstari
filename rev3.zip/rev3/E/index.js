const express = require('express');
const path = require('path');
const fs = require('fs');
const bodyParser = require('body-parser');

const app = express();

const regex = /^1\d\d\d\d$/;

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(__dirname));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => {
	res.sendFile(__dirname + '/index.html');
});

app.post('/unesi_indexe', (req, res) => {
	let object = req.body;

	try {
		let redovi = object.spisak.split('\n');
		for (let i = 0; i < redovi.length; i++) {
			redovi[i] = redovi[i].trim();
			let indeksi = redovi[i].split(',');
			if (indeksi.length != 6 || new Set(indeksi).size !== indeksi.length) {
				res.status(422).send('Greska sa podacima u redu ' + i);
				return;
			}
			for (let j = 0; j < indeksi.length; j++) {
				if (!indeksi[j].match(regex)) {
					res.status(422).send('Greska sa podacima u redu ' + i);
					return;
				}
			}
			redovi[i] = indeksi;
		}

		fs.writeFile(
			__dirname + '/spisakS' + object.spirala + '.json',
			JSON.stringify(redovi),
			err => {
				if (err) {
					res.status(500).send('Greska u pisanju podataka.');
				} else {
					res.status(200).send('Uspjesno spaseni podaci');
				}
			}
		);
	} catch (e) {
		res.status(422).send('Greska sa podacima.');
	}
});

app.post('/komentar', (req, res) => {
	try {
		let object = req.body;
		let json = JSON.stringify(object.sadrzaj);

		if (!validirajMarks(req.body)) {
			res.status(422).json({
				message: 'Podaci nisu u trazenom formatu!',
				data: null
			});
		} else {
			fs.writeFile(
				__dirname + '/markS' + object.spirala + object.index + '.json',
				json,
				err => {
					if (err) {
						res.status(500).json({
							message: 'Problem sa pisanjem podataka',
							data: null
						});
					} else {
						res.status(200).json({
							message: 'Uspjesno kreirana datoteka',
							data: object.sadrzaj
						});
					}
				}
			);
		}
	} catch (e) {
		res.status(422).json({
			message: 'Podaci nisu u trazenom formatu',
			data: null
		});
	}
});

app.post('/lista', (req, res) => {
	try {
		let object = req.body;

		if (!validirajSpisak(req.body)) {
			throw Error;
		} else {
			fs.writeFile(
				__dirname + '/spisak' + object.godina + '.txt',
				object.nizRepozitorija,
				err => {
					if (err) {
						res.status(500).json({
							message: 'Problem sa pisanjem podataka',
							data: null
						});
					} else {
						res.status(200).json({
							message: 'Lista uspjesno kreirana',
							data: object.nizRepozitorija.length
						});
					}
				}
			);
		}
	} catch (e) {
		res.status(422).json({
			message: 'Podaci nisu u trazenom formatu',
			data: null
		});
	}
});

app.post('/izvjestaj', (req, res) => {
	try {
		let object = req.body;
		if (!validirajIzvjestaj(object)) {
			throw Error;
		} else {
			fs.readFile(
				path.join(__dirname, '/spisakS' + object.spirala + '.json'),
				(err, dataJSON) => {
					try {
						if (err) throw err;

						let data = JSON.parse(dataJSON);
						for (let i = 0; i < data.length; i++) {
							let red = data[i];
							for (let j = 0; j < red.length; j++) {
								if (red[j] == object.index && j !== 0) {
									fs.readFile(
										path.join(
											__dirname,
											'/markS' + object.spirala + red[0] + '.json'
										),
										(innererr, innerdataJSON) => {
											if (innererr) throw innererr;

											let sadrzaj = JSON.parse(innerdataJSON);
											let sifra = slova[j - 1];
											let komentar = '';
											for (let k = 0; k < sadrzaj.length; k++) {
												if (sadrzaj[k].sifra_studenta == sifra)
													komentar = sadrzaj[k].tekst;
											}
											fs.appendFileSync(
												path.join(
													__dirname,
													'/izvjestajS' + object.spirala + object.index + '.txt'
												),
												'\n' + komentar + '\n' + '##########'
											);
										}
									);
								}
							}
						}
						res.download(
							__dirname +
								'/izvjestajS' +
								object.spirala +
								object.index +
								'.txt',
							err => {
								if (err) {
									var erroasdsar = err;
								}
							}
						);
					} catch (e) {
						res.status(422).json({
							message: 'Greska',
							data: null
						});
					}
				}
			);
		}
	} catch (e) {
		res.status(422).json({
			message: 'Greska',
			data: null
		});
	}
});

app.post('/bodovi', (req, res) => {
	let object = req.body;
	if (!validirajIzvjestaj(object)) {
		res.status(422).json({
			poruka: 'Podaci nisu u trazenom formatu!'
		});
	} else {
		let params = object;
		let brojOcjena = 0;
		let zbirOcjena = 0;
		let brojacUlazaka = 0;
		let brojacIzlazaka = 0;
		fs.readFile(
			path.join(__dirname, '/spisakS' + params.spirala + '.json'),
			(err, dataJSON) => {
				try {
					if (err) throw err;

					let data = JSON.parse(dataJSON);
					for (let i = 0; i < data.length; i++) {
						let red = data[i];
						for (let j = 0; j < red.length; j++) {
							if (red[j] == params.index && j !== 0) {
								brojacUlazaka++;
								fs.readFile(
									path.join(
										__dirname,
										'/markS' + params.spirala + red[0] + '.json'
									),
									(innererr, innerdataJSON) => {
										try {
											if (innererr) throw innererr;

											let sadrzaj = JSON.parse(innerdataJSON);
											let sifra = slova[j - 1];
											for (let k = 0; k < sadrzaj.length; k++) {
												if (sadrzaj[k].sifra_studenta == sifra) {
													zbirOcjena += parseInt(sadrzaj[k].ocjena);
													brojOcjena++;
												}
											}
											brojacIzlazaka++;
											if (brojacIzlazaka == brojacUlazaka) {
												res.status(200).json({
													poruka:
														'Student ' +
														params.index +
														' je ostvario u prosjeku ' +
														(Math.floor(zbirOcjena / brojOcjena) + 1) +
														' mjesto'
												});
											}
										} catch (e) {
											res.status(422).json({
												poruka: 'Greska'
											});
										}
									}
								);
							}
						}
					}
				} catch (e) {
					res.status(422).json({
						poruka: 'Greska'
					});
				}
			}
		);
	}
});

app.listen(3000);

const validirajMarks = object => {
	return object.spirala && object.index && object.sadrzaj.length !== 0;
};

const validirajSpisak = object => {
	return object.godina && object.nizRepozitorija.length !== 0;
};

const validirajIzvjestaj = object => {
	return object.spirala && object.index;
};

const slova = ['A', 'B', 'C', 'D', 'E'];
