const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');
const app = express();

app.use(express.static('html'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.post('/komentar', function(req, res){
  var podaci = req.body;
  if(podaci.spirala == null || podaci.spirala == "" || podaci.index == null || podaci.index == "" || podaci.sadrzaj == null)
    res.json({"message":"Podaci nisu u traženom formatu!", "data":"null"});
  else
    fs.appendFile('markS' + podaci.spirala + podaci.index + '.json', JSON.stringify(podaci), function(err){
      if(err)
        throw err;
      res.json({"message":"Uspješno kreirana datoteka!", "data":JSON.stringify(podaci)});
    });
});

app.post('/lista', function(req, res){
  var podaci = req.body;
  if(podaci.godina == null || podaci.godina == "" || podaci.nizRepozitorija == null)
    res.json({"message":"Podaci nisu u traženom formatu!", "data":"null"});
  else {
    fs.appendFile('spisak' + podaci.godina + '.txt', podaci, function(err){
      if(err)
        throw err;
      res.json({"message":"Uspješno kreirana datoteka!", "data":100});
    });
  }
});

app.post('/izvjestaj', function(req, res){
  var podaci = req.body;
  var asyncLoop = require('node-async-loop');
  var list, temp, nizIndeksa = [], nizPozicija = [];
  fs.readFile('spisakS' + podaci.spirala + '.json', function(err, data){
    if(err)
      throw err;
    list = data.toString('utf-8');
    obj = JSON.parse(list);

      for(var i = 0; i < obj.lista.length; i++){
        for(var j = 0; j < obj.lista[i].length; j++){
          if(obj.lista[i][j] == podaci.index){
            nizIndeksa.push(obj.lista[i][0]);
            nizPozicija.push(j-1);
          }
        }
      }

      var funkcija = function(){
        var z = 0, comment = "";
        asyncLoop(nizIndeksa, function(item, next){
          fs.readFile('markS' + podaci.spirala + item + '.json', function(err, data){
          if(err)
            throw err;
          temp = data.toString('utf-8');
          var obj2 = JSON.parse(temp);
          comment = comment + obj2.sadrzaj[nizPozicija[z]].tekst;
          comment = comment + "##########";
          z = z+1;
          if(z == nizPozicija.length)
            funkcija2(comment);
          });
          next();
        });
        var funkcija2 = function(comment){
          fs.appendFile('izvjestajS' + podaci.spirala + podaci.index + '.txt', comment, function(err){
            if(err)
              throw err;
          });
          res.download(__dirname + '/izvjestajS' + podaci.spirala + podaci.index + '.txt', 'izvjestajS' + podaci.spirala + podaci.index + '.txt');
        }
      }
      funkcija();
    });
});

app.post('/bodovi', function(req, res){
  var podaci = req.body;
  var asyncLoop = require('node-async-loop');
  var list, temp, nizIndeksa = [], nizPozicija = [];
  fs.readFile('spisakS' + podaci.spirala + '.json', function(err, data){
    if(err)
      throw err;
    list = data.toString('utf-8');
    obj = JSON.parse(list);

      for(var i = 0; i < obj.lista.length; i++){
        for(var j = 0; j < obj.lista[i].length; j++){
          if(obj.lista[i][j] == podaci.index){
            nizIndeksa.push(obj.lista[i][0]);
            nizPozicija.push(j-1);
          }
        }
      }
      var funkcija = function(){
        var z = 0, bodovi = 0, brojOcjena = 0;
        asyncLoop(nizIndeksa, function(item, next){
          fs.readFile('markS' + podaci.spirala + item + '.json', function(err, data){
          if(err)
            throw err;
          temp = data.toString('utf-8');
          var obj2 = JSON.parse(temp);
          bodovi = bodovi + obj2.sadrzaj[nizPozicija[z]].ocjena;
          z = z+1;
          brojOcjena += 1;
          if(z == nizPozicija.length)
            funkcija2(bodovi, brojOcjena);
          });
          next();
        });
        var funkcija2 = function(bodovi, brojOcjena){
          var rezultat = parseInt(bodovi / brojOcjena, 10) + 1;
            var poruka = "Student " + podaci.index + " je ostvario u prosjeku " + rezultat + " mjesto";
          res.writeHead(200, {"Content-Type":'application/json'});
          res.write(poruka);
          res.end();
          //res.json({'poruka':'Student ' + podaci.index + ' je ostvario u prosjeku ' + rezultat.toString() + ' mjesto'});

        }
      }
      funkcija();
  });
});

app.post('/spisak', function(req, res){
  var podaci = req.body;
  console.log(JSON.stringify(podaci.rezultat));
  fs.appendFile('spisakS' + podaci.spirala + '.json', JSON.stringify(podaci.rezultat), function(err){
    if(err)
      throw err;
  });
  res.end("Datoteka uspješno kreirana.");
});

app.listen(3000);
