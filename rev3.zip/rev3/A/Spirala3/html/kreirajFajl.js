var KreirajFajl=(function(){

  var kreirajKomentar = function(spirala, index, sadrzaj, fnCallback){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function(){
      if(ajax.readyState == 4 && ajax.status == 200){
        error = null;
        data = ajax.responseText;
        fnCallback(error,data);
      }
      if(ajax.readyState == 4 && ajax.status == 404){
        error = "404";
        data = ajax.responseText;
        fnCallback(error,data);
      }
      if(spirala == "" || index == ""){
        error = "-1";
        data = "Neispravni parametri";
        fnCallback(error,data);
      }
    }
    var tekst = JSON.stringify({'spirala': spirala, 'index': index, 'sadrzaj': sadrzaj});
    ajax.open("POST", "http://localhost:3000/komentar", true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(tekst);
  }

  var kreirajListu = function(godina, nizRepozitorija, fnCallback){
    var tekst = JSON.stringify({"godina": godina, "nizRepozitorija": nizRepozitorija});
    var error, data;

    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function(){
      if(ajax.readyState == 4 && ajax.status == 200){
        error = null;
        data = ajax.responseText;
      }
      if(ajax.readyState == 4 && ajax.status == 404){
        error = "404";
        data = ajax.responseText;
      }
      if(spirala == "" || JSON.parse(nizRepozitorija) == JSON.parse()){
        error = "-1";
        data = "Neispravni parametri";
      }
      fnCallback(error, data);
    }

    ajax.open("POST", "http://localhost:3000/lista", true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(tekst);
  }

  var kreirajIzvjestaj = function(spirala,index, fnCallback){
    var tekst = JSON.stringify({"spirala": spirala, "index": index});
    var error, data;
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function(){
      if(ajax.readyState == 4 && ajax.status == 200){
        error = null;
        data = ajax.responseText;
      }
      if(ajax.readyState == 4 && ajax.status == 404){
        error = "404";
        data = ajax.responseText;
      }
      if(spirala == "" || index == ""){
        error = "-1";
        data = "Neispravni parametri";
      }
      fnCallback(error, data);
    }
    ajax.open("POST", "http://localhost:3000/izvjestaj", true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(tekst);
  }

  var kreirajBodove = function(spirala,index, fnCallback){
    var error, data;
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function(){
      if(ajax.readyState == 4 && ajax.status == 200){
        error = null;
        data = ajax.responseText;
      }
      if(ajax.readyState == 4 && ajax.status == 404){
        error = "404";
        data = ajax.responseText;
      }
      if(spirala == "" || index == ""){
        error = "-1";
        data = "Neispravni parametri";
      }
      fnCallback(error, data);
    }

    var tekst = JSON.stringify({'spirala': spirala, 'index': index});
    ajax.open("POST", "http://localhost:3000/bodovi", true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(tekst);
  }
  return {
      kreirajKomentar: kreirajKomentar,
      kreirajListu: kreirajListu,
      kreirajIzvjestaj: kreirajIzvjestaj,
      kreirajBodove: kreirajBodove
  }
})();
