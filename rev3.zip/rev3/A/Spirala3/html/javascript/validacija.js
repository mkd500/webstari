function asd(a){
	if(a == 1){
		document.getElementById('registracijaStudenta').style.display = "none";	
		document.getElementById('registracijaNastavnika').style.display = "block";
		if(window.innerWidth > 700)
		document.getElementById('login').style.marginLeft = "8%";
	}
	else{	
		document.getElementById('registracijaNastavnika').style.display = "none";
		document.getElementById('registracijaStudenta').style.display = "block";
		if(window.innerWidth > 700)
		document.getElementById('login').style.marginLeft = "8%";
	}
}


var Validacija=(function(){
	var maxGrupa=7;
	var trenutniSemestar=0;//0 za zimski, 1 za ljetni semestar
	
	var validirajFakultetski = function(email){
		var regex = /\w+@etf.unsa.ba$/;
		if(!regex.test(email)){
			return false;
		}
		return true;
	}
	
	var validirajIndex = function(index){
		var regex = /^1\d\d\d\d$/;
		if(!regex.test(index)){
			return false;
		}
		return true;
	}
	
	var validirajGrupu = function(grupa){
		if(grupa < 1 || grupa > maxGrupa){
			return false;
		}
		return true;
	}
	
	var validirajAkGod = function(akGodina){
		var regex = /^20(\d\d)\/20(\d\d)$/;
		var matchArray = regex.exec(akGodina);
		var broj1;
		var broj2;
		
		if(matchArray != null){
			broj1 = parseInt(matchArray[1]);
			broj2 = parseInt(matchArray[2]);
		}
		else
			return false;
		var godina = parseInt(new Date().getFullYear().toString().substr(-2));
		if(trenutniSemestar == 0 && broj1 == godina && broj2 - broj1 == 1)
			return true;	
		if(trenutniSemestar == 1 && broj2 == godina && broj2 - broj1 == 1)
			return true;
		return false;
		
	}
	
	var validirajPassword = function(pass){
		var regex = /(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])/;
		
		if(pass.length > 20 || pass.length < 7){
			return false;
		}
		else if(!regex.test(pass)){
			return false;
		}
		
		return true;
	}
	
	var validirajPotvrdu = function(pass, potvrda){
		if(pass != potvrda || potvrda == ""){
			return false;
		}
		return true;
	}
	
	var validirajBitbucketURL = function(url){
		var regex = /^https:\/\/\w+@bitbucket.org\/\w+\/\w+\.git$/;
		if(!regex.test(url)){
			return false;
		}
		return true;
	}
	
	var validirajBitbucketSSH = function(ssh){
		var regex = /^git@bitbucket.org:\w+\/\w+\.git$/;
		if(!regex.test(ssh)){
			return false;
		}
		return true;
	}
	
	var validirajNazivRepozitorija = function(reg, naziv){
		if(reg == null){
			var regex = /^wtProjekat1\d\d\d\d$/;
			if(!regex.test(naziv)){
				return false;
			}
			return true;
		}
		if(!reg.test(naziv)){
			return false;
		}
		return true;
	}
	
	var validirajImeiPrezime = function(ime){
		var regex = /^([A-ZČĆŽŠĐ][a-zA-zčćžšđ'-]+) ([A-ZČĆŽŠĐ][a-zA-zčćžšđ'-]+)$/;
		var matchArray = regex.exec(ime);
		var ime1, ime2;
		if(matchArray != null){
			ime1 = matchArray[1];
			ime2 = matchArray[2];
			
			if((ime1.length > 2 && ime1.length < 13) || (ime2.length > 2 && ime2.length < 13))
				return true;
			else{
				return false;
			}
		}
		return false;
	}
	
	var postaviMaxGrupa = function(broj){
		maxGrupa = broj;
	}
	
	var postaviTrenSemestar = function(broj){
		trenSemestar = broj;
	}
	
	return{
		validirajFakultetski: validirajFakultetski,
		validirajIndex: validirajIndex,
		validirajGrupu: validirajGrupu,
		validirajAkGod: validirajAkGod,
		validirajPassword: validirajPassword,
		validirajPotvrdu: validirajPotvrdu,
		validirajBitbucketURL: validirajBitbucketURL,
		validirajBitbucketSSH: validirajBitbucketSSH,
		validirajNazivRepozitorija: validirajNazivRepozitorija,
		validirajImeiPrezime: validirajImeiPrezime,
		postaviMaxGrupa: postaviMaxGrupa,
		postaviTrenSemestar: postaviTrenSemestar
	}
}());

