function kreirajIz(){
  let spirala = document.getElementById('spiralaNastavnik').value.toString();
  let indeks = document.getElementById('indexNastavnik').value;
  KreirajFajl.kreirajIzvjestaj(spirala, indeks, function(err, data){
    document.getElementById("paragrafNastavnik").innerHTML = err;
  });
}

function kreirajBod(){
  let spirala = document.getElementById('spiralaNastavnik').value.toString();
  let indeks = document.getElementById('indexNastavnik').value;
  var poruka = KreirajFajl.kreirajBodove(spirala, indeks, function(err, data){});
  
}
