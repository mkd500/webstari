function potvrdi(){
  var spirala = document.getElementById('spirala').value.toString();
  var indeks = document.getElementById('index').value;
  var komentar1 = document.getElementById('komentar1').value;
  var komentar2 = document.getElementById('komentar2').value;
  var komentar3 = document.getElementById('komentar3').value;
  var komentar4 = document.getElementById('komentar4').value;
  var komentar5 = document.getElementById('komentar5').value;
  var sadrzaj = [];
  sadrzaj.push({'sifra_studenta':'A', 'tekst': komentar1, 'ocjena':0});
  sadrzaj.push({'sifra_studenta':'B', 'tekst': komentar2, 'ocjena':1});
  sadrzaj.push({'sifra_studenta':'C', 'tekst': komentar3, 'ocjena':2});
  sadrzaj.push({'sifra_studenta':'D', 'tekst': komentar4, 'ocjena':3});
  sadrzaj.push({'sifra_studenta':'E', 'tekst': komentar5, 'ocjena':4});

  KreirajFajl.kreirajKomentar(spirala, indeks, sadrzaj, function(error, data){});
  return false;
}
