var Poruke=(function(){
	var idDivaPoruka;
	var mogucePoruke =	["Neispravan unos e-mail adrese",
						"Neispravan unos indexa",
						"Neispravan unos grupe",
						"Neispravan unos akademske godine",
						"Neispravan unos passworda",
						"Neispravna potvrda passworda",
						"Neispravan Bitbucket URL",
						"Neispravan Bitbucket SSH",
						"Neispravan naziv repozitorija",
						"Neispravno ime i prezime"];
	var porukeZaIspis=[];
	
	var ispisiGreske = function(){
		if(porukeZaIspis.length > 0){
			idDivaPoruka.innerHTML = porukeZaIspis[0];
		}
		else
			idDivaPoruka.innerHTML = "";
	}
	
	var postaviIdDiva = function(divId){
		idDivaPoruka = document.getElementById(divId);
	}
	
	var dodajPoruku = function(broj){
		porukeZaIspis.push(mogucePoruke[broj]);
	}
	
	var ocistiGresku = function(broj){
		var a = porukeZaIspis.indexOf(mogucePoruke[broj]);
		if(a != -1)
			porukeZaIspis.splice(a, 1);
	}
	
	return{
	ispisiGreske: ispisiGreske,
	postaviIdDiva: postaviIdDiva,
	dodajPoruku: dodajPoruku,
	ocistiGresku: ocistiGresku
	}
}());

function funkcijaNastavnici(){
	Poruke.postaviIdDiva('greska2');
	
	if(!Validacija.validirajImeiPrezime(document.getElementById('imePrezime').value))
		Poruke.dodajPoruku(9);
	else
		Poruke.ocistiGresku(9);
	
	if(!Validacija.validirajPassword(document.getElementById('pw').value))
		Poruke.dodajPoruku(4);
	else
		Poruke.ocistiGresku(4);
	
	if(!Validacija.validirajPotvrdu(document.getElementById('pw').value, document.getElementById('potvrdapw').value))
		Poruke.dodajPoruku(5);
	else
		Poruke.ocistiGresku(5);
	
	if(!Validacija.validirajFakultetski(document.getElementById('mail').value))
		Poruke.dodajPoruku(0);
	else
		Poruke.ocistiGresku(0);
	
	if(document.getElementById('select').value == "Zimski")
		Validacija.postaviTrenSemestar(0);
	else
		Validacija.postaviTrenSemestar(1);
	
	if(!Validacija.validirajAkGod(document.getElementById('akGodina').value))
		Poruke.dodajPoruku(3);
	else
		Poruke.ocistiGresku(3);
	
	Poruke.ispisiGreske();
	if(Poruke.ispisiGreske() == "")
		return true;
	return false;	
	
}

function funkcijaStudenti(){
	Poruke.postaviIdDiva('greska3');
	
	if(!Validacija.validirajImeiPrezime(document.getElementById('imePrezime2').value))
		Poruke.dodajPoruku(9);
	else
		Poruke.ocistiGresku(9);
	
	if(!Validacija.validirajIndex(document.getElementById('index').value))
		Poruke.dodajPoruku(1);
	else
		Poruke.ocistiGresku(1);
	
	if(!Validacija.validirajGrupu(document.getElementById('grupa').value))
		Poruke.dodajPoruku(2);
	else
		Poruke.ocistiGresku(2);
	
	if(!Validacija.validirajAkGod(document.getElementById('akGodina2').value))
		Poruke.dodajPoruku(3);
	else
		Poruke.ocistiGresku(3);
	
	if(!Validacija.validirajPassword(document.getElementById('pw2').value))
		Poruke.dodajPoruku(4);
	else
		Poruke.ocistiGresku(4);
	
	if(!Validacija.validirajPotvrdu(document.getElementById('pw2').value, document.getElementById('potvrdapw2').value))
		Poruke.dodajPoruku(5);
	else
		Poruke.ocistiGresku(5);
	
	if(!Validacija.validirajBitbucketURL(document.getElementById('bitURL').value))
		Poruke.dodajPoruku(6);
	else
		Poruke.ocistiGresku(6);
	
	if(!Validacija.validirajBitbucketSSH(document.getElementById('bitSSH').value))
		Poruke.dodajPoruku(7);
	else
		Poruke.ocistiGresku(7);
	
	if(!Validacija.validirajNazivRepozitorija(null, document.getElementById('nazivRepo').value))
		Poruke.dodajPoruku(8);
	else
		Poruke.ocistiGresku(8);
	
	Poruke.ispisiGreske();
	if(Poruke.ispisiGreske() == "")
		return true;
	return false;	
	
}


/*document.getElementById("registracijaNastavnika").addEventListener( "submit", 
funkcijaNastavnici, false );*/

/*document.getElementById("registracijaStudenta").addEventListener( "submit", 
funkcijaStudenti, false );*/
