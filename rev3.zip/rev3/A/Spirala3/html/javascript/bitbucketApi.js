var BitbucketApi = (function(){
    var dohvatiAccessToken = function(key, secret, fnCallback){
      function ispisi(error,token){
   if(!error) console.log(token);
  }
  function getAccessToken(proslijedi){
    var ajax = new XMLHttpRequest();

   ajax.onreadystatechange = function() {// Anonimna funkcija
       if (ajax.readyState == 4 && ajax.status == 200)
           proslijedi(null,JSON.parse(ajax.responseText).access_token);
       else if (ajax.readyState == 4)
           proslijedi(ajax.status,null);
   }
   ajax.open("POST", "https://bitbucket.org/site/oauth2/access_token", true);
   ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
   ajax.setRequestHeader("Authorization", 'Basic ' + btoa(key:secret));
   ajax.send("grant_type="+encodeURIComponent("client_credentials"));
  }
  getAccessToken(ispisi);

  function listRepositories(error,token){
   if(error) throw error;
   var ajax = new XMLHttpRequest();
   ajax.onreadystatechange = function(){
       if (ajax.readyState == 4 && ajax.status == 200)
           {
               console.log(ajax.responseText);
               console.log(JSON.parse(ajax.responseText).values[0].name);
               console.log(JSON.parse(ajax.responseText).values[0].owner.username);
              
           }
       else if (ajax.readyState == 4)
           console.log(ajax.status);
   }
   ajax.open("GET","https://api.bitbucket.org/2.0/repositories?role=member");
   ajax.setRequestHeader("Authorization", 'Bearer ' + token);
   ajax.send();

}
    return {
        dohvatiAccessToken: dohvatiAccessToken,
        dohvatiRepozitorije: function(token, godina, naziv, branch, fnCallback){},
        dohvatiBranch: function(token, url, naziv, fnCallback){}
    }
})();
