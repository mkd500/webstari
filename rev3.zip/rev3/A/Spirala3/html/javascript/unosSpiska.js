function submitaj(){
  var spisak = document.getElementById('spisak').value;
  var spirala = document.getElementById('spirala').value.toString();

  var redovi = spisak.split('\n');
  var kolone = [], rezultat = [], pomocni, x = 0;
  for(var i = 0; i < redovi.length; i++){
    kolone[i] = [];
    kolone[i] = redovi[i].split(',');
  }

  for(var i = 0; i < kolone.length; i++){
    pomocni = [];
    for(var j = 0; j < kolone[i].length; j++){
      if(!Validacija.validirajIndex(kolone[i][j])){
        document.getElementById('poruka').innerHTML = "Red " + (i+1) + " ne zadovoljava uslove.";
        x = 1;
        break;
      }
      pomocni.push(kolone[i][j]);
    }
    if(istiIndex(pomocni))
      rezultat.push([pomocni]);
    else {
      document.getElementById('poruka').innerHTML = "Red " + (i+1) + " ne zadovoljava uslove.";
      x = 1;
      break;
    }
  }

  if(x == 0){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function(){
      if(ajax.readyState == 4 && ajax.status == 200){
        error = null;
        data = ajax.responseText;
      }
      if(ajax.readyState == 4 && ajax.status == 404){
        error = "404";
        data = ajax.responseText;
      }
    }
    var tekst = JSON.stringify({'spirala':spirala, 'rezultat':rezultat});
    ajax.open("POST", "http://localhost:3000/spisak", true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(tekst);
    document.getElementById('poruka').innerHTML = "Datoteka uspješno kreirana.";
  }
}

function istiIndex(niz){
  var j = 0, k = 1;
  while(j != niz.length-2){
    for(var i = k; i < niz.length; i++){
      if(niz[j] == niz[i]){
        return false;
      }
    }
    j++; k++;
  }
  return true;
}
