function move(element, pravac){
	var roditelj= element.parentNode.parentNode;
	var dijete= roditelj.parentNode;
	var id= element.parentNode.parentNode.rowIndex;

	if(pravac=="up" && id!=1){
		dijete.insertBefore(roditelj,roditelj.previousElementSibling);
	}   
	else if(pravac=="down"&& id!=5){
		dijete.insertBefore(roditelj.nextElementSibling,roditelj);
    }
}