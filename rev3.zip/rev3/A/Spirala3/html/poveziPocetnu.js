var ajax = new XMLHttpRequest();
ajax.onreadystatechange = function(){
	if (ajax.readyState == 4 && ajax.status == 200)
		document.getElementById("kontejner").innerHTML = ajax.responseText;
	if (ajax.readyState == 4 && ajax.status == 404)
		document.getElementById("kontejner").innerHTML = "Greska: nepoznat URL";
}

function klik(stranica){
  ajax.open("GET", "http://localhost:3000/"+ stranica +".html", true);
  ajax.send();
  return false;
}
