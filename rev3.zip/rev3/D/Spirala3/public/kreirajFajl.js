var KreirajFajl=(function(){
    
    return {
        kreirajKomentar : function(spirala, index, sadrzaj,  fnCallback) {
            if (spirala.length < 1 || index.length < 1) {
                fnCallback(-1, 'Neispravni parametri');
                return;
            }
            for (var i = 0; i < sadrzaj.length; i++) {
                var elementNiza = sadrzaj[i];
                if (elementNiza.sifra_studenta == null|| elementNiza.tekst == null || elementNiza.ocjena == null) {
                    console.log(JSON.stringify(elementNiza));
                    fnCallback(-1, 'Neispravni parametri');
                    return;
                }
            }
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
                if (ajax.status == 200) {
                    fnCallback(null, ajax.responseText);
                }
                else  {
                    fnCallback(ajax.status, ajax.responseText);
                }
            }
            var s = {"spirala" : spirala, "index" : index, "sadrzaj" : sadrzaj};
            ajax.open("POST", "http://localhost:3000/komentar", true);
            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send(JSON.stringify(s));
        },

        kreirajListu : function(godina, nizRepozitorija, fnCallback) {
            if (godina.length < 1 || nizRepozitorija.length < 1) {
                fnCallback(-1, 'Neispravni parametri');
            }
            else {
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function() {
                    if (ajax.status == 200) {
                        fnCallback(null, ajax.responseText);
                    }
                    else {
                        fnCallback(ajax.status, ajax.responseText);
                    }
                }
                var json = {"godina" : godina, "nizRepozitorija" : nizRepozitorija};
                ajax.open("POST", "http://localhost:3000/lista", true);
                ajax.setRequestHeader("Content-Type", "application/json");
                ajax.send(JSON.stringify(json));
            }
        },

        kreirajIzvjestaj : function(spirala,index, fnCallback) {
            if (spirala.length < 1 || index.length < 1) {
                fnCallback(-1, 'Neispravni parametri')
            }
            else {
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function() {
                    if (ajax.status == 200) {
                        fnCallback(null, ajax.responseText);
                    }
                    else  {
                        fnCallback(ajax.status, ajax.responseText);
                    }

                    
                }
                var json = {"spirala" : spirala, "index" : index};
                ajax.open("POST", "http://localhost:3000/izvjestaj");
                ajax.setRequestHeader("Content-Type", "application/json");
                ajax.send(JSON.stringify(json));
        }

        },
        kreirajBodove : function(spirala,index, fnCallback) {
            if (spirala.length < 1 || index.length < 1) {
                fnCallback(-1, 'Neispravni parametri')
            }
            else {
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function() {
                    if (ajax.status == 200) {
                        fnCallback(null, ajax.responseText);
                    }
                    else  {
                        fnCallback(ajax.status, ajax.responseText);
                    }
                }
                var json = {"spirala" : spirala, "index" : index};
                ajax.open("POST", "http://localhost:3000/bodovi");
                ajax.setRequestHeader("Content-Type", "application/json");
                ajax.send(JSON.stringify(json));
            }
        }     
    }
})();

function ispisi(err, dat) {
    console.log(dat);
}
