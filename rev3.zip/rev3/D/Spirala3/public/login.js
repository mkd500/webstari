Poruke.postaviIdDiva("greske");

var sImePrezime = document.getElementsByName("sImePrezime")[0];
sImePrezime.addEventListener("blur", function() {
	if (!Validacija.validirajImeIPrezime(sImePrezime.value)) {
		Poruke.dodajPoruku(9);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(9);
		Poruke.ispisiGreske();
	}
}, false);

var sIndeks = document.getElementsByName("sIndeks")[0];
sIndeks.addEventListener("blur", function() {
	if (!Validacija.validirajIndex(sIndeks.value)) {
		Poruke.dodajPoruku(1);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(1);
		Poruke.ispisiGreske();
	}
}, false);

var sGrupa = document.getElementsByName("sGrupa")[0];
sGrupa.addEventListener("blur", function() {
	if (!Validacija.validirajGrupu(sGrupa.value)) {
		Poruke.dodajPoruku(2);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(2);
		Poruke.ispisiGreske();
	}
}, false);


var sAkademskaGodina = document.getElementsByName("sAkademskaGodina")[0];
sAkademskaGodina.addEventListener("blur", function() {
	if (!Validacija.validirajAkGod(sAkademskaGodina.value)) {
		Poruke.dodajPoruku(3);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(3);
		Poruke.ispisiGreske();
	}
}, false);

var sPassword = document.getElementsByName("sPassword")[0];
sPassword.addEventListener("blur", function() {
	if (!Validacija.validirajPassword(sPassword.value)) {
		Poruke.dodajPoruku(4);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(4);
		Poruke.ispisiGreske();
	}
}, false);

var sPotvrdaPassworda = document.getElementsByName("sPotvrdaPassworda")[0];
sPotvrdaPassworda.addEventListener("blur", function() {
	if (!Validacija.validirajPotvrdu(sPassword.value, sPotvrdaPassworda.value)) {
		Poruke.dodajPoruku(5);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(5);
		Poruke.ispisiGreske();
	}
}, false);

var sBitbucketURL = document.getElementsByName("sBitbucketURL")[0];
sBitbucketURL.addEventListener("blur", function() {
	if (!Validacija.validirajBitBucketURL(sBitbucketURL.value)) {
		Poruke.dodajPoruku(6);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(6);
		Poruke.ispisiGreske();
	}
}, false);

var sBitbucketSSH = document.getElementsByName("sBitbucketSSH")[0];
sBitbucketSSH.addEventListener("blur", function() {
	if (!Validacija.validirajBitBucketSSH(sBitbucketSSH.value)) {
		Poruke.dodajPoruku(7);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(7);
		Poruke.ispisiGreske();
	}
}, false);

var sNazivRepozitorija = document.getElementsByName("sNazivRep")[0];
sNazivRepozitorija.addEventListener("blur", function() {
	if (!Validacija.validirajNazivRepozitorija(null, sNazivRepozitorija.value)) {
		Poruke.dodajPoruku(8);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(8);
		Poruke.ispisiGreske();
	}
}, false);

var sRegister = document.getElementsByName("sRegister")[0];
sRegister.addEventListener("click", function() {
	/*var div = document.getElementById("greske");
	div.style.borderTop = "2px solid #b30047";*/
}, false);

var nImePrezime = document.getElementsByName("nImePrezime")[0];
nImePrezime.addEventListener("blur", function() {
	if (!Validacija.validirajImeIPrezime(nImePrezime.value)) {
		Poruke.dodajPoruku(9);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(9);
		Poruke.ispisiGreske();
	}
}, false);

var nPassword = document.getElementsByName("nPassword")[0];
nPassword.addEventListener("blur", function() {
	if(!Validacija.validirajPassword(nPassword.value)) {
		Poruke.dodajPoruku(4);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(4);
		Poruke.ispisiGreske();
	}
}, false);


var nPotvrdaPassworda = document.getElementsByName("nPotvrdaPassworda")[0];
nPotvrdaPassworda.addEventListener("blur", function() {
	if (!Validacija.validirajPotvrdu(nPassword.value, nPotvrdaPassworda.value)) {
		Poruke.dodajPoruku(5);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(5);
		Poruke.ispisiGreske();
	}
}, false);

var nEmail = document.getElementsByName("nMail")[0];
nEmail.addEventListener("blur", function() {
	if (!Validacija.validirajFakultetski(nEmail.value)) {
		Poruke.dodajPoruku(0);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(0);
		Poruke.ispisiGreske();
	}
}, false);

var nMaxGrupa = document.getElementsByName("nMaxGrupa")[0];
nMaxGrupa.addEventListener("blur", function() {
	Validacija.postaviMaxGrupa(nMaxGrupa.value);
}, false);

var nRegex = document.getElementsByName("nRegex")[0];
nRegex.addEventListener("blur", function() {
	
}, false);

var nTrenutniSemestar = document.getElementsByName("nTrenutniSemestar")[0];
nTrenutniSemestar.addEventListener("blur", function() {
	Validacija.postaviTrenSemestar(nTrenutniSemestar.value);
}, false);

var nAkademskaGodina = document.getElementsByName("nTrenutnaAkGodina")[0];
nAkademskaGodina.addEventListener("blur", function() {
	if (!Validacija.validirajAkGod(nAkademskaGodina.value)) {
		Poruke.dodajPoruku(3);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(3);
		Poruke.ispisiGreske();
	}
}, false);

var nRegisterButton = document.getElementsByName("nRegisterButton")[0];
nRegisterButton.addEventListener("click", function() {
	/*var div = document.getElementById("greske");
	div.style.borderTop = "2px solid #b30047";*/
}, false);

function promijeniFormu() {
	var radioNastavnik = document.getElementById("registracijaNastavnika");
	var radioStudent = document.getElementById("registracijaStudenta");
	
	
	if (radioNastavnik.checked) {
		document.getElementsByClassName("nregister")[0].style.display = "block";
		document.getElementsByClassName("register")[0].style.display = "none";
		for (var i = 0; i < 9; i++)
			Poruke.ocistiGresku(i);
		Poruke.ispisiGreske();
	} 
	else if (radioStudent.checked) {	
		document.getElementsByClassName("nregister")[0].style.display = "none";
		document.getElementsByClassName("register")[0].style.display= "block";
		for (var i = 0; i < 9; i++)
			Poruke.ocistiGresku(i);
		Poruke.ispisiGreske();
	}
	
}

