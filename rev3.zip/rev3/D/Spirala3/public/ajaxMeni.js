var odabranaStranica = 0;

function login() {
    odabranaStranica = 1;
    ajax();
}

function statistika() {
    odabranaStranica = 2;
    ajax();
}

function unosKomentara() {
    odabranaStranica = 3;
    ajax();
}

function unosSpiska() {
    odabranaStranica = 4;
    ajax();
}

function nastavnik() {
    odabranaStranica = 5;
    ajax();
}

function bitbucketPozivi() {
    odabranaStranica = 6;
    ajax();
}

function ajax() {
    var ajax = new XMLHttpRequest();
    var stranice = ["login.html", "statistika.html", "unoskomentara.html", "unosSpiska.html", "nastavnik.html", "bitbucketPozivi.html"];
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4 && ajax.status == 200) {
			document.getElementById('rezultat_zahtjeva').innerHTML = "";
            document.getElementById('sadrzaj_stranice').innerHTML = ajax.response;
            if (odabranaStranica == 1) {
                var script = document.createElement("script"); 
                script.src = "login.js"; 
                document.head.appendChild(script); 
            }
            else if (odabranaStranica == 6) {
                document.getElementById('rezultat_zahtjeva').style.display = 'none';
            }
			
        }
        if (ajax.readyState == 4 && ajax.status == 404)
            document.getElementById("sadrzaj_stranice").innerHTML = "Greska: nepoznat URL";
    }
    ajax.open("GET", "http://localhost:3000/" + stranice[odabranaStranica - 1], true);
    ajax.send();  
}
