function move(button) {
	var redovi = document.getElementById("tabela").rows;
	var goreDole = button.id.toString().substring(0,2);
	var trenutniIndex = Number(button.id.toString().substring(3));
	if (goreDole == "up") {
		if (trenutniIndex > 1) {
			var trenutniRed = redovi[trenutniIndex];
			var prethodniRed = redovi[trenutniIndex - 1];
			trenutniRed.parentNode.insertBefore(trenutniRed, prethodniRed);
	
			var prethodniButton = document.getElementById("up_" + (trenutniIndex - 1).toString());
			var trenutniDown = document.getElementById("dn_" + trenutniIndex.toString());
			var prethodniDown = document.getElementById("dn_" + (trenutniIndex - 1).toString());
			
			var temp = prethodniButton.id;
			prethodniButton.id = button.id;
			button.id = temp;
			
			temp = trenutniDown.id;
			trenutniDown.id = prethodniDown.id;
			prethodniDown.id = temp;
		}
	}
	
	else {
		if (trenutniIndex < 5) {
			var trenutniRed = redovi[trenutniIndex];
			var sljedeciRed = redovi[trenutniIndex + 1];
			sljedeciRed.parentNode.insertBefore(sljedeciRed, trenutniRed);
	
			var sljedeciButton = document.getElementById("dn_" + (trenutniIndex + 1).toString());
			var trenutniUp = document.getElementById("up_" + trenutniIndex.toString());
			var sljedeciUp = document.getElementById("up_" + (trenutniIndex + 1).toString());
			
			var temp = sljedeciButton.id;
			sljedeciButton.id = button.id;
			button.id = temp;
			
			temp = trenutniUp.id;
			trenutniUp.id = sljedeciUp.id;
			sljedeciUp.id = temp;
			
		}
	}		
}

function azuriraj(range) {
	var odabraniID = range.id.substring(6,7);
	var par = document.getElementById("p_" + odabraniID);
	par.innerHTML = range.value;
}

function kreirajKomentare() {
	var spirala = document.getElementsByName('spirala')[0].value;
	var index = document.getElementsByName('index')[0].value;
	var sadrzaj = [];
	var tabela = document.getElementById('tabela');
	for (var i = 1; i < 6; i++) {
		for (var j = 1; j < 6; j++) {
			if (tabela.rows[j].cells[0].innerHTML.toString() == String.fromCharCode(i + 49 + 15)) {
				var json = {"sifra_studenta" : tabela.rows[j].cells[0].innerHTML, "tekst" : tabela.rows[j].cells[1].children[0].value, "ocjena" : j - 1};
				sadrzaj.push(json);
				break;
			}
		}
	}
	KreirajFajl.kreirajKomentar(document.getElementsByName('spirala')[0].value, document.getElementsByName('index')[0].value, sadrzaj, ispisiPoruku);
}

function ispisiPoruku(err, data) {
	if (!err || err == -1) {
		if (data) {
			if (err != -1) {
				var json = JSON.parse(data);
				if (json.message == null)
					document.getElementById('rezultat_zahtjeva').innerHTML = json.poruka;
				else
					document.getElementById("rezultat_zahtjeva").innerHTML = JSON.parse(data).message;
			}
			else 
				document.getElementById("rezultat_zahtjeva").innerHTML = data;
		}
	}
	else
		document.getElementById("rezultat_zahtjeva").innerHTML = err;
}