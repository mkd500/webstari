var Poruke = (function() {
	var idDivaPoruke;
	var mogucePoruke = ["Email koji ste napisali nije validan fakultetski email.", //0
						"Indeks koji ste napisali nije validan.\n", // 1
						"Nastavna grupa koju ste napisali nije validna.", // 2
						"Akademska godina koju ste napisali nije validna.\n", //3
						"Password koji ste napisali nije validan.", //4
						"Passwordi koje ste napisali se međusobno ne preklapaju.", // 5
						"URL Bitbucket-a koji ste napisali nije validan.", // 6
						"SSH Bitbucket-a koji ste napisali nije validan.", // 7 
						"Naziv repozitorija koji ste napisali nije validan.", // 8
						"Ime i prezime koje ste napisali nisu validni."]; // 9
	
	var porukeZaIspis = [];
	
	return {
		ispisiGreske: function() {
			var div = document.getElementById(idDivaPoruke);
			div.innerHTML = '';
			for (var i = 0; i < porukeZaIspis.length; i++)
				div.innerHTML += porukeZaIspis[i] + '\n';
		},
		
		postaviIdDiva: function(id) {
			idDivaPoruke = id;
		},
		
		dodajPoruku: function(broj) {
			if (broj >= 0 && broj < mogucePoruke.length) {
				var i = 0;
				for (i = 0; i < porukeZaIspis.length; i++) {
					if (porukeZaIspis[i] == mogucePoruke[broj]) {
						break;
					}
				}
				if (i == porukeZaIspis.length) {
					porukeZaIspis.push(mogucePoruke[broj]);
				}
				
			}
		}, 
		
		ocistiGresku: function(broj) {
			if (broj >= 0 && broj < mogucePoruke.length) {
				for (var i = 0; i < porukeZaIspis.length; i++) {
					if (porukeZaIspis[i] == mogucePoruke[broj])
						porukeZaIspis.splice(i, 1);
				}
			}
		}
	}
}());