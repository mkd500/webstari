var Validacija = (function() {
	var maxGrupa = 7;
	var trenutniSemestar = 0;
	var indeksZaRep = 0;
	
    return {
		validirajFakultetski: function(fakultetskiMail) {
			var reg = /.{1,}@etf.unsa.ba$/;
			return fakultetskiMail.match(reg);
		},
		
		validirajIndex: function(indeks) {
			var brIndeksa = indeks.toString();
			if (brIndeksa.length == 5 && brIndeksa.charAt(0) == '1') {
				indeksZaRep = Number(indeks);
				return true;
			}
			
			return false;
		},
		
		validirajGrupu: function(grupa) {
			return Number(grupa) >= 1 && Number(grupa) <= maxGrupa;
		},
		
		validirajAkGod: function(godina) {
			if (godina.length == 9) {
				var d = new Date();
				var trenutnaGodina = d.getFullYear().toString().substr(2,2);
				var AB = godina.substr(2, 2);
				var CD = godina.substr(7, 2);
				if (trenutniSemestar == 0)
					return AB == trenutnaGodina && Number(CD) == (Number(AB) + 1);
				else
					return CD == trenutnaGodina && Number(CD) == (Number(AB) + 1);
			}
			
			return false;
		},
		
		validirajPassword: function(password) {
			var reg = /^(?=.*[A-Z])(?=.*\d)[A-Za-z\d]{7,20}$/;
			return password.match(reg);
		},
		
		validirajPotvrdu: function(prvaSifra, drugaSifra) {
			if (Validacija.validirajPassword(prvaSifra)) // validira samo ako je password tacan
				return prvaSifra == drugaSifra;
			
			return false;
		},

		validirajBitBucketURL: function(url) {
			var reg = /^https:\/\/.{1,}(@bitbucket.org\/).{1,}(\/).{1,}(.git)$/;
			return url.match(reg);
		},

		validirajBitBucketSSH: function(ssh) {
			var reg = /^git@bitbucket.org:.{1,}(\/).{1,}(.git)$/;
			return ssh.match(reg);
		},
		
		validirajNazivRepozitorija: function(reg, naziv) {
			if (!reg) {
				reg = /^wt(p|P)rojekat1\d{4}$/;
				if (naziv.match(reg)) {
					var ind = naziv.substring(10, 15);
					return indeksZaRep == ind;
				}
				
				return false;
			}
			return naziv.match(reg);
		},
		
		validirajImeIPrezime: function(imeIPrezime) {
			var reg = /^(([A-ZČĆĐŽŠ]([A-ZČĆĐŠŽa-zčćšđž]){1,}))((([\s\'-]+)[A-ZČĆĐŽŠ]([A-ZČĆŽĐŠa-zčćšđž]){1,}){0,})$/;
			pom = imeIPrezime.split(" ");
			for (var i = 0; i < pom.length; i++)
				if (pom[i].length >= 3 && pom[i].length <= 12)
					break;
			return i != pom.length && imeIPrezime.match(reg);
		},
		
		postaviMaxGrupa: function(grupa) {
			maxGrupa = grupa;
		},
		
		postaviTrenSemestar: function(semestar) {
			trenutniSemestar = semestar;
		}
	}
}());