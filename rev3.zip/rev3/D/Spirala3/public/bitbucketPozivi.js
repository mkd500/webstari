function uhvatiAccesToken(err, data) {
    if(!err) {
       if (data)
            BitbucketApi.dohvatiRepozitorije(data, document.getElementsByName('godina')[0].value, document.getElementsByName('repozitorij')[0].value, document.getElementsByName('branch')[0].value, uhvatiRepozitorije);
    }
    else
        ispisiRezultat(err, data);
    }

function uhvatiRepozitorije(err, data) {
    if(!err)
        if (data) {
                /*var repozitoriji = "";
                for (var i = 0; i < data.length; i++) {
                    repozitoriji += data[i] + "\n";
                }  */
                var s = JSON.stringify(data);
                KreirajFajl.kreirajListu(document.getElementsByName('godina')[0].value, JSON.parse(s), ispisiRezultat);
                
        }
    else
        document.getElementById('rezultatPretrage').innerHTML = err;
}

function ispisiRezultat(err, data) {
    if (err != null) 
        document.getElementById('rezultatPretrage').innerHTML =  data;
    
    else
        document.getElementById('rezultatPretrage').innerHTML = err;
}