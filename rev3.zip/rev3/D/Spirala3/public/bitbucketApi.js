var BitbucketApi = (function(){
    var postojiLiBranch = false;
    var isDone = false;
    return {
        dohvatiAccessToken: function(key, secret, fnCallback){
            if (!key || !secret)
                fnCallback(-1, "Key ili secret nisu pravilno proslijeđeni!");
            else {
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function() {
                    if (ajax.readyState == 4 && ajax.status == 200)
                        fnCallback(null, JSON.parse(ajax.responseText).access_token);
                    else 
                        fnCallback(ajax.status, null);
                }
                ajax.open("POST", "https://bitbucket.org/site/oauth2/access_token", true);
                ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                ajax.setRequestHeader("Authorization", 'Basic ' + btoa(key + ':' + secret));
                //ajax.setRequestHeader("Authorization", 'Basic ' + btoa('MEqHJjNtsFdnCJ6EBc:gCgCRv8xpwKV9bYSFbGjx8KxsCGPqQzK'));
                ajax.send("grant_type="+encodeURIComponent("client_credentials"));
            }
        },

        dohvatiRepozitorije: function(token, godina, naziv, branch, fnCallback){
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200) {
                    var repozitoriji = JSON.parse(ajax.responseText);
                    var odabraniRepozitoriji = [];
                    for (var i = 0; i < repozitoriji.values.length; i++) {
                                    BitbucketApi.dohvatiBranch(token, repozitoriji.values[i].links.branches.href, branch, funkcija);
                                    if (postojiLiBranch) {
                                        odabraniRepozitoriji.push(repozitoriji.values[i].links.clone[1].href);
                                        postojiLiBranch = false;
                                        //isDone = false;
                                    }
                    }
                    fnCallback(null, odabraniRepozitoriji);
                }
                else 
                    fnCallback(ajax.status, null);
            }
            ajax.open("GET", "https://api.bitbucket.org/2.0/repositories?q=name~%22" + naziv + "%22+and+created_on>=" + godina.toString() + "-01-01+and+created_on<=" + (parseInt(godina) + 1).toString()+ "-12-31&role=member&pagelen=150", false);
            ajax.setRequestHeader("Authorization", 'Bearer ' + token);
            ajax.send();
        },
        dohvatiBranch: function(token, url, naziv, fnCallback){
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200) {
                    var branches = JSON.parse(ajax.responseText);
                    for (var i = 0; i < branches.values.length; i++) {
                        if (branches.values[i].name == naziv) {
                            postojiLiBranch = true;
                            fnCallback(null, true);
                            return;
                        }
                    }
                    if (i == branches.values.length)
                        fnCallback(null, false);
                }
                else
                    fnCallback(ajax.status, false);
            }

            ajax.open("GET", url, false);
            ajax.setRequestHeader("Authorization", 'Bearer ' + token);
            ajax.send();
        }
    }
})();

function funkcija(err, value) {
}