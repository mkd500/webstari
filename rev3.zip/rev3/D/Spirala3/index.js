const express = require('express'); 
const bodyParser = require('body-parser'); 
const fs = require('fs'); 
const app = express(); 
const csv = require('csvtojson');

app.use(express.static('public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.post("/komentar", function(req, res){
    var data = req.body;
    var ind = 0;
    if (data.spirala == null || data.index == null || data.sadrzaj == null) {
        res.end(JSON.stringify({"message" : "Podaci nisu u traženom formatu!", data:null}));
        ind = 1;
    }
    for (var i = 0; i < data.sadrzaj.length; i++) {
        if (data.sadrzaj[i].sifra_studenta == null || data.sadrzaj[i].tekst == null || data.sadrzaj[i].ocjena == null) {
            res.end(JSON.stringify({"message" : "Podaci nisu u traženom formatu!", data:null}));
            ind = 1;
            break;
        }
    }
    if (ind == 0) {
        var naziv = "marksS" + data.spirala + data.index + ".json"; 
        fs.writeFile(naziv, JSON.stringify(data), function(err) {
            if(err) {
                throw err;
            }
            res.end(JSON.stringify({"message":"Uspješno kreirana datoteka!","data": JSON.stringify(data)}));
        }); 
    }
});

app.post("/lista", function(req, res) {
    var data = req.body;
    var ind = 0;
    if (data.godina == null || data.nizRepozitorija == null) {
        res.end(JSON.stringify({"message" : "Podaci nisu u traženom formatu!", data:null}));
        ind = 1;
    }

    if (ind == 0) {
        if (data.godina.length < 1 || data.nizRepozitorija.length < 1) {
            res.end(JSON.stringify({"message" : "Podaci nisu u traženom formatu!", data:null}));
            ind = 1;
        }
    }

    if (ind == 0) {
        var naziv = "spisak" + data.godina + ".txt";
        var datoteka = "";
        for (var i = 0; i < data.nizRepozitorija.length; i++) {
            if (data.nizRepozitorija[i].includes(data.godina)) {
                datoteka += data.nizRepozitorija[i] + "\n";
            }
        }
        fs.writeFile(naziv, datoteka, function(err) {
            if (err)
                throw err;
            
            res.end(JSON.stringify({"message":"Lista uspješno kreirana","data":datoteka.split('\n').length - 1}));
        });
    }
});

app.post("/izvjestaj", function(req, res) {
    data = req.body;
    fs.readdir("./", (err, listaDatoteka) => {
        if (err)
            throw err;
        var naziv = "spisakS" + data.spirala + ".json";
        fs.readFile(naziv, (err, sadrzajDat) => {
            var spisak = JSON.parse(sadrzajDat.toString('utf-8'));
            var komentariNaSpiralu = "";
            for (var i = 0; i < spisak.length; i++) {
                for (var j = 1; j < spisak[i].length; j++) {
                    if (spisak[i][j] == data.index) {
                        var pom = j;
                        for (var k = 0; k < listaDatoteka.length; k++) {
                            var naziv = "marksS" + data.spirala + spisak[i][0] + ".json";
                            if (listaDatoteka[k] == naziv) {
                                var fileContent = fs.readFileSync(naziv);
                                var podaci = JSON.parse(fileContent.toString('utf-8'));
                                var komentari = podaci.sadrzaj;
                                for (var s = 0; s < komentari.length; s++) {
                                    if (komentari[s].sifra_studenta.toString() == String.fromCharCode(j + 16 + 48)) {
                                        var kom = komentari[s].tekst.length > 0 ? komentari[s].tekst + "\n##########\n" : "\n##########\n";
                                        komentariNaSpiralu += kom;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            fs.writeFile("izvjestajS" + data.spirala + data.index + ".txt", komentariNaSpiralu, (err) => {
                if (err)
                    throw err;
                
                res.end(JSON.stringify({"message":"Datoteka uspješno kreirana","data": komentariNaSpiralu}));
                
            });
        });
    });
});

app.post("/bodovi", (req, res) =>{
    var data = req.body;
    console.log(JSON.stringify(data));
    fs.readdir("./", (err, listaDatoteka) => {
        if (err)
            throw err;
        var naziv = "spisakS" + data.spirala + ".json";
        fs.readFile(naziv, (err, sadrzajDat) => {
            var spisak = JSON.parse(sadrzajDat.toString('utf-8'));
            var zbirOcjena = 0;
            var brojOcjena = 0;
            for (var i = 0; i < spisak.length; i++) {
                for (var j = 1; j < spisak[i].length; j++) {
                    if (spisak[i][j] == data.index) {
                        var pom = j;
                        for (var k = 0; k < listaDatoteka.length; k++) {
                            var naziv = "marksS" + data.spirala + spisak[i][0] + ".json";
                            if (listaDatoteka[k] == naziv) {
                                var fileContent = fs.readFileSync(naziv);
                                var podaci = JSON.parse(fileContent.toString('utf-8'));
                                var komentari = podaci.sadrzaj;
                                for (var s = 0; s < komentari.length; s++) {
                                    if (komentari[s].sifra_studenta.toString() == String.fromCharCode(j + 16 + 48)) {
                                        zbirOcjena += komentari[s].ocjena;
                                        brojOcjena++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            res.end(JSON.stringify({'poruka':'Student ' + data.index + ' je ostvario u prosjeku ' + (Math.floor(zbirOcjena/brojOcjena) + 1).toString() + ' mjesto'}));
        });
    });
});

app.post('/', (req, res) => {
    var zahtjev = req.body;
    var ind = 0;
    if (zahtjev.spirala.length < 1) {
        res.end(JSON.stringify({"message" : "Greška u broju spirale.", data:null}));
        ind = 1;
    }
    if (ind == 0) {
        var spisak = zahtjev['indeksi'];
        var redovi = spisak.split('\r\n');
        for (var i = 0; i < redovi.length; i++) {
            var kolone = redovi[i].split(',');
            if (kolone.length != 6) {
                res.end(JSON.stringify({"message" : "Greška u " + (i + 1) + "-tom redu.", data:null}));
                break;
            }
            else
                for (var j = 0; j < 6; j++) {
                    if (kolone[j].length != 5) {
                        res.end(JSON.stringify({"message" : "Greška u " + (i + 1) + "-tom redu.", data:null}));
                        break;
                    }
                    for (var k = j + 1; k < 6; k++) {
                        if (kolone[j] == kolone[k]) {
                            res.end(JSON.stringify({"message" : "Greška u " + (i + 1) + "-tom redu." + kolone[k], data:null}));
                            break;
                        }
                    }
                    if (k != 6)
                        break;
                }
                if (j != 6)
                break;
        }
        if (i == redovi.length) {
            var json = [];
            csv({noheader:true}).fromString(spisak).on('csv', (csvRow) => {
                json.push(csvRow);
            }).on('done',()=> {
                fs.writeFile("spisakS" + zahtjev['spirala'] + ".json", JSON.stringify(json), (err) => {
                    if (err)
                        throw err;
                    
                    res.end(JSON.stringify({"message":"Datoteka uspješno kreirana","data": JSON.stringify(json)}));
                });
            });
        }
    }
});

app.listen(3000);